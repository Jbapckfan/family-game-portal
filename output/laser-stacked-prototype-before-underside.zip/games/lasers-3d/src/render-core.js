/* Lasers 3D - renderer core helpers (shared by render-*.js and render.js).
 * Global: window.LaserRenderCore. Classic script, ES2019 (Safari 15). Needs THREE (r160 UMD).
 *
 * World mapping (INTERFACES-FRONTEND.md 1.2, FROZEN): game (x, y, z) -> three (x, z, -y).
 */
(function (root) {
  'use strict';
  var THREE = root.THREE;

  function world(x, y, z, out) {
    out = out || new THREE.Vector3();
    return out.set(x, z, -y);
  }

  /* Build a THREE material from a theme materials entry. `ov` overrides / fills 'accent' / 'beam' slots. */
  function matFromSpec(spec, ov) {
    ov = ov || {};
    var Ctor = THREE[spec.material] || THREE.MeshStandardMaterial;
    var m = new Ctor();
    var color = ov.color || spec.color;
    var emissive = ov.emissive || spec.emissive;
    if (typeof color === 'string' && color.charAt(0) === '#') m.color = new THREE.Color(color);
    if (m.emissive !== undefined && typeof emissive === 'string' && emissive.charAt(0) === '#') m.emissive = new THREE.Color(emissive);
    if (m.metalness !== undefined && typeof spec.metalness === 'number') m.metalness = spec.metalness;
    if (m.roughness !== undefined && typeof spec.roughness === 'number') m.roughness = spec.roughness;
    var ei = ov.emissiveIntensity !== undefined ? ov.emissiveIntensity : spec.emissiveIntensity;
    if (m.emissiveIntensity !== undefined && typeof ei === 'number') m.emissiveIntensity = ei;
    var op = ov.opacity !== undefined ? ov.opacity : spec.opacity;
    if (typeof op === 'number') m.opacity = op;
    m.transparent = ov.transparent !== undefined ? ov.transparent : !!spec.transparent;
    if (m.clearcoat !== undefined && typeof spec.clearcoat === 'number') m.clearcoat = spec.clearcoat;
    if (m.clearcoatRoughness !== undefined && typeof spec.clearcoatRoughness === 'number') m.clearcoatRoughness = spec.clearcoatRoughness;
    if (m.transmission !== undefined && typeof spec.transmission === 'number') m.transmission = spec.transmission;
    if (m.ior !== undefined && typeof spec.ior === 'number') m.ior = spec.ior;
    if (spec.side === 'DoubleSide') m.side = THREE.DoubleSide;
    if (spec.blending === 'AdditiveBlending') m.blending = THREE.AdditiveBlending;
    if (spec.depthWrite === false) m.depthWrite = false;
    if (spec.depthTest === false) m.depthTest = false;
    if (spec.toneMapped === false) m.toneMapped = false;
    return m;
  }

  /* Brushed-metal grain: 64x2 canvas of near-white vertical bands (<= 8% luminance contrast),
   * used as a map under the housing colour so the colour stays metal-mid. */
  var grainCache = null;
  function grainTexture(theme) {
    if (grainCache) return grainCache;
    var g = theme.brushedGrain;
    var c = document.createElement('canvas');
    c.width = g.width; c.height = g.height;
    var ctx = c.getContext('2d');
    var hi = 255, lo = Math.round(255 * (1 - g.maxLuminanceContrast));
    for (var x = 0; x < g.width; x++) {
      var v = (x % 2 === 0) ? hi : lo;
      ctx.fillStyle = 'rgb(' + v + ',' + v + ',' + v + ')';
      ctx.fillRect(x, 0, 1, g.height);
    }
    var tex = new THREE.CanvasTexture(c);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(g.repeatX, 1);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.magFilter = THREE.NearestFilter;
    grainCache = markShared(tex);
    return tex;
  }

  /* Merge non-indexed geometries (position/normal/uv) into one BufferGeometry. No addons. */
  function mergeGeometries(list) {
    var pos = [], nor = [], uv = [], i, j, g, p, n, u;
    for (i = 0; i < list.length; i++) {
      g = list[i].index ? list[i].toNonIndexed() : list[i];
      p = g.getAttribute('position'); n = g.getAttribute('normal'); u = g.getAttribute('uv');
      for (j = 0; j < p.count * 3; j++) pos.push(p.array[j]);
      for (j = 0; j < p.count * 3; j++) nor.push(n ? n.array[j] : 0);
      for (j = 0; j < p.count * 2; j++) uv.push(u ? u.array[j] : 0);
      if (g !== list[i]) g.dispose();
    }
    var out = new THREE.BufferGeometry();
    out.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    out.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
    out.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    return out;
  }

  /* Box placed by center + size (world units), returned as a transformed geometry for merging. */
  function boxAt(cx, cy, cz, sx, sy, sz) {
    var g = new THREE.BoxGeometry(sx, sy, sz);
    g.translate(cx, cy, cz);
    return g;
  }

  /* Canvas-drawn sprite textures. */
  function makeCanvas(w, h) { var c = document.createElement('canvas'); c.width = w; c.height = h; return c; }

  function badgeTexture(theme, level) {
    var b = theme.beam.badge, scale = 4;
    var w = b.widthPx * scale, h = b.heightPx * scale;
    var c = makeCanvas(w, h), ctx = c.getContext('2d'), r = h / 2, bw = b.borderPx * scale;
    var color = level < 0 ? '#CDB7FF' : theme.beamColors[level];
    ctx.save();
    ctx.shadowColor = color; ctx.shadowBlur = b.glowPx * scale;
    roundRect(ctx, bw, bw, w - 2 * bw, h - 2 * bw, r - bw);
    ctx.fillStyle = b.fill; ctx.fill();
    ctx.restore();
    roundRect(ctx, bw, bw, w - 2 * bw, h - 2 * bw, r - bw);
    ctx.lineWidth = bw; ctx.strokeStyle = color; ctx.stroke();
    ctx.fillStyle = theme.palette.uiText;
    ctx.font = b.fontWeight + ' ' + (b.fontSizePx * scale) + 'px ' + theme.ui.fonts.data;
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(level < 0 ? 'Z−' + (-level) : b.labels[level], w / 2, h / 2 + scale);
    var tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.arc(x + w - r, y + r, r, -Math.PI / 2, 0);
    ctx.lineTo(x + w, y + h - r); ctx.arc(x + w - r, y + h - r, r, 0, Math.PI / 2);
    ctx.lineTo(x + r, y + h); ctx.arc(x + r, y + h - r, r, Math.PI / 2, Math.PI);
    ctx.lineTo(x, y + r); ctx.arc(x + r, y + r, r, Math.PI, Math.PI * 1.5);
    ctx.closePath();
  }

  /* ---- ARCHES AND WINDOWS (DESIGN.md 13.1) ----------------------------------------------------------------
   * A level may carry `openings: [{ x, y, levels: [0] }]` - the levels punched OUT of that column. The engine
   * normalises this in LaserSim.parseLevel to `openMask[y][x]`, a per-column bitmask, alongside a canonical
   * `openings` array, so the renderer reads the PARSED level and never the raw one. Field naming is the engine's
   * call and this is the seam between the two, so the adapter accepts every shape it could reasonably hand back
   * and reduces them all to one flat bitmask:
   *
   *   parsed.isOpen(x, y, z) -> boolean                (a predicate wins over any data field)
   *   parsed.openMask / parsed.open                    (d rows of w - what the engine ships - or a flat w*d array)
   *   parsed.openings: [{x, y, levels: [..]}]          (also tolerated: {level: n} and {mask: n})
   *   parsed.raw.openings                              (a level object that never went through parseLevel)
   *
   * Bit k of the returned mask means "level k of this column is NOT solid". A bit at or above the column's own
   * height is dropped: an opening must be strictly below `t` (13.1), and a mask that says otherwise would make the
   * renderer disagree with the stepper about where the wall is.
   */
  function openMask(parsed) {
    var w = parsed.size.w, d = parsed.size.d, out = new Uint8Array(w * d), any = false, x, y, k, m, list, i, e, lv;
    function set(cx, cy, lvl) {
      if (!(cx >= 0 && cy >= 0 && cx < w && cy < d)) return;
      if (!(lvl >= 0 && lvl < 4)) return;
      if (lvl >= parsed.t[cy][cx]) return;             /* strictly below the column top, or it is not an opening */
      out[cy * w + cx] |= (1 << lvl);
      any = true;
    }
    if (typeof parsed.isOpen === 'function') {
      for (y = 0; y < d; y++) for (x = 0; x < w; x++) for (k = 0; k < parsed.t[y][x]; k++) if (parsed.isOpen(x, y, k)) set(x, y, k);
    }
    m = parsed.openMask || parsed.open || null;
    if (m && typeof m.length === 'number') {
      if (m.length === d && m[0] && typeof m[0] === 'object' && typeof m[0].length === 'number') {
        for (y = 0; y < d; y++) for (x = 0; x < w; x++) for (k = 0; k < 4; k++) if ((m[y][x] | 0) & (1 << k)) set(x, y, k);
      } else if (m.length === w * d) {
        for (y = 0; y < d; y++) for (x = 0; x < w; x++) for (k = 0; k < 4; k++) if ((m[y * w + x] | 0) & (1 << k)) set(x, y, k);
      }
    }
    list = parsed.openings || (parsed.raw && parsed.raw.openings) || null;
    if (list && typeof list.length === 'number') {
      for (i = 0; i < list.length; i++) {
        e = list[i];
        if (!e || typeof e !== 'object') continue;
        if (typeof e.mask === 'number') { for (k = 0; k < 4; k++) if (e.mask & (1 << k)) set(e.x, e.y, k); }
        if (typeof e.level === 'number') set(e.x, e.y, e.level);
        if (e.levels && typeof e.levels.length === 'number') for (lv = 0; lv < e.levels.length; lv++) set(e.x, e.y, e.levels[lv]);
      }
    }
    return { mask: out, any: any, w: w, d: d };
  }

  /* The FLAT light leak of DESIGN.md 13.3, drawn once into a canvas and reused by every opened column: a soft round
   * halo with a four-point gleam over it - the shape light makes, not an icon. Greyscale, so the material's colour
   * tints it and one texture serves any palette. Direction- and level-neutral by construction: the star is
   * symmetric under a quarter turn, so it cannot suggest a heading, and it carries no vertical reading at all (see
   * theme.terrain.lightLeak for the rest of the reasoning). */
  function leakTexture(theme) {
    var L = theme.terrain.lightLeak, s = L.texturePx, c = makeCanvas(s, s), ctx = c.getContext('2d');
    var q = L.quadCells, half = s / 2, px = s / q, i, ang, rad;
    var outer = (L.spanCells / 2) * px, waist = Math.max(1, (L.waistCells / 2) * px), dot = (L.coreDotCells / 2) * px;
    var g = ctx.createRadialGradient(half, half, 0, half, half, half);
    g.addColorStop(0, 'rgba(255,255,255,' + L.haloOpacity + ')');
    g.addColorStop(0.42, 'rgba(255,255,255,' + (L.haloOpacity * 0.30).toFixed(4) + ')');
    g.addColorStop(1, 'rgba(255,255,255,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, s, s);
    ctx.save();
    ctx.shadowColor = 'rgba(255,255,255,0.85)';
    ctx.shadowBlur = L.softPx * (s / 128);
    ctx.fillStyle = 'rgba(255,255,255,' + L.coreOpacity + ')';
    ctx.beginPath();
    for (i = 0; i < 8; i++) {                       /* 4 tapered spikes: N, E, S, W with a narrow waist between */
      ang = -Math.PI / 2 + i * Math.PI / 4;
      rad = (i % 2 === 0) ? outer : waist;
      ctx[i ? 'lineTo' : 'moveTo'](half + Math.cos(ang) * rad, half + Math.sin(ang) * rad);
    }
    ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.arc(half, half, dot, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    var tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  /* ---- DARKNESS (DESIGN.md 15) ----------------------------------------------------------------------------
   * Fog of war as ONE TEXTURE, not as geometry. The obvious implementation - rebuild the terrain for the known set
   * whenever a cell is learned - would re-merge and re-upload the whole board thirty times during a single shot,
   * which is exactly the per-tap hitch the rest of this renderer is built to avoid. Instead the board's knowledge
   * lives in a w x d byte texture (a 24x24 board is 2.3 KB) that every fogged material samples:
   *
   *   red channel = 0   the cell is unknown: its terrain, its pieces and its light leak are not drawn at all,
   *                     its ground is painted theme.terrain.darkness.unknownColor and its grid outline lies flat
   *                     on the board's ground plane, which is the "you can always see WHERE the world is" of 15.1.
   *   red channel = 255 the cell is known: it renders EXACTLY as it would on a lit board (15.1's last rule), so
   *                     the flat view's deception is untouched - the fog gates WHEN, never HOW.
   *   in between        the ~400 ms arrival: the ground brightens, the column grows up out of it and the outline
   *                     rides up with it. The stagger is free - main learns a cell as the travelling beam head
   *                     reaches its centre, so a shot peels the board open along its own path.
   *
   * The value is sampled TWICE per fogged material: once in the vertex shader (only where geometry has to move,
   * and only if the GL can do a vertex texture fetch - see setRise) and once in the fragment shader, from an
   * INTERPOLATED board position rather than a varying of the vertex's own value. That second sample is what makes
   * the single four-vertex ground slab correct: its corners are the board's corners, so a varying would smear one
   * gradient across the whole board instead of resolving per cell.
   */
  function createFog(theme) {
    var D = theme.terrain.darkness, C = D.unknownColorVec3;
    var w = 1, d = 1, dark = false, instant = false;
    var val = new Float32Array(1);     /* per cell, 0 unknown .. 1 known */
    var live = [];                     /* indices still easing, so isAnimating() is O(1) */
    var count = 0;                     /* cells whose goal is 1 (known), animating or not */
    var data = new Uint8Array(4);
    var tex = new THREE.DataTexture(data, 1, 1, THREE.RGBAFormat, THREE.UnsignedByteType);
    tex.magFilter = THREE.NearestFilter; tex.minFilter = THREE.NearestFilter;
    tex.wrapS = THREE.ClampToEdgeWrapping; tex.wrapT = THREE.ClampToEdgeWrapping;
    tex.generateMipmaps = false; tex.flipY = false; tex.needsUpdate = true;
    markShared(tex);
    /* ONE uniform object per name, shared by every fogged material: three reads `.value` each frame, so a single
     * assignment here reaches all of them (the same trick render-terrain's uReveal and render-beam's uHead use). */
    var uniforms = {
      uFogMap: { value: tex },
      uFogSize: { value: new THREE.Vector2(1, 1) },
      uFogOn: { value: 0 },
      uFogRise: { value: 1 },
      uFogDark: { value: new THREE.Vector3(C[0], C[1], C[2]) },
      uFogGrid: { value: D.unknownGridLevel },
      uFogMin: { value: D.minVisible },
      uFogGround: { value: D.gridKnownAt }
    };

    function alloc(W, H) {
      if (W === w && H === d) return;
      w = W; d = H;
      val = new Float32Array(w * d);
      data = new Uint8Array(w * d * 4);
      tex.dispose();
      tex = new THREE.DataTexture(data, w, d, THREE.RGBAFormat, THREE.UnsignedByteType);
      tex.magFilter = THREE.NearestFilter; tex.minFilter = THREE.NearestFilter;
      tex.wrapS = THREE.ClampToEdgeWrapping; tex.wrapT = THREE.ClampToEdgeWrapping;
      tex.generateMipmaps = false; tex.flipY = false;
      markShared(tex);
      uniforms.uFogMap.value = tex;
      uniforms.uFogSize.value.set(w, d);
    }
    function writeTexel(i) {
      var v = Math.round(clamp(val[i], 0, 1) * 255), o = i * 4;
      data[o] = v; data[o + 1] = v; data[o + 2] = v; data[o + 3] = 255;
    }
    function flush() { tex.needsUpdate = true; }
    function paintAll() { for (var i = 0; i < w * d; i++) writeTexel(i); flush(); }

    /* A dark level starts with every cell at 0 and is told its seed set (the emitter and the targets, 15.1) plus
     * whatever the player already knew. A LIT level is simply every cell at 1 with uFogOn 0, so the fogged shaders
     * are inert and cost one uniform compare. */
    function setBoard(W, H, isDark) {
      alloc(W, H);
      dark = !!isDark;
      live.length = 0; count = 0;
      var i, n = w * d, v = dark ? 0 : 1;
      for (i = 0; i < n; i++) val[i] = v;
      if (!dark) count = n;
      uniforms.uFogOn.value = dark ? 1 : 0;
      paintAll();
    }
    function index(x, y) {
      x = Math.round(x); y = Math.round(y);
      if (x < 0 || y < 0 || x >= w || y >= d) return -1;
      return y * w + x;
    }
    /* `now` skips the arrival animation: used for the cells a level opens with, for a restored save and whenever
     * prefers-reduced-motion is on. Discovery only ever accumulates (15.1), so there is no un-learn. */
    function learn(x, y, now) {
      var i = index(x, y);
      if (i < 0 || val[i] >= 1) return false;
      if (val[i] === 0) count++;
      if (now || instant) { val[i] = 1; writeTexel(i); flush(); return true; }
      if (live.indexOf(i) < 0) live.push(i);
      return true;
    }
    function learnAll(cells, now) {
      var changed = false, i;
      if (!cells) return false;
      for (i = 0; i < cells.length; i++) {
        if (!cells[i]) continue;
        if (learn(cells[i].x, cells[i].y, now)) changed = true;
      }
      return changed;
    }
    function step(dt) {
      if (!live.length) return false;
      var ms = Math.max(1, D.revealMs), i, k;
      for (i = live.length - 1; i >= 0; i--) {
        k = live[i];
        val[k] += dt * 1000 / ms;
        if (val[k] >= 1) { val[k] = 1; live.splice(i, 1); }
        writeTexel(k);
      }
      flush();
      return true;
    }
    function isAnimating() { return live.length > 0; }
    function value(x, y) { var i = index(x, y); return i < 0 ? 0 : val[i]; }
    function known(x, y) { var i = index(x, y); return i >= 0 && val[i] > 0; }
    /* Vertex texture fetch is what lets the column grow and the outline ride up. Every GL this game ships on has
     * it; a hypothetical one that does not still gets the whole fog, just without the geometry moving. */
    function setRise(on) { uniforms.uFogRise.value = on ? 1 : 0; }
    function setInstant(on) {
      instant = !!on;
      if (instant && live.length) { while (live.length) { var i = live.pop(); val[i] = 1; writeTexel(i); } flush(); }
    }
    function dispose() { tex.dispose(); }

    return { __version: 1, uniforms: uniforms, setBoard: setBoard, learn: learn, learnAll: learnAll, step: step,
      isAnimating: isAnimating, value: value, known: known, setRise: setRise, setInstant: setInstant,
      isDark: function () { return dark; }, count: function () { return count; },
      total: function () { return w * d; }, size: function () { return { w: w, d: d }; }, dispose: dispose };
  }

  /* GLSL the fogged materials share. `mode` says what the VERTEX shader does with the value:
   *   'none'  nothing moves (the ground slab: it IS the board's ground plane)
   *   'rise'  transformed.y *= k       (terrain tops, sides and light leaks grow out of the ground)
   *   'lift'  transformed.y = mix(ground, transformed.y, k)   (the grid outline, which is drawn at the column's
   *           own top on a lit board and must lie on the ground plane until the cell is known - 15.1)
   * and `tint` what the FRAGMENT shader does with it:
   *   'mix'    toward the fog colour, and GONE below uFogMin - the terrain proper, which 15.1 says is simply not
   *            drawn until the beam has been there
   *   'ground' toward the fog colour and never gone: the board's ground plane, which is the surface an unknown
   *            cell still shows (and must, or the page's own background shows through and an unexplored board
   *            comes out BRIGHTER than an explored one)
   *   'grid'   toward the fog colour, but only as far as uFogGrid, so the outline is ALWAYS drawn
   *   'alpha'  scale colour and alpha (the additive light leak, which cannot be darkened by mixing)
   * The fragment always re-samples from the interpolated board position, never from a varying of the vertex's own
   * value: the ground slab has four vertices and the whole board between them.
   */
  function fogShader(shader, fog, mode, tint) {
    var u = fog.uniforms, k;
    for (k in u) if (Object.prototype.hasOwnProperty.call(u, k)) shader.uniforms[k] = u[k];
    var head = 'uniform sampler2D uFogMap;\nuniform vec2 uFogSize;\nuniform float uFogOn;\nuniform float uFogRise;\n' +
      'uniform vec3 uFogDark;\nuniform float uFogGrid;\nuniform float uFogMin;\nuniform float uFogGround;\n' +
      'varying vec2 vFogPos;\n';
    var vert = '\n vFogPos = vec2(position.x, -position.z);\n';
    if (mode !== 'none') {
      vert += ' if (uFogOn > 0.5 && uFogRise > 0.5) {\n' +
        '   float fk = texture2D(uFogMap, (floor(vFogPos + 0.5) + 0.5) / uFogSize).r;\n' +
        (mode === 'lift' ? '   transformed.y = mix(uFogGround, transformed.y, fk);\n' : '   transformed.y *= fk;\n') +
        ' }\n';
    }
    shader.vertexShader = head + shader.vertexShader.replace('#include <begin_vertex>', '#include <begin_vertex>' + vert);
    var frag = '\n if (uFogOn > 0.5) {\n' +
      '   float fk = texture2D(uFogMap, (floor(vFogPos + 0.5) + 0.5) / uFogSize).r;\n';
    if (tint === 'grid') frag += '   gl_FragColor.rgb = mix(uFogDark, gl_FragColor.rgb, mix(uFogGrid, 1.0, fk));\n';
    else if (tint === 'ground') frag += '   gl_FragColor.rgb = mix(uFogDark, gl_FragColor.rgb, fk);\n';
    else if (tint === 'alpha') frag += '   if (fk < uFogMin) discard;\n   gl_FragColor.rgb *= fk;\n   gl_FragColor.a *= fk;\n';
    else frag += '   if (fk < uFogMin) discard;\n   gl_FragColor.rgb = mix(uFogDark, gl_FragColor.rgb, fk);\n';
    frag += ' }\n';
    shader.fragmentShader = head + shader.fragmentShader.replace('#include <dithering_fragment>', '#include <dithering_fragment>' + frag);
    return shader;
  }

  /* Soft radial glow (halo) or a starburst with `streaks` glass-like rays. */
  function glowTexture(color, streaks) {
    var s = 128, c = makeCanvas(s, s), ctx = c.getContext('2d'), i;
    var g = ctx.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    g.addColorStop(0, 'rgba(255,255,255,1)');
    g.addColorStop(0.25, color);
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, s, s);
    if (streaks) {
      ctx.translate(s / 2, s / 2);
      ctx.strokeStyle = 'rgba(255,255,255,0.85)'; ctx.lineWidth = 2;
      for (i = 0; i < streaks; i++) {
        ctx.beginPath(); ctx.moveTo(0, 6); ctx.lineTo(0, s / 2 - 2); ctx.stroke();
        ctx.rotate(Math.PI * 2 / streaks);
      }
    }
    var tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    return tex;
  }

  /* Resource ownership. Module-level geometries / materials / textures that many meshes reuse are flagged with
   * `userData.shared = true` (markShared) and are NEVER disposed by disposeObject/clearGroup; only the module that
   * created them disposes them in its own dispose(). Everything else (per-piece, per-effect, per-target) is owned
   * by the object and freed with it. Disposing a shared material makes three.js recompile its shader program on
   * the next frame (a per-tap hitch); disposing a shared texture forces a re-upload. */
  function markShared(r) { if (r && r.userData) r.userData.shared = true; return r; }
  function isShared(r) { return !!(r && r.userData && r.userData.shared === true); }
  function markSharedAll(list) { for (var i = 0; i < list.length; i++) markShared(list[i]); return list; }

  function disposeObject(obj) {
    obj.traverse(function (o) {
      if (o.geometry && !o.isSprite && !isShared(o.geometry)) o.geometry.dispose();   /* Sprite.geometry is three's own shared quad */
      if (o.material) {
        var mats = Array.isArray(o.material) ? o.material : [o.material];
        for (var i = 0; i < mats.length; i++) {
          if (isShared(mats[i])) continue;
          if (mats[i].map && !isShared(mats[i].map)) mats[i].map.dispose();
          mats[i].dispose();
        }
      }
    });
  }

  function clearGroup(group) {
    while (group.children.length) { var c = group.children[group.children.length - 1]; group.remove(c); disposeObject(c); }
  }

  /* Monotone-chain convex hull of [x0,y0, x1,y1, ...] -> the same flat form, counter-clockwise, no duplicate end.
   * Used to shrink the camera-fit candidate set: the maximum of a linear function over a point set is attained on
   * its hull, so a 24x24 board's 2304 top-face corners collapse to a handful of points per height level. */
  function convexHull2D(pts) {
    var n = pts.length / 2, i, idx = [];
    for (i = 0; i < n; i++) idx.push(i);
    idx.sort(function (a, b) { return pts[a * 2] - pts[b * 2] || pts[a * 2 + 1] - pts[b * 2 + 1]; });
    /* dedup */
    var uniq = [];
    for (i = 0; i < idx.length; i++) {
      var j = idx[i];
      if (uniq.length && pts[uniq[uniq.length - 1] * 2] === pts[j * 2] && pts[uniq[uniq.length - 1] * 2 + 1] === pts[j * 2 + 1]) continue;
      uniq.push(j);
    }
    if (uniq.length < 3) { var out0 = []; for (i = 0; i < uniq.length; i++) out0.push(pts[uniq[i] * 2], pts[uniq[i] * 2 + 1]); return out0; }
    function cross(o, a, b) {
      return (pts[a * 2] - pts[o * 2]) * (pts[b * 2 + 1] - pts[o * 2 + 1]) - (pts[a * 2 + 1] - pts[o * 2 + 1]) * (pts[b * 2] - pts[o * 2]);
    }
    var lower = [], upper = [];
    for (i = 0; i < uniq.length; i++) {
      while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], uniq[i]) <= 0) lower.pop();
      lower.push(uniq[i]);
    }
    for (i = uniq.length - 1; i >= 0; i--) {
      while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], uniq[i]) <= 0) upper.pop();
      upper.push(uniq[i]);
    }
    lower.pop(); upper.pop();
    var hull = lower.concat(upper), out = [];
    for (i = 0; i < hull.length; i++) out.push(pts[hull[i] * 2], pts[hull[i] * 2 + 1]);
    return out;
  }

  function smoothstep(a, b, x) { var t = (x - a) / (b - a); t = t < 0 ? 0 : (t > 1 ? 1 : t); return t * t * (3 - 2 * t); }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }

  root.LaserRenderCore = {
    __version: 1,
    world: world, matFromSpec: matFromSpec, grainTexture: grainTexture,
    mergeGeometries: mergeGeometries, boxAt: boxAt,
    badgeTexture: badgeTexture, glowTexture: glowTexture, leakTexture: leakTexture, openMask: openMask,
    createFog: createFog, fogShader: fogShader,
    disposeObject: disposeObject, clearGroup: clearGroup, smoothstep: smoothstep, clamp: clamp, convexHull2D: convexHull2D,
    markShared: markShared, markSharedAll: markSharedAll, isShared: isShared
  };
}(typeof self !== 'undefined' ? self : this));
