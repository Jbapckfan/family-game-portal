/* Two playable decks, with apertures shared by the rules and the drawing. No idle animation. */
(function (root) {
  'use strict';
  function create(level) {
    var THREE = root.THREE, Core = root.LaserRenderCore, Sim = root.LaserSim;
    var group = new THREE.Group(); group.name = 'two-sided-board';
    var upper = new THREE.Group(), lower = new THREE.Group(); upper.name='upper-deck'; lower.name='lower-deck';
    group.add(upper,lower);
    var materials=[], buckets={}, fade=1, target=1, active='above', ray=new THREE.Raycaster(), bounds=new THREE.Box3(), hit=new THREE.Vector3();
    function material(color,metal,emissive) {
      var m=new THREE.MeshStandardMaterial({color:color,roughness:0.38,metalness:metal||0,emissive:emissive||0,emissiveIntensity:0.6});
      m.userData.shared=true;materials.push(m);return m;
    }
    var top=material('#25435b',0.55),base=material('#102235',0.7),edge=material('#447589',0.75),glow=material('#93fff2',0.25,'#30e6d2');
    var lowTop=material('#193f53',0.5),lowBase=material('#0b1f32',0.6),lowGrid=material('#34778b',0.65),gold=material('#ffe0a2',0.5,'#ba7e35');
    function box(parent,mat,x,h,y,w,d,tall) {
      var k=parent.uuid+':'+mat.uuid;
      if(!buckets[k])buckets[k]={parent:parent,mat:mat,geos:[]};
      buckets[k].geos.push(Core.boxAt(x,h,-y,w,tall,d));
    }
    var w=level.size.w,d=level.size.d;
    for(var y=0;y<d;y++)for(var x=0;x<w;x++) {
      if(!Sim.inHole(level,x,y,0)) {
        var h=level.t[y][x];
        box(upper,base,x,(h-0.18)/2,y,1,1,h+0.18);
        box(upper,top,x,h+0.012,y,0.96,0.96,0.024);
      }
      var z=Sim.heightAt(level,x,y,'below');
      box(lower,lowBase,x,(-4.22+z)/2,y,1,1,z+4.22);
      box(lower,lowTop,x,z+0.012,y,0.96,0.96,0.024);
    }
    function border(parent,mat,h,x,y,bw,bd,thick) {
      box(parent,mat,x,h,y-bd/2,bw+thick,thick,thick);
      box(parent,mat,x,h,y+bd/2,bw+thick,thick,thick);
      box(parent,mat,x-bw/2,h,y,thick,bd,thick);
      box(parent,mat,x+bw/2,h,y,thick,bd,thick);
    }
    border(upper,edge,-0.04,(w-1)/2,(d-1)/2,w,d,0.10);
    border(lower,lowGrid,-4.04,(w-1)/2,(d-1)/2,w,d,0.10);
    level.duplex.holes.forEach(function(h) {
      var cx=h.x+(h.w-1)/2,cy=h.y+(h.d-1)/2;
      // The inner edge is outside the geometric aperture, so the beam really clears it.
      border(group,edge,-0.06,cx,cy,h.w+0.09,h.d+0.09,0.09);
      border(group,glow,0.005,cx,cy,h.w+0.04,h.d+0.04,0.025);
      border(group,gold,-0.17,cx,cy,h.w+0.04,h.d+0.04,0.025);
    });
    [[-0.64,-0.64],[w-0.36,-0.64],[-0.64,d-0.36],[w-0.36,d-0.36]].forEach(function(c) {
      box(group,edge,c[0],-2,c[1],0.13,0.13,4.18);
      for(var h=-4;h<=0;h++)box(group,h===0?glow:gold,c[0],h,c[1],0.23,0.23,0.045);
    });
    Object.keys(buckets).forEach(function(k){var b=buckets[k],g=Core.mergeGeometries(b.geos);b.geos.forEach(function(g){g.dispose();});var m=new THREE.Mesh(g,b.mat);m.castShadow=true;m.receiveShadow=true;b.parent.add(m);});
    var upperMats=[top,base,edge];
    // edge is shared with the structural rails; clone only the fading upper meshes.
    upper.children.forEach(function(m){m.castShadow=false;m.material=m.material.clone();m.material.userData.shared=true;m.material.transparent=true;materials.push(m.material);});
    upperMats=upper.children.map(function(m){return m.material;});
    function frame(dt,elevation,reduced) {
      target=active==='below'?0.035:0.48+0.52*Core.smoothstep(65,90,elevation);
      var step=reduced?1:Math.max(0,dt||0)*5;
      fade+=Math.sign(target-fade)*Math.min(Math.abs(target-fade),step);
      upperMats.forEach(function(m){m.opacity=fade;m.transparent=true;m.depthWrite=fade>0.95;});
      // The cutaway deck must not leave an opaque silhouette in the cached shadow map.
      upper.children.forEach(function(m){m.castShadow=false;});
    }
    function pick(nx,ny,camera) {
      ray.setFromCamera(new THREE.Vector2(nx,ny),camera);
      var o=ray.ray.origin,v=ray.ray.direction,best=Infinity,cell=null;
      if(v.y>=-1e-6)return null;
      for(var y=0;y<d;y++)for(var x=0;x<w;x++) {
        if(active==='above'&&Sim.inHole(level,x,y,0))continue;
        var h=Sim.heightAt(level,x,y,active),base=active==='below'?-4.22:-0.18;
        bounds.min.set(x-0.5,base,-y-0.5);bounds.max.set(x+0.5,h+0.024,-y+0.5);
        if(!ray.ray.intersectBox(bounds,hit))continue;
        var distance=o.distanceToSquared(hit);
        if(distance<best){best=distance;cell={x:x,y:y};if(active==='below')cell.side='below';}
      }
      return cell;
    }
    var points=[];
    [-0.8,w-0.2].forEach(function(x){[-0.8,d-0.2].forEach(function(y){[-4.3,Math.max.apply(null,level.t.flat())+1.2].forEach(function(h){points.push(x,h,-y);});});});
    return {group:group,pick:pick,fitPoints:points,frame:frame,
      setLayer:function(side){active=side==='below'?'below':'above';target=active==='below'?0.035:1;},
      needsFrame:function(){return Math.abs(target-fade)>0.001;},
      dispose:function(){materials.forEach(function(m){m.dispose();});}};
  }
  root.LaserRenderDuplex={create:create};
}(typeof self!=='undefined'?self:this));
