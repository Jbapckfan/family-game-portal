import {test} from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {solve,proveMinimal} from '../solver.mjs';
const require=createRequire(import.meta.url),Sim=require('../src/sim.js'),levels=require('../src/levels.js'),P=require('../src/progress.js');
const chapter=levels.filter(l=>l.duplex),copy=x=>JSON.parse(JSON.stringify(x));
for(const raw of chapter)test(raw.name+': crossings, legal solution, minimum par and required openings',()=>{
 const L=Sim.parseLevel(raw),placed=[];
 for(const p of raw.solution){assert.ok(Sim.canPlace(L,placed,p.x,p.y,p.side));placed.push(p);}
 const r=Sim.trace(L,placed);assert.ok(r.allTargetsHit);assert.ok(r.visited.some(v=>v.z<0));assert.ok(r.events.some(e=>e.kind==='crossing'));
 assert.ok(proveMinimal(raw,raw.par,{maxNodes:200000}).proven);
 const sealed=copy(raw);sealed.duplex.holes=[{x:0,y:10,w:2,d:2}];
 const solutions=solve(raw,{maxSolutions:Infinity,maxNodes:200000});assert.equal(solutions.truncated,false);assert.ok(solutions.solutions.every(p=>Sim.trace(raw,p).events.some(e=>e.kind==='crossing')));
 assert.equal(Sim.trace(sealed,raw.solution).allTargetsHit,false);
 assert.equal(P.fingerprint(raw),P.fingerprint(L));
 const saved={f:P.fingerprint(L),placed:raw.solution,camera:{layer:'below'}};
 assert.deepEqual(P.attempt(saved,L,Sim).placed,raw.solution);
});
test('round trip actually crosses downward and upward; split reaches both sides',()=>{
 assert.deepEqual(Sim.trace(chapter[1],chapter[1].solution).events.filter(e=>e.kind==='crossing').map(e=>e.side),['below','above']);
 const r=Sim.trace(chapter[3],chapter[3].solution);assert.ok(r.branched);assert.equal(r.hits.length,2);
});
test('same square supports independent pieces on each deck',()=>{
 const L=Sim.parseLevel(chapter[0]),upper={x:3,y:5,type:'MIRROR',orient:'/'},lower={...upper,side:'below',type:'WEDGE'};
 assert.ok(Sim.canPlace(L,[upper],3,5,'below'));assert.ok(Sim.canPlace(L,[lower],3,5));
 assert.equal(Sim.canPlace(L,[lower],3,5,'below'),false);assert.ok(Sim.trace(L,[upper,lower]).allTargetsHit);
 assert.equal(Sim.heightAt(L,3,5),0);assert.equal(Sim.heightAt(L,3,5,'below'),-2);
 const p={f:P.fingerprint(L),placed:[upper,lower]};const withTray={...chapter[0],tray:['MIRROR','WEDGE']};p.f=P.fingerprint(withTray);assert.equal(P.attempt(p,withTray,Sim).placed.length,2);
});
test('hole squares have no upper placement; lower layer remains usable beneath an aperture',()=>{
 const L=Sim.parseLevel(chapter[0]);assert.equal(Sim.canPlace(L,[],3,3),false);assert.equal(Sim.canPlace(L,[],3,3,'below'),true);
 assert.equal(Sim.canPlace(levels[0],[],2,2,'below'),false);assert.equal(Sim.canPlace(L,[],2,2,'other'),false);
});
test('board blocks a crossing at the real half-step intersection, not just a destination cell',()=>{
 const raw=copy(chapter[0]);raw.duplex.holes=[{x:3,y:4,w:2,d:2}]; // end cell is open, crossing lies on its solid edge
 const r=Sim.trace(raw,raw.solution);assert.equal(r.end,'blocked-board');assert.equal(r.endPoint.z,-0.5);assert.equal(r.endPoint.y,3.5);
});
test('parser rejects floating actors, overlapping apertures, invalid sides and lower terrain reaching the slab',()=>{
 for(const mutate of [l=>l.emitter.side='elsewhere',l=>l.duplex.lower[0]='333333333333',l=>l.duplex.holes.push(l.duplex.holes[0]),l=>l.targets.push({x:3,y:3}),l=>l.duplex.holes[0].w=99]){
  const l=copy(chapter[0]);mutate(l);assert.throws(()=>Sim.parseLevel(l));
 }
 const l=copy(levels[0]);l.emitter.side='below';assert.throws(()=>Sim.parseLevel(l));
});
test('save fingerprints include lower terrain and hole locations, and attempts reject stale deck geometry',()=>{
 const l=copy(chapter[0]),f=P.fingerprint(l);l.duplex.lower[0]='100000000000';assert.notEqual(P.fingerprint(l),f);
 const a={f,placed:chapter[0].solution};assert.equal(P.attempt(a,l,Sim),null);
 const moved=copy(chapter[0]);moved.duplex.holes[0].x++;assert.notEqual(P.fingerprint(moved),f);
});
