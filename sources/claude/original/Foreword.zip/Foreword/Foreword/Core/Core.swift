import Foundation
import SwiftUI

// MARK: - Daily clock

/// Puzzle numbering: No. 1 is the launch date, in the player's local calendar.
enum DailyClock {
    static let epoch: Date = {
        var c = DateComponents(); c.year = 2026; c.month = 10; c.day = 20
        return Calendar.current.date(from: c)!
    }()

    static func dayIndex(_ date: Date = .now) -> Int {
        let cal = Calendar.current
        return cal.dateComponents([.day], from: cal.startOfDay(for: epoch), to: cal.startOfDay(for: date)).day ?? 0
    }

    static func nextMidnight(after date: Date = .now) -> Date {
        let cal = Calendar.current
        return cal.date(byAdding: .day, value: 1, to: cal.startOfDay(for: date))!
    }

    static func countdownString(to date: Date, from now: Date = .now) -> String {
        let s = max(0, Int(date.timeIntervalSince(now)))
        return String(format: "%02d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
    }
}

// MARK: - Shared enums

enum GameStatus: String, Codable { case playing, won, lost }
enum PlayMode: String, Codable { case daily, practice }

enum GameID: String, CaseIterable, Identifiable, Codable {
    case dovetail, splice, sprout, tangle, keystone, tumbler
    var id: String { rawValue }

    var title: String {
        switch self {
        case .dovetail: "Dovetail"
        case .splice: "Splice"
        case .sprout: "Sprout"
        case .tangle: "Tangle"
        case .keystone: "Keystone"
        case .tumbler: "Tumbler"
        }
    }
    var tagline: String {
        switch self {
        case .dovetail: "Eight words. Each joins the next."
        case .splice: "Twelve halves. Six words. One way."
        case .sprout: "Grow a seed into a bloom."
        case .tangle: "Three words, shuffled together."
        case .keystone: "One hidden word holds five others up."
        case .tumbler: "Crack a five-letter lock by feel."
        }
    }
    var symbol: String {
        switch self {
        case .dovetail: "square.stack.3d.down.right"
        case .splice: "film.stack"
        case .sprout: "leaf"
        case .tangle: "point.3.connected.trianglepath.dotted"
        case .keystone: "building.columns"
        case .tumbler: "lock.rotation"
        }
    }
    var palette: Palette { Palette.of(self) }
}

// MARK: - Palettes

struct Palette {
    let bg: Color, surface: Color, fg: Color, muted: Color, line: Color
    let accent: Color, accentInk: Color, good: Color, goodInk: Color, warn: Color, warnInk: Color, bad: Color, key: Color

    static func of(_ g: GameID) -> Palette {
        switch g {
        case .dovetail:
            Palette(bg: .adaptive(0xE6EAE4, 0x1A1F1B), surface: .adaptive(0xFBFBF9, 0x252B26), fg: .adaptive(0x1E2722, 0xEDEBE3),
                    muted: .adaptive(0x66716B, 0x9BA69E), line: .adaptive(0xC9D1CB, 0x3A423B),
                    accent: .adaptive(0xD65A2C, 0xF27A4E), accentInk: .white, good: .adaptive(0xCD8F4E, 0xC9894A), goodInk: .adaptive(0x3B2410, 0x2A1708),
                    warn: .adaptive(0xD99A12, 0xF1B83A), warnInk: .adaptive(0x5A3E00, 0x2A1D00), bad: .adaptive(0xD04444, 0xF06A6A), key: .adaptive(0xD3DBD4, 0x343C36))
        case .splice:
            Palette(bg: .adaptive(0xEDF0F2, 0x111417), surface: .adaptive(0xFFFFFF, 0x1B2025), fg: .adaptive(0x121519, 0xE8EBEE),
                    muted: .adaptive(0x687079, 0x8E969E), line: .adaptive(0xC7CED5, 0x343B42),
                    accent: .adaptive(0x0E97A3, 0x30CCD8), accentInk: .adaptive(0xFFFFFF, 0x06282B), good: .adaptive(0xD3EEF0, 0x103D42), goodInk: .adaptive(0x0B4E55, 0xBFF0F4),
                    warn: .adaptive(0xD99A12, 0xF1B83A), warnInk: .adaptive(0x5A3E00, 0x2A1D00), bad: .adaptive(0xD04444, 0xF06A6A), key: .adaptive(0xD9DEE3, 0x2A3138))
        case .sprout:
            Palette(bg: .adaptive(0xE6EEE8, 0x0F1712), surface: .adaptive(0xFFFFFF, 0x18231B), fg: .adaptive(0x13211A, 0xE7EFE9),
                    muted: .adaptive(0x5F7367, 0x8DA394), line: .adaptive(0xBFCFC4, 0x2E3E33),
                    accent: .adaptive(0x1F7D4F, 0x3FB874), accentInk: .adaptive(0xFFFFFF, 0x06301A), good: .adaptive(0xCFE9D8, 0x1C3A28), goodInk: .adaptive(0x13211A, 0xE7EFE9),
                    warn: .adaptive(0xD7A11C, 0xF0B93C), warnInk: .adaptive(0x4A3600, 0x3A2900), bad: .adaptive(0xD04444, 0xF06A6A), key: .adaptive(0xD3DFD7, 0x263128))
        case .tangle:
            Palette(bg: .adaptive(0xF0EDF6, 0x15121D), surface: .adaptive(0xFFFFFF, 0x201B2B), fg: .adaptive(0x241F30, 0xEEEAF6),
                    muted: .adaptive(0x6D6682, 0x9A93AE), line: .adaptive(0xCDC7DD, 0x39324F),
                    accent: .adaptive(0x5A49D6, 0x8C7CFF), accentInk: .adaptive(0xFFFFFF, 0x120A3A), good: .adaptive(0xDDD8F2, 0x2A2440), goodInk: .adaptive(0x241F30, 0xEEEAF6),
                    warn: .adaptive(0xD9A520, 0xF2C14E), warnInk: .adaptive(0x2E2300, 0x2E2300), bad: .adaptive(0xD04444, 0xF26D6D), key: .adaptive(0xDAD6E6, 0x2E2840))
        case .keystone:
            Palette(bg: .adaptive(0xE8ECEF, 0x14181C), surface: .adaptive(0xFBFBFC, 0x1E242A), fg: .adaptive(0x1B2229, 0xE9EEF2),
                    muted: .adaptive(0x5F6C78, 0x93A0AB), line: .adaptive(0xC5CED6, 0x303A44),
                    accent: .adaptive(0x2F6F8F, 0x5FB0D4), accentInk: .adaptive(0xFFFFFF, 0x06202C), good: .adaptive(0xD6E6EE, 0x16323F), goodInk: .adaptive(0x123A4D, 0xCFE8F2),
                    warn: .adaptive(0xC9892B, 0xE0A64A), warnInk: .adaptive(0x2A1D00, 0x2A1D00), bad: .adaptive(0xC04A3A, 0xF07A6A), key: .adaptive(0xD3DAE0, 0x2A323A))
        case .tumbler:
            // Tumbler is a vault: one dark look in both appearances.
            Palette(bg: .hex(0x16191D), surface: .hex(0x22272D), fg: .hex(0xECE6D6), muted: .hex(0x8E94A0), line: .hex(0x343B44),
                    accent: .hex(0xD9B35A), accentInk: .hex(0x2A1D00), good: .hex(0x3BAF73), goodInk: .hex(0x06301A),
                    warn: .hex(0xD9B35A), warnInk: .hex(0x2A1D00), bad: .hex(0xF07A6A), key: .hex(0x2E353E))
        }
    }
}

extension Color {
    static func adaptive(_ light: UInt32, _ dark: UInt32) -> Color {
        Color(uiColor: UIColor { trait in
            trait.userInterfaceStyle == .dark ? UIColor(hex: dark) : UIColor(hex: light)
        })
    }
    static func hex(_ v: UInt32) -> Color { Color(uiColor: UIColor(hex: v)) }
}

extension UIColor {
    convenience init(hex: UInt32) {
        self.init(red: CGFloat((hex >> 16) & 0xFF) / 255, green: CGFloat((hex >> 8) & 0xFF) / 255, blue: CGFloat(hex & 0xFF) / 255, alpha: 1)
    }
}

// MARK: - Persistence

enum Persist {
    static func save<T: Encodable>(_ value: T, key: String) {
        if let data = try? JSONEncoder().encode(value) { UserDefaults.standard.set(data, forKey: key) }
    }
    static func load<T: Decodable>(_ type: T.Type, key: String) -> T? {
        guard let data = UserDefaults.standard.data(forKey: key) else { return nil }
        return try? JSONDecoder().decode(T.self, from: data)
    }
    static func remove(key: String) { UserDefaults.standard.removeObject(forKey: key) }
}

// MARK: - Stats

struct GameStats: Codable {
    var played = 0
    var won = 0
    var streak = 0
    var maxStreak = 0
    var lastDay: Int? = nil
    var dist: [Int] = Array(repeating: 0, count: 7)

    var winPercent: Int { played == 0 ? 0 : Int((Double(won) / Double(played) * 100).rounded()) }

    /// Records a finished daily puzzle once; `bucket` is the mistake count to histogram on a win.
    mutating func record(day: Int, didWin: Bool, bucket: Int) {
        guard lastDay != day else { return }
        played += 1
        if didWin {
            won += 1
            streak = (lastDay == day - 1) ? streak + 1 : 1
            maxStreak = max(maxStreak, streak)
            dist[min(max(bucket, 0), dist.count - 1)] += 1
        } else {
            streak = 0
        }
        lastDay = day
    }
}

enum StatsStore {
    static func load(_ g: GameID) -> GameStats { Persist.load(GameStats.self, key: "stats.\(g.rawValue)") ?? GameStats() }
    static func save(_ s: GameStats, for g: GameID) { Persist.save(s, key: "stats.\(g.rawValue)") }
    static func record(_ g: GameID, day: Int, didWin: Bool, bucket: Int) {
        var s = load(g); s.record(day: day, didWin: didWin, bucket: bucket); save(s, for: g)
    }
}

/// A compact description of today's progress for the home screen.
struct DailySummary {
    var status: GameStatus
    var emoji: String
    var detail: String
}

// MARK: - Haptics

enum Haptics {
    static func tap() { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
    static func success() { UINotificationFeedbackGenerator().notificationOccurred(.success) }
    static func error() { UINotificationFeedbackGenerator().notificationOccurred(.error) }
    static func warning() { UINotificationFeedbackGenerator().notificationOccurred(.warning) }
}

// MARK: - Puzzle data

struct DovetailData: Decodable { let puzzles: [[String]]; let common: [String]; let fused: [String] }
struct SpliceData: Decodable { let puzzles: [[[String]]]; let fused: [String] }
struct SproutLevel: Decodable { let a: [String]; let d: [String] }
struct SproutPuzzle: Decodable { let seed: String; let pool: String; let levels: [String: SproutLevel] }
struct SproutData: Decodable { let puzzles: [SproutPuzzle] }
struct TanglePuzzle: Decodable { let s: String; let w: [String]; let o: [Int] }
struct TangleData: Decodable { let puzzles: [TanglePuzzle]; let dict: [String] }
struct KeystoneClue: Decodable { let w: String; let d: String }
struct KeystoneRound: Decodable { let k: String; let clues: [KeystoneClue] }
struct KeystoneData: Decodable { let days: [[KeystoneRound]] }
struct TumblerData: Decodable { let answers: [String]; let guess: [String] }

/// Loads the bundled puzzle banks once. Each bank is a JSON file produced by the generators in `tools/`.
final class PuzzleLibrary {
    static let shared = PuzzleLibrary()

    private(set) lazy var dovetail: DovetailData = load("dovetail")
    private(set) lazy var splice: SpliceData = load("splice")
    private(set) lazy var sprout: SproutData = load("sprout")
    private(set) lazy var tangle: TangleData = load("tangle")
    private(set) lazy var keystone: KeystoneData = load("keystone")
    private(set) lazy var tumbler: TumblerData = load("tumbler")
    private(set) lazy var tumblerGuess: Set<String> = Set(tumbler.guess)

    private(set) lazy var dovetailCommon: Set<String> = Set(dovetail.common)
    private(set) lazy var dovetailFused: Set<String> = Set(dovetail.fused)
    /// True if a + b or b + a is a word (used by Dovetail feedback and Keystone).
    func joins(_ a: String, _ b: String) -> Bool { dovetailFused.contains(a + b) || dovetailFused.contains(b + a) }
    private(set) lazy var spliceFused: Set<String> = Set(splice.fused)
    private(set) lazy var tangleDict: Set<String> = Set(tangle.dict)

    func count(_ g: GameID) -> Int {
        switch g {
        case .dovetail: dovetail.puzzles.count
        case .splice: splice.puzzles.count
        case .sprout: sprout.puzzles.count
        case .tangle: tangle.puzzles.count
        case .keystone: keystone.days.count
        case .tumbler: tumbler.answers.count
        }
    }

    /// Daily index into a bank: wraps once the bank is exhausted.
    func index(for day: Int, in g: GameID) -> Int {
        let n = count(g); return ((day % n) + n) % n
    }

    private func load<T: Decodable>(_ name: String) -> T {
        guard let url = Bundle.main.url(forResource: name, withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode(T.self, from: data) else {
            fatalError("Missing or malformed \(name).json in the app bundle")
        }
        return decoded
    }
}

// MARK: - Small helpers

extension String {
    var sortedLetters: String { String(sorted()) }
    subscript(i: Int) -> Character { self[index(startIndex, offsetBy: i)] }
}

extension Array where Element == Character {
    /// Removes one occurrence of each character in `other`; returns nil if any is missing.
    func removingAll(_ other: [Character]) -> [Character]? {
        var rest = self
        for c in other {
            guard let i = rest.firstIndex(of: c) else { return nil }
            rest.remove(at: i)
        }
        return rest
    }
}
