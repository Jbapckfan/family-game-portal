import SwiftUI

@main
struct ForewordApp: App {
    @State private var store = StoreManager()

    var body: some Scene {
        WindowGroup {
            HomeView()
                .environment(store)
                .task { await store.start() }
        }
    }
}
