import Foundation
import Observation

/// Dovetail: a chain of eight words; every adjacent pair, joined, spells a word.
@MainActor
@Observable
final class DovetailModel {
    static let maxMisses = 6

    struct Guess: Codable, Hashable { var w: String; var up: Bool; var down: Bool }

    struct State: Codable {
        var mode: PlayMode
        var day: Int
        var words: [String]
        var solved: [Bool]
        var guesses: [[Guess]]
        var hints: [Int]
        var misses: Int
        var status: GameStatus
        var active: Int
        var typed: String
    }

    enum Judgement {
        case short, dupe, notWord
        case solve(word: String, alternate: Bool)
        case miss(up: Bool, down: Bool, left: String?, right: String?)
    }

    private let lib = PuzzleLibrary.shared
    private(set) var st: State
    var toast: String?
    var shakeRow: Int = -1
    var shakeTick = 0
    var popRow: Int = -1
    private(set) var practiceIndex: Int? = nil

    var day: Int { st.day }
    var n: Int { st.words.count }
    var isPlaying: Bool { st.status == .playing }

    init(day: Int) {
        if let saved = Persist.load(State.self, key: "dovetail.day.\(day)"), saved.words.count >= 3 {
            st = saved
        } else {
            st = DovetailModel.newState(lib.dovetail.puzzles[lib.index(for: day, in: .dovetail)], mode: .daily, day: day)
        }
    }

    static func newState(_ words: [String], mode: PlayMode, day: Int) -> State {
        let n = words.count
        return State(mode: mode, day: day, words: words, solved: words.indices.map { $0 == 0 || $0 == n - 1 },
                     guesses: words.map { _ in [] }, hints: words.map { _ in 0 }, misses: 0, status: .playing, active: 1, typed: "")
    }

    /// Summary for the home screen without instantiating the whole model.
    static func summary(day: Int) -> DailySummary? {
        guard let s = Persist.load(State.self, key: "dovetail.day.\(day)") else { return nil }
        let solvedCount = s.solved.filter { $0 }.count - 2
        return DailySummary(status: s.status, emoji: emojiRow(s), detail: s.status == .playing ? "\(solvedCount) of \(s.words.count - 2) placed" : s.status == .won ? "\(s.misses) miss\(s.misses == 1 ? "" : "es")" : "Chain broke")
    }

    static func emojiRow(_ s: State) -> String {
        var out = ""
        for i in 1..<(s.words.count - 1) { out += !s.solved[i] ? "🟥" : (s.guesses[i].isEmpty && s.hints[i] == 0) ? "🟩" : "🟨" }
        return out
    }
    var emojiRow: String { DovetailModel.emojiRow(st) }

    // MARK: Judging

    func judge(_ word: String, row i: Int) -> Judgement {
        let sol = st.words[i]
        if word.count != sol.count { return .short }
        if st.guesses[i].contains(where: { $0.w == word }) { return .dupe }
        if word == sol { return .solve(word: word, alternate: false) }
        let left = st.solved[i - 1] ? st.words[i - 1] : nil
        let right = st.solved[i + 1] ? st.words[i + 1] : nil
        let fitUp = left.map { lib.dovetailFused.contains($0 + word) } ?? false
        let fitDown = right.map { lib.dovetailFused.contains(word + $0) } ?? false
        if left != nil, right != nil, fitUp, fitDown, lib.dovetailCommon.contains(word) { return .solve(word: word, alternate: true) }
        if !lib.dovetailCommon.contains(word) { return .notWord }
        return .miss(up: fitUp, down: fitDown, left: left, right: right)
    }

    // MARK: Input

    func key(_ k: String) {
        guard isPlaying, st.active >= 0 else { return }
        let len = st.words[st.active].count, h = st.hints[st.active]
        switch k {
        case "ENTER": submit()
        case "BACK": if st.typed.count > h { st.typed.removeLast() }
        default:
            if k.count == 1, k.first!.isLetter, st.typed.count < len { st.typed += k.lowercased() }
        }
    }

    func select(row i: Int) {
        guard isPlaying, !st.solved[i] else { return }
        st.active = i
        st.typed = st.words[i].prefix(st.hints[i]).lowercased()
    }

    func submit() {
        let i = st.active, word = st.typed
        switch judge(word, row: i) {
        case .short: toast = "Too short"; shake(i)
        case .dupe: toast = "Already tried"; shake(i)
        case .notWord: toast = "Not in word list"; shake(i)
        case .solve(let w, _):
            st.words[i] = w; st.solved[i] = true; st.typed = ""
            let up = st.solved[i - 1] ? (st.words[i - 1] + w).uppercased() : nil
            let down = st.solved[i + 1] ? (w + st.words[i + 1]).uppercased() : nil
            toast = [up, down].compactMap { $0 }.joined(separator: " · ")
            popRow = i
            Haptics.success()
            if st.solved.allSatisfy({ $0 }) { st.status = .won; finish() } else { st.active = nextOpen(from: i) }
        case .miss(let up, let down, let left, let right):
            st.guesses[i].append(Guess(w: word, up: up, down: down))
            st.misses += 1; st.typed = st.words[i].prefix(st.hints[i]).lowercased()
            let W = word.uppercased()
            if up && down { toast = "\((left! + word).uppercased()) and \((word + right!).uppercased()) are words, but not this chain" }
            else if up { toast = "\((left! + word).uppercased()) fits above, but \(W) doesn't reach below" }
            else if down { toast = "\((word + right!).uppercased()) fits below, but above doesn't reach \(W)" }
            else { toast = "\(W) joins neither side" }
            Haptics.error(); shake(i)
            if st.misses >= DovetailModel.maxMisses { st.status = .lost; finish() }
        }
        persist()
    }

    func hint() {
        guard isPlaying, st.active >= 0 else { return }
        let i = st.active, len = st.words[i].count
        guard st.hints[i] < len - 1 else { return }
        st.hints[i] += 1; st.misses += 1
        st.typed = st.words[i].prefix(st.hints[i]).lowercased()
        toast = "Letter revealed · 1 miss"
        if st.misses >= DovetailModel.maxMisses { st.status = .lost; finish() }
        persist()
    }

    var canHint: Bool { isPlaying && st.active >= 0 && st.hints[st.active] < st.words[st.active].count - 1 }

    func nextOpen(from: Int) -> Int {
        for k in 1..<n { let j = (from + k) % n; if !st.solved[j] { return j } }
        return -1
    }

    private func shake(_ i: Int) { shakeRow = i; shakeTick += 1 }

    private func finish() {
        if st.mode == .daily, st.day == DailyClock.dayIndex() { StatsStore.record(.dovetail, day: st.day, didWin: st.status == .won, bucket: st.misses) }
    }

    func persist() { if st.mode == .daily { Persist.save(st, key: "dovetail.day.\(st.day)") } }

    func startPractice() {
        let n = lib.dovetail.puzzles.count
        var idx: Int
        repeat { idx = Int.random(in: 0..<n) } while n > 1 && idx == lib.index(for: DailyClock.dayIndex(), in: .dovetail)
        practiceIndex = idx
        st = DovetailModel.newState(lib.dovetail.puzzles[idx], mode: .practice, day: st.day)
    }

    var shareText: String {
        let head = st.mode == .daily ? "Dovetail #\(st.day + 1)" : "Dovetail (practice)"
        let tail = st.status == .won ? "\(st.misses) miss\(st.misses == 1 ? "" : "es")" : "Chain broke ✕"
        return "\(head)\n\(emojiRow)\n\(tail)"
    }

    var resultTitle: String {
        switch st.status {
        case .won: st.misses == 0 ? "Flawless joinery." : st.misses <= 2 ? "Tight joints." : "Joined."
        case .lost: "The chain broke."
        case .playing: ""
        }
    }
}
