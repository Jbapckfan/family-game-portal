import SwiftUI

struct DovetailView: View {
    @State private var model: DovetailModel
    init(day: Int = DailyClock.dayIndex()) { _model = State(initialValue: DovetailModel(day: day)) }
    @Environment(StoreManager.self) private var store
    @State private var showHelp = !UserDefaults.standard.bool(forKey: "seen.dovetail")
    @State private var showResult = false
    @State private var showPaywall = false
    @State private var paywallReason: String? = nil
    private let p = GameID.dovetail.palette

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(spacing: 10) {
                    hud
                    chain
                    Text("Each word, joined to the next, spells a new word.")
                        .font(.footnote).foregroundStyle(p.muted).padding(.top, 4)
                }
                .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 12)
            }
            if model.isPlaying {
                KeyboardView(palette: p) { model.key($0) }
                    .padding(.horizontal, 8).padding(.top, 8).padding(.bottom, 6)
                    .background(p.bg.shadow(.drop(color: .black.opacity(0.08), radius: 8, y: -2)))
            }
        }
        .background(p.bg.ignoresSafeArea())
        .navigationTitle("Dovetail")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 4) {
                    Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }
                    Button { showResult = true } label: { Image(systemName: "chart.bar") }.disabled(model.isPlaying)
                }
            }
        }
        .toast($model.toast, palette: p)
        .onChange(of: model.st.status) { _, s in if s != .playing { Task { try? await Task.sleep(for: .seconds(0.9)); showResult = true } } }
        .onAppear { if !model.isPlaying { showResult = true } }
        .sheet(isPresented: $showHelp, onDismiss: { UserDefaults.standard.set(true, forKey: "seen.dovetail") }) { help }
        .sheet(isPresented: $showResult) { result }
        .sheet(isPresented: $showPaywall) { PaywallView(reason: paywallReason) }
    }

    // MARK: HUD

    private var hud: some View {
        HStack {
            HStack(spacing: 5) {
                ForEach(0..<DovetailModel.maxMisses, id: \.self) { i in
                    DovetailPin().fill(i < model.st.misses ? p.accent : p.line).frame(width: 13, height: 13)
                }
            }
            Text(model.st.status == .won ? "Joined!" : model.st.status == .lost ? "The chain broke" : "\(DovetailModel.maxMisses - model.st.misses) misses left")
                .font(.system(size: 13, weight: .medium)).foregroundStyle(p.muted)
            Spacer()
            Button {
                let ent = Entitlements(isPlus: store.isPlus)
                if ent.canHint(.dovetail, day: model.day) || model.st.mode == .practice {
                    if model.st.mode == .daily { Entitlements.noteHintUsed(.dovetail, day: model.day) }
                    model.hint()
                } else { paywallReason = "You've used today's free hint. Plus members get unlimited hints across all four games."; showPaywall = true }
            } label: {
                Text("Reveal a letter · costs 1").font(.system(size: 12, weight: .semibold))
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(p.surface, in: Capsule()).overlay(Capsule().stroke(p.line))
            }
            .foregroundStyle(p.fg)
            .disabled(!model.canHint)
            .opacity(model.canHint ? 1 : 0.45)
        }
    }

    // MARK: Chain

    private var chain: some View {
        VStack(spacing: -10) {
            ForEach(0..<model.n, id: \.self) { i in
                row(i)
            }
        }
    }

    @ViewBuilder
    private func row(_ i: Int) -> some View {
        let w = model.st.words[i]
        let known = model.st.solved[i]
        let given = i == 0 || i == model.n - 1
        let lost = model.st.status == .lost && !known
        let active = i == model.st.active && model.isPlaying
        VStack(spacing: 4) {
            HStack(spacing: 5) {
                ForEach(0..<w.count, id: \.self) { k in
                    let ch: String = {
                        if known || lost { return String(w[k]).uppercased() }
                        if k < model.st.hints[i] { return String(w[k]).uppercased() }
                        if active, k < model.st.typed.count { return String(model.st.typed[k]).uppercased() }
                        return ""
                    }()
                    let isHint = !known && !lost && k < model.st.hints[i]
                    let fill: Color = isHint ? p.warn : ((known || lost) ? Color.clear : p.surface)
                    let stroke: Color = {
                        if known || lost { return Color.clear }
                        if isHint { return p.warn }
                        if active && !ch.isEmpty { return p.fg }
                        return active ? p.muted : p.line
                    }()
                    let ink: Color = isHint ? p.warnInk : (lost ? p.accent : (known ? p.goodInk : p.fg))
                    Text(ch)
                        .font(.system(size: w.count > 8 ? 20 : 23, weight: .bold).width(.condensed))
                        .frame(width: w.count > 8 ? 32 : 36, height: 40)
                        .background(fill, in: RoundedRectangle(cornerRadius: 4))
                        .overlay(RoundedRectangle(cornerRadius: 4).stroke(stroke, lineWidth: 2))
                        .foregroundStyle(ink)
                }
            }
            .padding(.vertical, 12).padding(.horizontal, 10)
            .frame(maxWidth: .infinity)
            .background {
                if known || lost {
                    PlankShape(tab: i < model.n - 1, notch: i > 0)
                        .fill(lost ? AnyShapeStyle(p.line) : AnyShapeStyle(LinearGradient(colors: [p.good.opacity(0.75), p.good, p.good.opacity(0.7)], startPoint: .top, endPoint: .bottom)))
                        .opacity(given ? 0.92 : 1)
                }
            }
            .modifier(Shake(animatableData: CGFloat(model.shakeRow == i ? model.shakeTick : 0)))
            .animation(.default, value: model.shakeTick)
            .contentShape(Rectangle())
            .onTapGesture { model.select(row: i) }
            if !known && !lost && !model.st.guesses[i].isEmpty {
                FlowLayout(spacing: 5, lineSpacing: 5) {
                    ForEach(model.st.guesses[i], id: \.self) { g in
                        HStack(spacing: 2) {
                            if g.up { Text("▲").font(.system(size: 9)) }
                            Text(g.w.uppercased()).font(.system(size: 12, weight: .semibold).width(.condensed)).tracking(0.6)
                            if g.down { Text("▼").font(.system(size: 9)) }
                        }
                        .padding(.horizontal, 8).padding(.vertical, 2)
                        .background((g.up || g.down) ? p.warn : p.surface, in: Capsule())
                        .overlay(Capsule().stroke((g.up || g.down) ? p.warn : p.line))
                        .foregroundStyle((g.up || g.down) ? p.warnInk : p.muted)
                    }
                }
                .padding(.bottom, 6)
            }
            if (known || lost), i < model.n - 1, model.st.solved[i + 1] || model.st.status == .lost {
                HStack { Spacer()
                    Text((model.st.words[i] + model.st.words[i + 1]).uppercased())
                        .font(.system(size: 10, weight: .semibold)).tracking(1.2)
                        .padding(.horizontal, 8).padding(.vertical, 2)
                        .background(p.surface, in: Capsule()).overlay(Capsule().stroke(p.line))
                        .foregroundStyle(p.fg)
                }
                .padding(.trailing, 12)
                .offset(y: -12)
                .frame(height: 0)
                .zIndex(3)
            }
        }
        .zIndex(Double(model.n - i))
    }

    // MARK: Sheets

    private var help: some View {
        HowToSheet(game: .dovetail) {
            Text("Eight words stack into a chain. Each word, joined to the one below it, spells a new word. The top and bottom are given; fill in the six between.")
            VStack(spacing: 2) {
                Text("FIRE").font(.system(size: 20, weight: .bold).width(.condensed)).tracking(2)
                Text("fire + arm = firearm").font(.caption).foregroundStyle(p.muted)
                Text("ARM").font(.system(size: 20, weight: .bold).width(.condensed)).tracking(2).foregroundStyle(p.good)
                Text("arm + pit = armpit").font(.caption).foregroundStyle(p.muted)
                Text("PIT").font(.system(size: 20, weight: .bold).width(.condensed)).tracking(2)
            }.frame(maxWidth: .infinity)
            Text("Joins can be real compounds (BOOK+WORM) or pure spelling (CAR+PET, THIN+KING). Only the letters matter.")
            legend(p.good, "Correct. The planks join.")
            legend(p.warn, "Wrong, but it fits one neighbor. The chip shows which side.")
            legend(p.key, "Wrong, fits neither.")
            Text("Tap any row to type there. Six misses break the chain. Revealing a letter costs one miss. A new chain every day at midnight.").font(.footnote).foregroundStyle(p.muted)
        }
    }

    private func legend(_ c: Color, _ t: String) -> some View {
        HStack(spacing: 10) { RoundedRectangle(cornerRadius: 4).fill(c).frame(width: 26, height: 18); Text(t).font(.subheadline) }
    }

    private var result: some View {
        ResultSheet(game: .dovetail, title: model.resultTitle, emoji: model.emojiRow, mode: model.st.mode, shareText: model.shareText,
                    stats: StatsStore.load(.dovetail), onPractice: practice) {
            VStack(spacing: 0) {
                ForEach(0..<model.n, id: \.self) { i in
                    HStack {
                        Text(model.st.words[i].uppercased()).font(.system(size: 15, weight: .bold).width(.condensed)).tracking(0.5)
                            .foregroundStyle(model.st.status == .lost && !model.st.solved[i] ? p.accent : p.fg)
                        Spacer()
                        if i < model.n - 1 { Text((model.st.words[i] + model.st.words[i + 1]).uppercased()).font(.system(size: 11, weight: .medium)).tracking(1).foregroundStyle(p.muted) }
                    }
                    .padding(.vertical, 4)
                    .overlay(alignment: .bottom) { Rectangle().fill(p.line).frame(height: 1).opacity(i < model.n - 1 ? 1 : 0) }
                }
            }
        }
    }

    private func practice() {
        let ent = Entitlements(isPlus: store.isPlus)
        if ent.canPractice(day: model.day) {
            if !store.isPlus { Entitlements.notePracticeUsed(day: model.day) }
            model.startPractice()
        } else { paywallReason = "That's today's free practice puzzle. Plus members practice as much as they like, and can play every past chain."; showPaywall = true }
    }
}

/// A plank with a dovetail tab at the bottom and a matching notch at the top.
struct PlankShape: Shape {
    var tab: Bool
    var notch: Bool
    func path(in r: CGRect) -> Path {
        let T: CGFloat = 10, w1: CGFloat = 15, w2: CGFloat = 21, cx = r.midX
        var p = Path()
        p.move(to: CGPoint(x: r.minX, y: r.minY))
        if notch {
            p.addLine(to: CGPoint(x: cx - w1, y: r.minY)); p.addLine(to: CGPoint(x: cx - w2, y: r.minY + T))
            p.addLine(to: CGPoint(x: cx + w2, y: r.minY + T)); p.addLine(to: CGPoint(x: cx + w1, y: r.minY))
        }
        p.addLine(to: CGPoint(x: r.maxX, y: r.minY))
        let bottom = tab ? r.maxY - T : r.maxY
        p.addLine(to: CGPoint(x: r.maxX, y: bottom))
        if tab {
            p.addLine(to: CGPoint(x: cx + w1, y: bottom)); p.addLine(to: CGPoint(x: cx + w2, y: r.maxY))
            p.addLine(to: CGPoint(x: cx - w2, y: r.maxY)); p.addLine(to: CGPoint(x: cx - w1, y: bottom))
        }
        p.addLine(to: CGPoint(x: r.minX, y: bottom))
        p.closeSubpath()
        return p
    }
}

struct DovetailPin: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: r.minX + r.width * 0.25, y: r.minY)); p.addLine(to: CGPoint(x: r.minX + r.width * 0.75, y: r.minY))
        p.addLine(to: CGPoint(x: r.maxX, y: r.maxY)); p.addLine(to: CGPoint(x: r.minX, y: r.maxY)); p.closeSubpath()
        return p
    }
}
