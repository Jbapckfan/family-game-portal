import Foundation
import Observation

/// Keystone: a hidden word joins with five clue words. Three arches a day, scored by clues needed.
@MainActor
@Observable
final class KeystoneModel {
    static let rounds = 3

    struct Guess: Codable, Hashable { var w: String; var fits: [Bool] }

    struct Round: Codable {
        var k: String
        var clues: [String]
        var dirs: [String]         // "before" = clue + k, "after" = k + clue
        var revealed: Int = 2
        var strikes: Int = 0
        var guesses: [Guess] = []
        var status: GameStatus = .playing
        var score: Int = 0

        func fused(_ i: Int) -> String { dirs[i] == "before" ? clues[i] + k : k + clues[i] }
    }

    struct State: Codable {
        var mode: PlayMode
        var day: Int
        var rounds: [Round]
        var cur: Int
        var status: GameStatus
        var typed: String
    }

    enum Judgement { case short, dupe, clue, notWord, solve, miss([Bool]) }

    private let lib = PuzzleLibrary.shared
    private(set) var st: State
    var toast: String?
    var shakeTick = 0

    var day: Int { st.day }
    var isPlaying: Bool { st.status == .playing }
    var round: Round { st.rounds[st.cur] }
    var total: Int { KeystoneModel.total(st) }
    static func total(_ s: State) -> Int { s.rounds.reduce(0) { $0 + ($1.status == .playing ? 0 : $1.score) } }

    init(day: Int) {
        if let saved = Persist.load(State.self, key: "keystone.day.\(day)"), saved.rounds.count == KeystoneModel.rounds { st = saved }
        else { st = KeystoneModel.newState(lib.keystone.days[lib.index(for: day, in: .keystone)], mode: .daily, day: day) }
    }

    static func newState(_ rounds: [KeystoneRound], mode: PlayMode, day: Int) -> State {
        State(mode: mode, day: day, rounds: rounds.map { Round(k: $0.k, clues: $0.clues.map(\.w), dirs: $0.clues.map(\.d)) }, cur: 0, status: .playing, typed: "")
    }

    static func summary(day: Int) -> DailySummary? {
        guard let s = Persist.load(State.self, key: "keystone.day.\(day)") else { return nil }
        if s.status == .playing, s.cur == 0, s.rounds[0].guesses.isEmpty { return nil }
        let done = s.rounds.filter { $0.status != .playing }.count
        return DailySummary(status: s.status, emoji: emoji(s), detail: s.status == .playing ? "arch \(done + 1) of 3" : "score \(total(s))")
    }

    static let scoreEmoji = [2: "🟩", 3: "🟨", 4: "🟧", 5: "🟥", 6: "⬛"]
    static func emoji(_ s: State) -> String {
        s.rounds.map { $0.status == .playing ? "⬜" : (scoreEmoji[$0.score] ?? "⬛") }.joined() + (s.status == .playing ? "" : " \(total(s))")
    }
    var emoji: String { KeystoneModel.emoji(st) }

    func judge(_ word: String) -> Judgement {
        let r = round
        if word.count < 3 { return .short }
        if r.guesses.contains(where: { $0.w == word }) { return .dupe }
        if word == r.k { return .solve }
        if r.clues.contains(word) { return .clue }
        if !lib.dovetailCommon.contains(word) { return .notWord }
        return .miss(r.clues.prefix(r.revealed).map { lib.joins(word, $0) })
    }

    func key(_ k: String) {
        guard isPlaying else { return }
        switch k {
        case "ENTER": submit()
        case "BACK": if !st.typed.isEmpty { st.typed.removeLast() }
        default: if k.count == 1, k.first!.isLetter, st.typed.count < 9 { st.typed += k.lowercased() }
        }
    }

    func submit() {
        let word = st.typed
        switch judge(word) {
        case .short: toast = "Three letters or more"; shakeTick += 1
        case .dupe: toast = "Already tried"; shakeTick += 1
        case .clue: toast = "That's one of the clues"; shakeTick += 1
        case .notWord: toast = "Not in word list"; shakeTick += 1
        case .solve:
            st.rounds[st.cur].status = .won; st.rounds[st.cur].score = round.revealed; st.typed = ""
            toast = round.k.uppercased() + " · " + (0..<3).map { round.fused($0).uppercased() }.joined(separator: ", ") + "…"
            Haptics.success()
            persist()
            Task { try? await Task.sleep(for: .seconds(1.3)); advance() }
        case .miss(let fits):
            st.rounds[st.cur].guesses.append(Guess(w: word, fits: fits)); st.typed = ""
            let n = fits.filter { $0 }.count, m = fits.count
            if round.revealed < 5 {
                st.rounds[st.cur].revealed += 1
                toast = n == m ? "\(word.uppercased()) fits all \(m), but it isn't the keystone. New clue." : "\(word.uppercased()) fits \(n) of \(m). New clue."
                Haptics.warning()
            } else {
                st.rounds[st.cur].strikes += 1
                if round.strikes >= 2 { st.rounds[st.cur].status = .lost; st.rounds[st.cur].score = 6; toast = "The keystone was \(round.k.uppercased())"; Haptics.error() }
                else { toast = "\(word.uppercased()) fits \(n) of 5. Last try."; Haptics.warning() }
            }
            shakeTick += 1
            persist()
            if round.status == .lost { Task { try? await Task.sleep(for: .seconds(1.5)); advance() } }
        }
    }

    private func advance() {
        if st.rounds.allSatisfy({ $0.status != .playing }) {
            st.status = st.rounds.allSatisfy { $0.status == .won } ? .won : .lost
            if st.mode == .daily, st.day == DailyClock.dayIndex() { StatsStore.record(.keystone, day: st.day, didWin: st.status == .won, bucket: min(6, (total - 6) / 2)) }
            persist(); return
        }
        st.cur = st.rounds.firstIndex { $0.status == .playing } ?? st.cur
        st.typed = ""; persist()
    }

    func persist() { if st.mode == .daily { Persist.save(st, key: "keystone.day.\(st.day)") } }

    func startPractice() {
        let n = lib.keystone.days.count
        var idx: Int
        repeat { idx = Int.random(in: 0..<n) } while n > 1 && idx == lib.index(for: DailyClock.dayIndex(), in: .keystone)
        st = KeystoneModel.newState(lib.keystone.days[idx], mode: .practice, day: st.day)
    }

    var shareText: String {
        let head = st.mode == .daily ? "Keystone #\(st.day + 1)" : "Keystone (practice)"
        let line = st.rounds.map { KeystoneModel.scoreEmoji[$0.score] ?? "⬜" }.joined() + " \(total)"
        let tail = st.status == .won ? (total == 6 ? "Perfect 6" : "Score \(total) (6 is perfect)") : "An arch fell"
        return "\(head)\n\(line)\n\(tail)"
    }
    var resultTitle: String {
        switch st.status {
        case .won: total == 6 ? "Perfect six." : total <= 9 ? "Solid masonry." : "All three stand."
        case .lost: "An arch fell."
        case .playing: ""
        }
    }
}
