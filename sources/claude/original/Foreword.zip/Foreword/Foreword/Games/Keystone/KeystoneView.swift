import SwiftUI

struct KeystoneView: View {
    @State private var model: KeystoneModel
    init(day: Int = DailyClock.dayIndex()) { _model = State(initialValue: KeystoneModel(day: day)) }
    @Environment(StoreManager.self) private var store
    @State private var showHelp = !UserDefaults.standard.bool(forKey: "seen.keystone")
    @State private var showResult = false
    @State private var showPaywall = false
    @State private var paywallReason: String? = nil
    private let p = GameID.keystone.palette
    private let stone = Color.adaptive(0xD9CFC0, 0x4A4036)
    private let stoneInk = Color.adaptive(0x2B2117, 0xEFE6DA)

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(spacing: 10) {
                    roundTabs
                    HStack {
                        Text(model.isPlaying ? "Which word joins all of these?" : model.st.status == .won ? "All three arches stand." : "An arch fell.")
                            .font(.system(size: 13, weight: .medium)).foregroundStyle(p.muted)
                        Spacer()
                        HStack(spacing: 4) { ForEach(0..<2, id: \.self) { i in RoundedRectangle(cornerRadius: 2).fill(model.round.revealed >= 5 && i < model.round.strikes ? p.bad : p.line).frame(width: 10, height: 10).rotationEffect(.degrees(45)) } }
                    }
                    arch
                    log
                    Text("Every wrong guess reveals another clue. Fewer clues, better score.").font(.footnote).foregroundStyle(p.muted)
                }
                .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 12)
            }
            if model.isPlaying {
                KeyboardView(palette: p) { model.key($0) }
                    .padding(.horizontal, 8).padding(.top, 8).padding(.bottom, 6)
                    .background(p.bg.shadow(.drop(color: .black.opacity(0.08), radius: 8, y: -2)))
            }
        }
        .background(p.bg.ignoresSafeArea())
        .navigationTitle("Keystone")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 4) {
                    Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }
                    Button { showResult = true } label: { Image(systemName: "chart.bar") }.disabled(model.isPlaying)
                }
            }
        }
        .toast($model.toast, palette: p)
        .onChange(of: model.st.status) { _, s in if s != .playing { Task { try? await Task.sleep(for: .seconds(0.9)); showResult = true } } }
        .onAppear { if !model.isPlaying { showResult = true } }
        .sheet(isPresented: $showHelp, onDismiss: { UserDefaults.standard.set(true, forKey: "seen.keystone") }) { help }
        .sheet(isPresented: $showResult) { result }
        .sheet(isPresented: $showPaywall) { PaywallView(reason: paywallReason) }
    }

    private var roundTabs: some View {
        HStack(spacing: 8) {
            ForEach(0..<KeystoneModel.rounds, id: \.self) { i in
                let r = model.st.rounds[i], cur = i == model.st.cur && model.isPlaying
                VStack(spacing: 2) {
                    Text("ARCH \(i + 1)").font(.system(size: 10, weight: .bold)).tracking(1).foregroundStyle(p.muted)
                    Text(r.status == .playing ? (cur ? "\(r.revealed) clues" : "—") : r.status == .won ? "\(r.score)" : "✕").font(.system(size: 17, weight: .bold))
                }
                .frame(maxWidth: .infinity, minHeight: 50)
                .background(r.status == .won ? p.good : p.surface, in: RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(cur ? p.accent : p.line, lineWidth: cur ? 2 : 1))
            }
        }
    }

    private var arch: some View {
        let r = model.round, last = r.guesses.last
        return VStack(spacing: 8) {
            LazyVGrid(columns: [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)], spacing: 8) {
                ForEach(0..<4, id: \.self) { i in stoneView(i, r: r, last: last) }
            }
            stoneView(4, r: r, last: last)
            keystoneSlot(r)
        }
    }

    @ViewBuilder
    private func stoneView(_ i: Int, r: KeystoneModel.Round, last: KeystoneModel.Guess?) -> some View {
        if i < r.revealed || r.status != .playing {
            Text((r.status != .playing ? r.fused(i) : r.clues[i]).uppercased())
                .font(.system(size: 20, weight: .heavy)).tracking(1.5)
                .frame(maxWidth: .infinity, minHeight: 54)
                .background(stone, in: RoundedRectangle(cornerRadius: 8))
                .foregroundStyle(stoneInk)
                .overlay(alignment: .topTrailing) {
                    if r.status == .playing, let last, i < last.fits.count {
                        Text(last.fits[i] ? "✓ " + last.w.uppercased() : "✗").font(.system(size: 10, weight: .bold)).foregroundStyle(last.fits[i] ? p.accent : p.muted).padding(6)
                    }
                }
                .transition(.move(edge: .top).combined(with: .opacity))
        } else {
            Text("CLUE \(i + 1)").font(.system(size: 12, weight: .semibold)).tracking(1).foregroundStyle(p.muted)
                .frame(maxWidth: .infinity, minHeight: 54)
                .overlay(RoundedRectangle(cornerRadius: 8).strokeBorder(style: StrokeStyle(lineWidth: 2, dash: [6])).foregroundStyle(p.line))
        }
    }

    private func keystoneSlot(_ r: KeystoneModel.Round) -> some View {
        Group {
            if r.status != .playing { Text(r.k.uppercased()) }
            else if model.st.typed.isEmpty { Text("type the keystone").font(.system(size: 13)).foregroundStyle(p.muted) }
            else { Text(model.st.typed.uppercased()) }
        }
        .font(.system(size: 26, weight: .heavy)).tracking(3)
        .frame(width: 240, height: 62)
        .background(r.status == .won ? p.warn : r.status == .lost ? p.bad.opacity(0.18) : p.surface, in: TrapezoidShape())
        .overlay(TrapezoidShape().stroke(r.status == .won ? p.warn : r.status == .lost ? .clear : p.line, lineWidth: 2))
        .foregroundStyle(r.status == .won ? p.warnInk : r.status == .lost ? p.bad : p.fg)
        .modifier(Shake(animatableData: CGFloat(model.shakeTick)))
        .animation(.default, value: model.shakeTick)
    }

    private var log: some View {
        VStack(spacing: 5) {
            ForEach(Array(model.round.guesses.reversed().enumerated()), id: \.offset) { _, g in
                HStack(alignment: .top, spacing: 8) {
                    Text(g.w.uppercased()).font(.system(size: 13, weight: .bold)).tracking(1).frame(minWidth: 80, alignment: .leading)
                    FlowLayout(spacing: 4, lineSpacing: 4) {
                        ForEach(Array(g.fits.enumerated()), id: \.offset) { i, f in
                            let c = model.round.clues[i]
                            Text(f ? (PuzzleLibrary.shared.dovetailFused.contains(g.w + c) ? g.w + c : c + g.w).uppercased() : c.uppercased() + " ✗")
                                .font(.system(size: 11, weight: f ? .bold : .regular)).tracking(0.5)
                                .padding(.horizontal, 6).padding(.vertical, 1)
                                .overlay(Capsule().stroke(f ? p.accent : p.line)).foregroundStyle(f ? p.accent : p.muted)
                        }
                    }
                }
            }
        }
    }

    private var help: some View {
        HowToSheet(game: .keystone) {
            Text("A hidden word joins with five clue words to make five new words. Find it. Two clues show at first; every wrong guess reveals another.")
            VStack(spacing: 4) {
                Text("SNOW · FOOT · BASKET · ROOM · PIN").font(.system(size: 14, weight: .bold)).tracking(1)
                Text("all join with").font(.caption).foregroundStyle(p.muted)
                Text("BALL").font(.system(size: 20, weight: .heavy)).tracking(2).foregroundStyle(p.accent)
                Text("snowball · football · basketball · ballroom · pinball").font(.caption).foregroundStyle(p.muted)
            }.frame(maxWidth: .infinity)
            Text("The hidden word can go before or after a clue, and the join can be a real compound or pure spelling (CAR+PET, THIN+KING). Only the letters matter.")
            Text("Score is how many clues you needed: 2 is perfect, 5 is a scrape. After all five show you get two last tries. Three arches a day, easy to hard.")
            Text("Wrong guesses still teach: each clue shows ✓ if your word joins it.").font(.footnote).foregroundStyle(p.muted)
        }
    }

    private var result: some View {
        ResultSheet(game: .keystone, title: model.resultTitle, emoji: model.emoji, mode: model.st.mode, shareText: model.shareText, stats: StatsStore.load(.keystone), onPractice: practice) {
            VStack(spacing: 0) {
                ForEach(Array(model.st.rounds.enumerated()), id: \.offset) { _, r in
                    HStack(alignment: .top) {
                        Text(r.k.uppercased()).font(.system(size: 15, weight: .bold)).tracking(1)
                        Spacer()
                        Text((0..<5).map { r.fused($0) }.joined(separator: " · ")).font(.system(size: 11)).foregroundStyle(p.muted).multilineTextAlignment(.trailing)
                        Text(r.status == .won ? "\(r.score)" : "✕").font(.system(size: 15, weight: .bold)).frame(width: 24, alignment: .trailing)
                    }
                    .padding(.vertical, 6)
                    .overlay(alignment: .bottom) { Rectangle().fill(p.line).frame(height: 1) }
                }
            }
        }
    }

    private func practice() {
        if Entitlements(isPlus: store.isPlus).canPractice(day: model.day) {
            if !store.isPlus { Entitlements.notePracticeUsed(day: model.day) }
            model.startPractice()
        } else { paywallReason = "That's today's free practice puzzle. Plus members get unlimited arches, and every past day."; showPaywall = true }
    }
}

struct TrapezoidShape: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: r.minX + r.width * 0.12, y: r.minY)); p.addLine(to: CGPoint(x: r.maxX - r.width * 0.12, y: r.minY))
        p.addLine(to: CGPoint(x: r.maxX, y: r.maxY)); p.addLine(to: CGPoint(x: r.minX, y: r.maxY)); p.closeSubpath()
        return p
    }
}
