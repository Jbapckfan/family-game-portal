import Foundation
import Observation

/// Splice: twelve word-halves, six words, exactly one perfect pairing.
@MainActor
@Observable
final class SpliceModel {
    static let maxMistakes = 4

    struct State: Codable {
        var mode: PlayMode
        var day: Int
        var parts: [[String]]          // six [left, right] pairs; tile index t belongs to pair t/2
        var order: [Int]               // display order of tile indices
        var done: [Int]                // solved pair indices, in solve order
        var mistakes: Int
        var status: GameStatus
        var sel: [Int]
        var attempts: [Bool]
        var tried: [String]
    }

    enum Judgement { case dupe, notWord(String), mistake(String), solve(pair: Int, word: String) }

    private let lib = PuzzleLibrary.shared
    private(set) var st: State
    var toast: String?
    var shakeTick = 0
    var leaving: Set<Int> = []

    var tiles: [String] { st.parts.flatMap { $0 } }
    var day: Int { st.day }
    var isPlaying: Bool { st.status == .playing }

    init(day: Int) {
        if let saved = Persist.load(State.self, key: "splice.day.\(day)"), saved.parts.count == 6 { st = saved }
        else { st = SpliceModel.newState(lib.splice.puzzles[lib.index(for: day, in: .splice)], mode: .daily, day: day) }
    }

    static func newState(_ parts: [[String]], mode: PlayMode, day: Int) -> State {
        var gen = SeededGenerator(seed: UInt64(day + 11))
        let order = Array(0..<(parts.count * 2)).shuffled(using: &gen)
        return State(mode: mode, day: day, parts: parts, order: order, done: [], mistakes: 0, status: .playing, sel: [], attempts: [], tried: [])
    }

    static func summary(day: Int) -> DailySummary? {
        guard let s = Persist.load(State.self, key: "splice.day.\(day)") else { return nil }
        let e = s.attempts.map { $0 ? "🟩" : "🟥" }.joined()
        return DailySummary(status: s.status, emoji: e, detail: s.status == .playing ? "\(s.done.count) of 6 spliced" : s.status == .won ? (s.mistakes == 0 ? "Clean cut" : "\(s.mistakes) mistake\(s.mistakes == 1 ? "" : "s")") : "Reel cut")
    }

    var emoji: String { st.attempts.map { $0 ? "🟩" : "🟥" }.joined() }

    func judge(_ i: Int, _ j: Int) -> Judgement {
        let t = tiles, a = t[i], b = t[j]
        let key = a + "+" + b
        if st.tried.contains(key) { return .dupe }
        if i / 2 == j / 2, i % 2 == 0, j == i + 1 { return .solve(pair: i / 2, word: a + b) }
        if lib.spliceFused.contains(a + b) { return .mistake(a + b) }
        return .notWord(a + b)
    }

    func pick(_ i: Int) {
        guard isPlaying else { return }
        if let k = st.sel.firstIndex(of: i) { st.sel.remove(at: k) }
        else if st.sel.count < 2 { st.sel.append(i) }
        else { st.sel[1] = i }
        Haptics.tap()
    }

    func flip() { st.sel.reverse() }
    func clear() { st.sel = [] }
    func shuffle() { st.order.shuffle() }

    func splice() {
        guard st.sel.count == 2 else { return }
        let i = st.sel[0], j = st.sel[1]
        switch judge(i, j) {
        case .dupe: toast = "Already tried that"
        case .notWord(let w): toast = "\(w.uppercased()) isn't a word"; shakeTick += 1; st.sel = []
        case .solve(let pair, let w):
            toast = w.uppercased()
            leaving = [i, j]
            st.done.append(pair); st.attempts.append(true); st.sel = []
            Haptics.success()
            if st.done.count == st.parts.count { st.status = .won; finish() }
        case .mistake(let w):
            st.tried.append(tiles[i] + "+" + tiles[j]); st.mistakes += 1; st.attempts.append(false); st.sel = []
            toast = "\(w.uppercased()) is a word, but it strands another half"
            Haptics.error(); shakeTick += 1
            if st.mistakes >= SpliceModel.maxMistakes { st.status = .lost; finish() }
        }
        persist()
    }

    private func finish() { if st.mode == .daily, st.day == DailyClock.dayIndex() { StatsStore.record(.splice, day: st.day, didWin: st.status == .won, bucket: st.mistakes) } }
    func persist() { if st.mode == .daily { Persist.save(st, key: "splice.day.\(st.day)") } }

    func startPractice() {
        let n = lib.splice.puzzles.count
        var idx: Int
        repeat { idx = Int.random(in: 0..<n) } while n > 1 && idx == lib.index(for: DailyClock.dayIndex(), in: .splice)
        st = SpliceModel.newState(lib.splice.puzzles[idx], mode: .practice, day: st.day + idx)
        st.day = DailyClock.dayIndex()
    }

    var shareText: String {
        let head = st.mode == .daily ? "Splice #\(st.day + 1)" : "Splice (practice)"
        let tail = st.status == .won ? (st.mistakes == 0 ? "Clean cut" : "\(st.mistakes) mistake\(st.mistakes == 1 ? "" : "s")") : "\(st.done.count)/6 before the cut"
        return "\(head)\n\(emoji)\n\(tail)"
    }
    var resultTitle: String {
        switch st.status { case .won: st.mistakes == 0 ? "Clean cut." : "Spliced."; case .lost: "The reel is cut."; case .playing: "" }
    }
}

/// Deterministic shuffle so a day's bin looks the same on every device.
struct SeededGenerator: RandomNumberGenerator {
    private var state: UInt64
    init(seed: UInt64) { state = seed &* 0x9E3779B97F4A7C15 &+ 0xD1B54A32D192ED03 }
    mutating func next() -> UInt64 {
        state &+= 0x9E3779B97F4A7C15
        var z = state
        z = (z ^ (z >> 30)) &* 0xBF58476D1CE4E5B9
        z = (z ^ (z >> 27)) &* 0x94D049BB133111EB
        return z ^ (z >> 31)
    }
}
