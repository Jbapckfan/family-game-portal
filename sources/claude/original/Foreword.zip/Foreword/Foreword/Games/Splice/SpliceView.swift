import SwiftUI

struct SpliceView: View {
    @State private var model: SpliceModel
    init(day: Int = DailyClock.dayIndex()) { _model = State(initialValue: SpliceModel(day: day)) }
    @Environment(StoreManager.self) private var store
    @State private var showHelp = !UserDefaults.standard.bool(forKey: "seen.splice")
    @State private var showResult = false
    @State private var showPaywall = false
    @State private var paywallReason: String? = nil
    private let p = GameID.splice.palette
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 9), count: 3)

    var body: some View {
        ScrollView {
            VStack(spacing: 10) {
                HStack {
                    Text(hudText).font(.system(size: 13, weight: .medium)).foregroundStyle(p.muted)
                    Spacer()
                    MistakeDots(total: SpliceModel.maxMistakes, used: model.st.mistakes, palette: p)
                }
                reel
                spliceBar
                if model.isPlaying { bin }
                HStack(spacing: 10) {
                    toolButton("Shuffle") { model.shuffle() }.disabled(!model.isPlaying)
                    toolButton("Deselect") { model.clear() }.disabled(model.st.sel.isEmpty)
                }
                Text("Every half pairs with something. Only one way uses them all.").font(.footnote).foregroundStyle(p.muted)
            }
            .padding(16)
        }
        .background(p.bg.ignoresSafeArea())
        .navigationTitle("Splice")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 4) {
                    Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }
                    Button { showResult = true } label: { Image(systemName: "chart.bar") }.disabled(model.isPlaying)
                }
            }
        }
        .toast($model.toast, palette: p)
        .onChange(of: model.st.status) { _, s in if s != .playing { Task { try? await Task.sleep(for: .seconds(0.9)); showResult = true } } }
        .onAppear { if !model.isPlaying { showResult = true } }
        .sheet(isPresented: $showHelp, onDismiss: { UserDefaults.standard.set(true, forKey: "seen.splice") }) { help }
        .sheet(isPresented: $showResult) { result }
        .sheet(isPresented: $showPaywall) { PaywallView(reason: paywallReason) }
    }

    private var hudText: String {
        switch model.st.status {
        case .won: return "All six spliced."
        case .lost: return "The reel is cut."
        case .playing:
            let left = SpliceModel.maxMistakes - model.st.mistakes
            return "\(6 - model.st.done.count) words to go · \(left) mistake\(left == 1 ? "" : "s") left"
        }
    }

    private var reel: some View {
        let show: [Int] = model.st.status == .lost ? model.st.done + (0..<6).filter { !model.st.done.contains($0) } : model.st.done
        return VStack(spacing: 6) {
            ForEach(show, id: \.self) { k in
                let missed = !model.st.done.contains(k)
                HStack(spacing: 0) {
                    Text(model.st.parts[k][0].uppercased())
                    Rectangle().fill(missed ? p.bad : p.accent).frame(width: 3, height: 24).rotationEffect(.degrees(14)).padding(.horizontal, 6)
                    Text(model.st.parts[k][1].uppercased())
                }
                .font(.system(size: 24, weight: .heavy).width(.condensed)).tracking(2)
                .foregroundStyle(missed ? p.bad : p.goodInk)
                .frame(maxWidth: .infinity, minHeight: 44)
                .background(missed ? p.bad.opacity(0.15) : p.good, in: RoundedRectangle(cornerRadius: 6))
                .transition(.move(edge: .top).combined(with: .opacity))
            }
        }
        .animation(.easeOut(duration: 0.3), value: model.st.done.count)
    }

    private var spliceBar: some View {
        let t = model.tiles, sel = model.st.sel
        return HStack(spacing: 8) {
            Group {
                if sel.count == 2 { HStack(spacing: 6) { Text(t[sel[0]].uppercased()); Text("+").foregroundStyle(p.muted); Text(t[sel[1]].uppercased()) } }
                else if sel.count == 1 { HStack(spacing: 6) { Text(t[sel[0]].uppercased()); Text("+").foregroundStyle(p.muted); Text("pick a second half").font(.system(size: 14)).foregroundStyle(p.muted) } }
                else { Text(model.isPlaying ? "Pick two halves to splice them." : model.st.status == .won ? "Nice cut." : "Better luck tomorrow.").font(.system(size: 14)).foregroundStyle(p.muted) }
            }
            .font(.system(size: 24, weight: .heavy).width(.condensed)).tracking(2)
            .lineLimit(1).minimumScaleFactor(0.6)
            Spacer(minLength: 4)
            if sel.count == 2 {
                Button { model.flip() } label: { Image(systemName: "arrow.left.arrow.right").font(.system(size: 14, weight: .bold)).frame(width: 40, height: 40).background(p.key, in: RoundedRectangle(cornerRadius: 9)) }.foregroundStyle(p.fg)
                Button { model.splice() } label: { Text("Splice").font(.system(size: 14, weight: .bold)).frame(height: 40).padding(.horizontal, 14).background(p.accent, in: RoundedRectangle(cornerRadius: 9)) }.foregroundStyle(p.accentInk)
            }
        }
        .padding(.leading, 14).padding(.trailing, 8).padding(.vertical, 8)
        .frame(maxWidth: .infinity, minHeight: 56)
        .background(p.surface, in: RoundedRectangle(cornerRadius: 10))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(p.line))
    }

    private var bin: some View {
        LazyVGrid(columns: columns, spacing: 9) {
            ForEach(model.st.order, id: \.self) { i in
                if !model.st.done.contains(i / 2) {
                    let selected = model.st.sel.contains(i)
                    Button { model.pick(i) } label: {
                        Text(model.tiles[i].uppercased())
                            .font(.system(size: model.tiles[i].count > 6 ? 17 : 22, weight: .heavy).width(.condensed)).tracking(1.5)
                            .frame(maxWidth: .infinity, minHeight: 58)
                            .background(selected ? p.good : p.surface, in: RoundedRectangle(cornerRadius: 5))
                            .overlay(RoundedRectangle(cornerRadius: 5).stroke(selected ? p.accent : p.fg.opacity(0.75), lineWidth: 2))
                            .overlay(alignment: .top) { sprockets.padding(.top, 3) }
                            .overlay(alignment: .bottom) { sprockets.padding(.bottom, 3) }
                            .foregroundStyle(p.fg)
                            .offset(y: selected ? -2 : 0)
                    }
                    .buttonStyle(.plain)
                    .modifier(Shake(animatableData: CGFloat(selected ? model.shakeTick : 0)))
                    .animation(.default, value: model.shakeTick)
                    .transition(.scale.combined(with: .opacity))
                }
            }
        }
        .animation(.easeOut(duration: 0.25), value: model.st.done.count)
    }

    private var sprockets: some View {
        HStack(spacing: 6) { ForEach(0..<8, id: \.self) { _ in Circle().fill(p.fg.opacity(0.75)).frame(width: 4, height: 4) } }
    }

    private func toolButton(_ t: String, _ a: @escaping () -> Void) -> some View {
        Button(action: a) { Text(t).font(.system(size: 14, weight: .semibold)).padding(.horizontal, 14).padding(.vertical, 9).overlay(Capsule().stroke(p.line)) }.foregroundStyle(p.fg)
    }

    private var help: some View {
        HowToSheet(game: .splice) {
            Text("Twelve word-halves are in the bin. Splice them into six words, using every half exactly once.")
            HStack(spacing: 6) {
                ForEach(["fire", "wood", "place", "work"], id: \.self) { t in
                    Text(t.uppercased()).font(.system(size: 16, weight: .heavy).width(.condensed)).tracking(1.5)
                        .padding(.horizontal, 8).padding(.vertical, 4)
                        .background(t == "fire" || t == "place" ? p.good : p.surface, in: RoundedRectangle(cornerRadius: 4))
                        .overlay(RoundedRectangle(cornerRadius: 4).stroke(t == "fire" || t == "place" ? p.accent : p.fg, lineWidth: 2))
                }
            }.frame(maxWidth: .infinity)
            Text("FIRE could take WOOD or PLACE. That's the trap: many pairs make real words, but only one set of six uses all twelve. A splice that spells a real word but isn't in today's set costs a mistake. One that isn't a word costs nothing.")
            Text("Tap two halves, then Splice. Use the arrows to swap the order. Four mistakes and the reel is cut. A new bin every day at midnight.").font(.footnote).foregroundStyle(p.muted)
        }
    }

    private var result: some View {
        ResultSheet(game: .splice, title: model.resultTitle, emoji: model.emoji, mode: model.st.mode, shareText: model.shareText, stats: StatsStore.load(.splice), onPractice: practice) {
            VStack(spacing: 4) {
                ForEach(0..<6, id: \.self) { k in
                    let missed = !model.st.done.contains(k)
                    HStack(spacing: 0) {
                        Text(model.st.parts[k][0].uppercased()); Rectangle().fill(missed ? p.bad : p.accent).frame(width: 2, height: 16).rotationEffect(.degrees(14)).padding(.horizontal, 5); Text(model.st.parts[k][1].uppercased())
                    }
                    .font(.system(size: 17, weight: .heavy).width(.condensed)).tracking(1.5)
                    .foregroundStyle(missed ? p.bad : p.goodInk)
                    .frame(maxWidth: .infinity, minHeight: 32)
                    .background(missed ? p.bad.opacity(0.15) : p.good, in: RoundedRectangle(cornerRadius: 6))
                }
            }
        }
    }

    private func practice() {
        if Entitlements(isPlus: store.isPlus).canPractice(day: model.day) {
            if !store.isPlus { Entitlements.notePracticeUsed(day: model.day) }
            model.startPractice()
        } else { paywallReason = "That's today's free practice puzzle. Plus members practice as much as they like, and can play every past bin."; showPaywall = true }
    }
}
