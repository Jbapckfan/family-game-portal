import Foundation
import Observation

/// Sprout: grow a three-letter seed into an eight-letter bloom, one soil letter per turn.
@MainActor
@Observable
final class SproutModel {
    static let maxWilts = 5

    struct Pick: Codable, Hashable { var soil: Bool; var i: Int; var ch: String }

    struct State: Codable {
        var mode: PlayMode
        var day: Int
        var seed: String
        var pool: String
        var alive: [Int: [String]]     // level -> words that can still reach a bloom
        var dead: [Int: [String]]      // level -> real words that are dead ends
        var stack: [String]
        var soilUsed: [Bool]
        var typed: [Pick]
        var wilts: Int
        var status: GameStatus
        var levelWilt: [Int: Int]
        var hint: String?
    }

    enum Judgement { case short, badLetters, notWord, dead(String), grow(String, added: Character) }

    private let lib = PuzzleLibrary.shared
    private(set) var st: State
    var toast: String?
    var shakeTick = 0
    var growTick = 0

    var day: Int { st.day }
    var isPlaying: Bool { st.status == .playing }
    var current: String { st.stack.last ?? st.seed }
    var level: Int { current.count + 1 }
    var typedWord: String { st.typed.map(\.ch).joined() }
    var remainingPool: [Character] { st.pool.enumerated().filter { !st.soilUsed[$0.offset] }.map(\.element) }

    init(day: Int) {
        if let saved = Persist.load(State.self, key: "sprout.day.\(day)"), !saved.stack.isEmpty { st = saved }
        else { st = SproutModel.newState(lib.sprout.puzzles[lib.index(for: day, in: .sprout)], mode: .daily, day: day) }
    }

    static func newState(_ p: SproutPuzzle, mode: PlayMode, day: Int) -> State {
        var alive: [Int: [String]] = [:], dead: [Int: [String]] = [:]
        for (k, v) in p.levels { if let n = Int(k) { alive[n] = v.a; dead[n] = v.d } }
        return State(mode: mode, day: day, seed: p.seed, pool: p.pool, alive: alive, dead: dead, stack: [p.seed],
                     soilUsed: Array(repeating: false, count: p.pool.count), typed: [], wilts: 0, status: .playing, levelWilt: [:], hint: nil)
    }

    static func summary(day: Int) -> DailySummary? {
        guard let s = Persist.load(State.self, key: "sprout.day.\(day)") else { return nil }
        let len = s.stack.last?.count ?? 3
        return DailySummary(status: s.status, emoji: emoji(s), detail: s.status == .playing ? "\(len) letters tall" : s.status == .won ? (s.wilts == 0 ? "No wilts" : "\(s.wilts) wilt\(s.wilts == 1 ? "" : "s")") : "Died at \(len)")
    }

    static func emoji(_ s: State) -> String {
        var out = "🌱"
        for k in 4...8 { out += s.stack.contains { $0.count == k } ? ((s.levelWilt[k] ?? 0) > 0 ? "🟨" : "🟩") : "⬜" }
        return out + (s.status == .won ? "🌸" : s.status == .lost ? "🥀" : "")
    }
    var emoji: String { SproutModel.emoji(st) }

    // MARK: Judging

    func judge(_ word: String) -> Judgement {
        let cur = current, k = cur.count + 1
        if word.count != k { return .short }
        guard var rest = Array(word).removingAll(Array(cur)), rest.count == 1, remainingPool.contains(rest[0]) else { return .badLetters }
        let added = rest.removeFirst()
        if st.alive[k]?.contains(word) == true { return .grow(word, added: added) }
        if st.dead[k]?.contains(word) == true { return .dead(word) }
        return .notWord
    }

    func hintLetter() -> Character? {
        let key = current.sortedLetters, k = level
        guard let alive = st.alive[k] else { return nil }
        for c in Set(remainingPool).sorted() {
            let target = (key + String(c)).sortedLetters
            if alive.contains(where: { $0.sortedLetters == target }) { return c }
        }
        return nil
    }

    // MARK: Input

    func tap(soil: Bool, index i: Int) {
        guard isPlaying, st.typed.count < level else { return }
        if soil {
            if st.typed.contains(where: { $0.soil }) { toast = "Only one soil letter per turn"; return }
            if st.typed.contains(where: { $0.soil && $0.i == i }) { return }
            st.typed.append(Pick(soil: true, i: i, ch: String(st.pool[i])))
        } else {
            if st.typed.contains(where: { !$0.soil && $0.i == i }) { return }
            st.typed.append(Pick(soil: false, i: i, ch: String(current[i])))
        }
        Haptics.tap()
    }
    func untype(at i: Int) { guard i < st.typed.count else { return }; st.typed.remove(at: i) }
    func backspace() { if !st.typed.isEmpty { st.typed.removeLast() } }
    func clear() { st.typed = [] }
    func isUsed(soil: Bool, index i: Int) -> Bool { st.typed.contains { $0.soil == soil && $0.i == i } }
    var soilTaken: Bool { st.typed.contains { $0.soil } }

    func grow() {
        guard isPlaying else { return }
        let word = typedWord, k = level
        switch judge(word) {
        case .short: toast = "Use all \(k) letters"; shakeTick += 1
        case .badLetters: toast = "Use every letter you have, plus one from the soil"; shakeTick += 1
        case .notWord: toast = "Not in word list"; shakeTick += 1
        case .dead(let w):
            st.levelWilt[k, default: 0] += 1; st.wilts += 1; st.typed = []
            toast = "\(w.uppercased()) is a word, but nothing grows from it"
            Haptics.warning(); shakeTick += 1
            if st.wilts >= SproutModel.maxWilts { st.status = .lost; finish() }
        case .grow(let w, let added):
            st.stack.append(w)
            if let idx = st.pool.enumerated().first(where: { $0.element == added && !st.soilUsed[$0.offset] })?.offset { st.soilUsed[idx] = true }
            st.typed = []; st.hint = nil; growTick += 1
            toast = w.count == 8 ? "\(w.uppercased()) · in bloom" : w.uppercased()
            Haptics.success()
            if w.count == 8 { st.status = .won; finish() }
        }
        persist()
    }

    func hint() {
        guard isPlaying, st.hint == nil else { return }
        guard let c = hintLetter() else { toast = "Nothing grows here. Check your word."; return }
        st.hint = String(c); st.wilts += 1; st.levelWilt[level, default: 0] += 1
        toast = "Add \(String(c).uppercased()) · 1 wilt"
        if st.wilts >= SproutModel.maxWilts { st.status = .lost; finish() }
        persist()
    }

    /// One complete growth path from the current position, used in the reveal after a loss.
    func examplePath() -> [String] {
        var path = st.stack, used = st.soilUsed
        var cur = path.last ?? st.seed
        while cur.count < 8 {
            let k = cur.count + 1
            guard let alive = st.alive[k] else { break }
            let rem = st.pool.enumerated().filter { !used[$0.offset] }.map(\.element)
            var found: (String, Character)? = nil
            for w in alive {
                if let rest = Array(w).removingAll(Array(cur)), rest.count == 1, rem.contains(rest[0]) { found = (w, rest[0]); break }
            }
            guard let f = found else { break }
            path.append(f.0); cur = f.0
            if let idx = st.pool.enumerated().first(where: { $0.element == f.1 && !used[$0.offset] })?.offset { used[idx] = true }
        }
        return path
    }

    private func finish() { if st.mode == .daily, st.day == DailyClock.dayIndex() { StatsStore.record(.sprout, day: st.day, didWin: st.status == .won, bucket: st.wilts) } }
    func persist() { if st.mode == .daily { Persist.save(st, key: "sprout.day.\(st.day)") } }

    func startPractice() {
        let n = lib.sprout.puzzles.count
        var idx: Int
        repeat { idx = Int.random(in: 0..<n) } while n > 1 && idx == lib.index(for: DailyClock.dayIndex(), in: .sprout)
        st = SproutModel.newState(lib.sprout.puzzles[idx], mode: .practice, day: st.day)
    }

    var shareText: String {
        let head = st.mode == .daily ? "Sprout #\(st.day + 1)" : "Sprout (practice)"
        let tail = st.status == .won ? (st.wilts == 0 ? "No wilts" : "\(st.wilts) wilt\(st.wilts == 1 ? "" : "s")") : "Died at \(current.count) letters"
        return "\(head)\n\(emoji)\n\(tail)"
    }
    var resultTitle: String {
        switch st.status { case .won: st.wilts == 0 ? "Perfect bloom." : "In bloom."; case .lost: "The plant died."; case .playing: "" }
    }
}
