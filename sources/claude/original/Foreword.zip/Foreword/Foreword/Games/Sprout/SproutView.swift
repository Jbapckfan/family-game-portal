import SwiftUI

struct SproutView: View {
    @State private var model: SproutModel
    init(day: Int = DailyClock.dayIndex()) { _model = State(initialValue: SproutModel(day: day)) }
    @Environment(StoreManager.self) private var store
    @State private var showHelp = !UserDefaults.standard.bool(forKey: "seen.sprout")
    @State private var showResult = false
    @State private var showPaywall = false
    @State private var paywallReason: String? = nil
    private let p = GameID.sprout.palette
    private let soil = Color.adaptive(0x7A5436, 0xC49B73)
    private let soilSoft = Color.adaptive(0xE9D8C8, 0x3A2B1F)
    private let bloom = Color.adaptive(0xD94F7E, 0xFF7FA8)
    private let bloomInk = Color.adaptive(0xFFFFFF, 0x3B0D1E)

    var body: some View {
        ScrollView {
            VStack(spacing: 10) {
                hud
                stem
                rack
                Text("Add one letter, rearrange everything, grow a new word.").font(.footnote).foregroundStyle(p.muted)
            }
            .padding(16)
        }
        .background(p.bg.ignoresSafeArea())
        .navigationTitle("Sprout")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 4) {
                    Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }
                    Button { showResult = true } label: { Image(systemName: "chart.bar") }.disabled(model.isPlaying)
                }
            }
        }
        .toast($model.toast, palette: p)
        .onChange(of: model.st.status) { _, s in if s != .playing { Task { try? await Task.sleep(for: .seconds(1.0)); showResult = true } } }
        .onAppear { if !model.isPlaying { showResult = true } }
        .sheet(isPresented: $showHelp, onDismiss: { UserDefaults.standard.set(true, forKey: "seen.sprout") }) { help }
        .sheet(isPresented: $showResult) { result }
        .sheet(isPresented: $showPaywall) { PaywallView(reason: paywallReason) }
    }

    private var hud: some View {
        HStack {
            HStack(spacing: 4) {
                ForEach(0..<SproutModel.maxWilts, id: \.self) { i in
                    LeafShape().fill(i < model.st.wilts ? p.warn : p.accent).frame(width: 16, height: 16)
                        .rotationEffect(.degrees(i < model.st.wilts ? 120 : 45)).opacity(i < model.st.wilts ? 0.7 : 1)
                        .animation(.easeOut(duration: 0.3), value: model.st.wilts)
                }
            }
            Text(model.st.status == .won ? "Bloomed!" : model.st.status == .lost ? "The plant died." : "\(8 - model.current.count) to bloom")
                .font(.system(size: 13, weight: .semibold)).foregroundStyle(p.muted)
            Spacer()
            Button {
                let ent = Entitlements(isPlus: store.isPlus)
                if ent.canHint(.sprout, day: model.day) || model.st.mode == .practice {
                    if model.st.mode == .daily { Entitlements.noteHintUsed(.sprout, day: model.day) }
                    model.hint()
                } else { paywallReason = "You've used today's free hint. Plus members get unlimited hints across all four games."; showPaywall = true }
            } label: {
                Text("Which letter? · costs 1").font(.system(size: 12, weight: .bold)).padding(.horizontal, 10).padding(.vertical, 6)
                    .background(p.surface, in: Capsule()).overlay(Capsule().stroke(p.line))
            }
            .foregroundStyle(p.fg)
            .disabled(!model.isPlaying || model.st.hint != nil)
            .opacity(!model.isPlaying || model.st.hint != nil ? 0.45 : 1)
        }
    }

    private var stem: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 2).fill(p.good).frame(width: 3).padding(.vertical, 8)
            VStack(spacing: 6) {
                ForEach((3...8).reversed(), id: \.self) { n in levelRow(n) }
            }
        }
    }

    @ViewBuilder
    private func levelRow(_ n: Int) -> some View {
        if let w = model.st.stack.first(where: { $0.count == n }) {
            HStack(spacing: 5) {
                ForEach(Array(w.enumerated()), id: \.offset) { _, ch in
                    tile(String(ch).uppercased(), bg: n == 8 ? bloom : n == 3 ? soil : p.accent, fg: n == 8 ? bloomInk : n == 3 ? .white : p.accentInk)
                }
            }
            .transition(.scale(scale: 0.7).combined(with: .opacity))
        } else if n == model.level, model.isPlaying {
            HStack(spacing: 5) {
                ForEach(0..<n, id: \.self) { i in
                    let pick = i < model.st.typed.count ? model.st.typed[i] : nil
                    Button { if pick != nil { model.untype(at: i) } } label: {
                        tile(pick?.ch.uppercased() ?? "", bg: pick?.soil == true ? soilSoft : p.surface, fg: p.fg)
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(pick == nil ? p.line : pick!.soil ? soil : p.accent, lineWidth: 2))
                    }.buttonStyle(.plain)
                }
            }
            .modifier(Shake(animatableData: CGFloat(model.shakeTick)))
            .animation(.default, value: model.shakeTick)
        } else {
            HStack(spacing: 5) { ForEach(0..<n, id: \.self) { _ in Circle().fill(p.line).frame(width: 10, height: 10).frame(width: 38, height: 40) } }
        }
    }

    private func tile(_ s: String, bg: Color, fg: Color) -> some View {
        Text(s).font(.system(size: 21, weight: .heavy, design: .rounded)).frame(width: 38, height: 40)
            .background(bg, in: RoundedRectangle(cornerRadius: 8)).foregroundStyle(fg)
    }

    private var rack: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("YOUR WORD").font(.system(size: 11, weight: .heavy)).tracking(1.2).foregroundStyle(p.muted)
            FlowLayout(spacing: 6, lineSpacing: 6) {
                ForEach(Array(model.current.enumerated()), id: \.offset) { i, ch in
                    rackTile(String(ch).uppercased(), used: model.isUsed(soil: false, index: i), soil: false, hint: false) { model.tap(soil: false, index: i) }
                }
            }
            Text("SOIL · ADD ONE").font(.system(size: 11, weight: .heavy)).tracking(1.2).foregroundStyle(p.muted)
            FlowLayout(spacing: 6, lineSpacing: 6) {
                ForEach(Array(model.st.pool.enumerated()), id: \.offset) { i, ch in
                    if !model.st.soilUsed[i] {
                        let used = model.isUsed(soil: true, index: i)
                        rackTile(String(ch).uppercased(), used: used || (!used && model.soilTaken), soil: true, hint: model.st.hint == String(ch) && !used) { model.tap(soil: true, index: i) }
                    }
                }
            }
            HStack(spacing: 8) {
                rackButton("Clear", bg: p.key, fg: p.fg) { model.clear() }.disabled(model.st.typed.isEmpty)
                rackButton("⌫", bg: p.key, fg: p.fg) { model.backspace() }.disabled(model.st.typed.isEmpty)
                rackButton("Grow", bg: p.accent, fg: p.accentInk) { model.grow() }.disabled(!model.isPlaying || model.st.typed.count != model.level)
            }
        }
        .padding(12)
        .background(p.surface, in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(p.line))
        .opacity(model.isPlaying ? 1 : 0.5)
        .disabled(!model.isPlaying)
    }

    private func rackTile(_ s: String, used: Bool, soil isSoil: Bool, hint: Bool, _ a: @escaping () -> Void) -> some View {
        Button(action: a) {
            Text(s).font(.system(size: 22, weight: .heavy, design: .rounded)).frame(width: 44, height: 48)
                .background(isSoil ? soilSoft : p.good, in: RoundedRectangle(cornerRadius: 9))
                .overlay(RoundedRectangle(cornerRadius: 9).strokeBorder(style: StrokeStyle(lineWidth: 2, dash: isSoil ? [5] : [])).foregroundStyle(isSoil ? soil : .clear))
                .overlay(alignment: .topTrailing) { if hint { Circle().fill(p.warn).frame(width: 12, height: 12).overlay(Circle().stroke(p.surface, lineWidth: 2)).offset(x: 4, y: -4) } }
                .foregroundStyle(p.fg)
                .opacity(used ? 0.25 : 1)
                .scaleEffect(used ? 0.92 : 1)
        }
        .buttonStyle(.plain)
        .disabled(used)
        .animation(.easeOut(duration: 0.15), value: used)
    }

    private func rackButton(_ t: String, bg: Color, fg: Color, _ a: @escaping () -> Void) -> some View {
        Button(action: a) { Text(t).font(.system(size: 15, weight: .heavy, design: .rounded)).frame(maxWidth: .infinity, minHeight: 44).background(bg, in: RoundedRectangle(cornerRadius: 10)) }
            .foregroundStyle(fg)
    }

    private var help: some View {
        HowToSheet(game: .sprout) {
            Text("Start from a three-letter seed. Each turn, take one letter from the soil, add it to the letters you have, and rearrange them all into a new word. Reach eight letters to bloom.")
            VStack(spacing: 2) {
                Group { Text("EAR"); Text("+ T").font(.caption).foregroundStyle(p.muted); Text("RATE"); Text("+ C").font(.caption).foregroundStyle(p.muted); Text("CRATE"); Text("+ N … + I … + O").font(.caption).foregroundStyle(p.muted); Text("REACTION") }
                    .font(.system(size: 18, weight: .heavy, design: .rounded)).tracking(2)
            }.frame(maxWidth: .infinity)
            Text("Many paths work. But some real words are dead ends: nothing grows from them. Planting one wilts a leaf and sends you back a step. Five wilts and the plant dies.")
            Text("Tap letters to spell, then Grow. Tap a letter in the row to put it back. \"Which letter?\" marks a soil letter that keeps the plant alive; it costs a wilt. New seed every day at midnight.").font(.footnote).foregroundStyle(p.muted)
        }
    }

    private var result: some View {
        let path = model.st.status == .won ? model.st.stack : model.examplePath()
        return ResultSheet(game: .sprout, title: model.resultTitle, emoji: model.emoji, mode: model.st.mode, shareText: model.shareText, stats: StatsStore.load(.sprout), onPractice: practice) {
            VStack(spacing: 4) {
                if model.st.status != .won { Text("One way it could have grown:").font(.footnote).foregroundStyle(p.muted) }
                ForEach(Array(path.reversed().enumerated()), id: \.offset) { _, w in
                    Text(w.uppercased()).font(.system(size: 16, weight: .heavy, design: .rounded)).tracking(2)
                        .padding(.horizontal, 10).padding(.vertical, 3)
                        .background(w.count == 8 ? bloom.opacity(0.25) : w.count == 3 ? soilSoft : p.good, in: RoundedRectangle(cornerRadius: 6))
                }
            }
        }
    }

    private func practice() {
        if Entitlements(isPlus: store.isPlus).canPractice(day: model.day) {
            if !store.isPlus { Entitlements.notePracticeUsed(day: model.day) }
            model.startPractice()
        } else { paywallReason = "That's today's free practice puzzle. Plus members plant as many seeds as they like, and can replay every past one."; showPaywall = true }
    }
}

struct LeafShape: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: r.minX, y: r.maxY))
        p.addQuadCurve(to: CGPoint(x: r.maxX, y: r.minY), control: CGPoint(x: r.minX, y: r.minY))
        p.addQuadCurve(to: CGPoint(x: r.minX, y: r.maxY), control: CGPoint(x: r.maxX, y: r.maxY))
        return p
    }
}
