import Foundation
import Observation

/// Tangle: three words interleaved into one string; pull them apart.
@MainActor
@Observable
final class TangleModel {
    static let maxKnots = 4

    struct Hint: Codable, Hashable { var i: Int; var j: Int }

    struct State: Codable {
        var mode: PlayMode
        var day: Int
        var s: String
        var w: [String]
        var o: [Int]
        var removed: [Bool]
        var pulled: [Int]
        var sel: [Int]
        var knots: Int
        var status: GameStatus
        var attempts: [Bool]
        var hints: [Hint]
        var tried: [String]
    }

    enum Judgement { case empty, badLength([Int]), dupe, notWord(String), knot(String), pull(Int, String) }

    private let lib = PuzzleLibrary.shared
    private(set) var st: State
    var toast: String?
    var shakeTick = 0
    var leaving: Set<Int> = []

    var day: Int { st.day }
    var isPlaying: Bool { st.status == .playing }
    var remaining: [Int] { st.w.indices.filter { !st.pulled.contains($0) } }
    var selectedWord: String { st.sel.sorted().map { String(st.s[$0]) }.joined() }

    init(day: Int) {
        if let saved = Persist.load(State.self, key: "tangle.day.\(day)"), saved.w.count == 3 { st = saved }
        else { st = TangleModel.newState(lib.tangle.puzzles[lib.index(for: day, in: .tangle)], mode: .daily, day: day) }
    }

    static func newState(_ p: TanglePuzzle, mode: PlayMode, day: Int) -> State {
        State(mode: mode, day: day, s: p.s, w: p.w, o: p.o, removed: Array(repeating: false, count: p.s.count), pulled: [], sel: [], knots: 0, status: .playing, attempts: [], hints: [], tried: [])
    }

    static func summary(day: Int) -> DailySummary? {
        guard let s = Persist.load(State.self, key: "tangle.day.\(day)") else { return nil }
        return DailySummary(status: s.status, emoji: emoji(s), detail: s.status == .playing ? "\(s.pulled.count) of 3 pulled" : s.status == .won ? (s.knots == 0 ? "No knots" : "\(s.knots) knot\(s.knots == 1 ? "" : "s")") : "Knotted up")
    }

    static func emoji(_ s: State) -> String { s.attempts.map { $0 ? "🟩" : "🟥" }.joined() + (s.status == .won ? "🧵" : s.status == .lost ? "🪢" : "") }
    var emoji: String { TangleModel.emoji(st) }

    func judge() -> Judgement {
        let word = selectedWord
        if word.isEmpty { return .empty }
        let rem = remaining, lens = rem.map { st.w[$0].count }
        if !lens.contains(word.count) { return .badLength(lens.sorted()) }
        if let hit = rem.first(where: { st.w[$0] == word }) { return .pull(hit, word) }
        if st.tried.contains(word) { return .dupe }
        if lib.tangleDict.contains(word) { return .knot(word) }
        return .notWord(word)
    }

    func toggle(_ i: Int) {
        guard isPlaying else { return }
        if let k = st.sel.firstIndex(of: i) { st.sel.remove(at: k) } else { st.sel.append(i) }
        Haptics.tap()
    }
    func clear() { st.sel = [] }
    func backspace() { if !st.sel.isEmpty { st.sel.removeLast() } }

    func pull() {
        guard isPlaying else { return }
        switch judge() {
        case .empty: return
        case .badLength(let lens): toast = "Threads left are \(lens.map(String.init).joined(separator: ", ")) letters"; shakeTick += 1
        case .dupe: toast = "Already tried that"
        case .notWord(let w): toast = "\(w.uppercased()) isn't a word"; shakeTick += 1; st.sel = []
        case .pull(let j, let w):
            toast = w.uppercased()
            leaving = Set(st.o.indices.filter { st.o[$0] == j })
            for i in leaving { st.removed[i] = true }
            st.pulled.append(j); st.attempts.append(true); st.sel = []
            Haptics.success()
            if st.pulled.count == st.w.count { st.status = .won; finish() }
        case .knot(let w):
            st.tried.append(w); st.knots += 1; st.attempts.append(false); st.sel = []
            toast = "\(w.uppercased()) is a word, but it isn't one of these threads"
            Haptics.error(); shakeTick += 1
            if st.knots >= TangleModel.maxKnots { st.status = .lost; finish() }
        }
        persist()
    }

    /// The first bead of the longest thread still tangled.
    func hintBead() -> Hint? {
        let rem = remaining
        guard let j = rem.sorted(by: { st.w[$0].count > st.w[$1].count || (st.w[$0].count == st.w[$1].count && $0 < $1) }).first else { return nil }
        guard let i = st.o.indices.first(where: { st.o[$0] == j && !st.removed[$0] }), !st.hints.contains(where: { $0.i == i }) else { return nil }
        return Hint(i: i, j: j)
    }

    func hint() {
        guard isPlaying, let h = hintBead() else { return }
        st.hints.append(h); st.knots += 1
        toast = "That bead starts the \(st.w[h.j].count)-letter thread · 1 knot"
        if st.knots >= TangleModel.maxKnots { st.status = .lost; finish() }
        persist()
    }

    private func finish() { if st.mode == .daily, st.day == DailyClock.dayIndex() { StatsStore.record(.tangle, day: st.day, didWin: st.status == .won, bucket: st.knots) } }
    func persist() { if st.mode == .daily { Persist.save(st, key: "tangle.day.\(st.day)") } }

    func startPractice() {
        let n = lib.tangle.puzzles.count
        var idx: Int
        repeat { idx = Int.random(in: 0..<n) } while n > 1 && idx == lib.index(for: DailyClock.dayIndex(), in: .tangle)
        st = TangleModel.newState(lib.tangle.puzzles[idx], mode: .practice, day: st.day)
    }

    var shareText: String {
        let head = st.mode == .daily ? "Tangle #\(st.day + 1)" : "Tangle (practice)"
        let tail = st.status == .won ? (st.knots == 0 ? "No knots" : "\(st.knots) knot\(st.knots == 1 ? "" : "s")") : "\(st.pulled.count)/3 threads"
        return "\(head)\n\(emoji)\n\(tail)"
    }
    var resultTitle: String {
        switch st.status { case .won: st.knots == 0 ? "Clean pull." : "Untangled."; case .lost: "Knotted up."; case .playing: "" }
    }
}
