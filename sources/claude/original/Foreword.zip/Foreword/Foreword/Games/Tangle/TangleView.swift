import SwiftUI

struct TangleView: View {
    @State private var model: TangleModel
    init(day: Int = DailyClock.dayIndex()) { _model = State(initialValue: TangleModel(day: day)) }
    @Environment(StoreManager.self) private var store
    @State private var showHelp = !UserDefaults.standard.bool(forKey: "seen.tangle")
    @State private var showResult = false
    @State private var showPaywall = false
    @State private var paywallReason: String? = nil
    private let p = GameID.tangle.palette
    private let threadColors: [Color] = [.adaptive(0xE25B4A, 0xFF7A69), .adaptive(0x1F9A8C, 0x36C9B7), .adaptive(0xD9A520, 0xF2C14E)]
    private let threadInks: [Color] = [.white, .white, .adaptive(0x2E2300, 0x2E2300)]

    var body: some View {
        ScrollView {
            VStack(spacing: 10) {
                hud
                threads
                tangle
                needle
                Text("Three words, shuffled together. Each keeps its letter order.").font(.footnote).foregroundStyle(p.muted)
            }
            .padding(16)
        }
        .background(p.bg.ignoresSafeArea())
        .navigationTitle("Tangle")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 4) {
                    Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }
                    Button { showResult = true } label: { Image(systemName: "chart.bar") }.disabled(model.isPlaying)
                }
            }
        }
        .toast($model.toast, palette: p)
        .onChange(of: model.st.status) { _, s in if s != .playing { Task { try? await Task.sleep(for: .seconds(0.9)); showResult = true } } }
        .onAppear { if !model.isPlaying { showResult = true } }
        .sheet(isPresented: $showHelp, onDismiss: { UserDefaults.standard.set(true, forKey: "seen.tangle") }) { help }
        .sheet(isPresented: $showResult) { result }
        .sheet(isPresented: $showPaywall) { PaywallView(reason: paywallReason) }
    }

    private var hud: some View {
        HStack {
            MistakeDots(total: TangleModel.maxKnots, used: model.st.knots, palette: p)
            Text(hudText).font(.system(size: 13, weight: .medium)).foregroundStyle(p.muted)
            Spacer()
            Button {
                let ent = Entitlements(isPlus: store.isPlus)
                if ent.canHint(.tangle, day: model.day) || model.st.mode == .practice {
                    if model.st.mode == .daily { Entitlements.noteHintUsed(.tangle, day: model.day) }
                    model.hint()
                } else { paywallReason = "You've used today's free hint. Plus members get unlimited hints across all four games."; showPaywall = true }
            } label: {
                Text("Loose end · costs 1").font(.system(size: 12, weight: .semibold)).padding(.horizontal, 10).padding(.vertical, 6)
                    .background(p.surface, in: Capsule()).overlay(Capsule().stroke(p.line))
            }
            .foregroundStyle(p.fg)
            .disabled(!model.isPlaying || model.hintBead() == nil)
            .opacity(!model.isPlaying || model.hintBead() == nil ? 0.45 : 1)
        }
    }

    private var hudText: String {
        switch model.st.status {
        case .won: return "Untangled!"
        case .lost: return "Knotted up."
        case .playing:
            let left = TangleModel.maxKnots - model.st.knots, n = 3 - model.st.pulled.count
            return "\(n) thread\(n == 1 ? "" : "s") left · \(left) knot\(left == 1 ? "" : "s") to spare"
        }
    }

    private var threads: some View {
        let order = model.st.w.indices.sorted { model.st.w[$0].count < model.st.w[$1].count || (model.st.w[$0].count == model.st.w[$1].count && $0 < $1) }
        return VStack(spacing: 8) {
            ForEach(order, id: \.self) { j in
                let done = model.st.pulled.contains(j), lost = model.st.status == .lost && !done
                HStack(spacing: 8) {
                    Text("\(model.st.w[j].count) letters").font(.system(size: 11, weight: .semibold)).tracking(1).foregroundStyle(p.muted).frame(width: 60, alignment: .trailing)
                    ZStack {
                        RoundedRectangle(cornerRadius: 2).fill(done || lost ? (lost ? p.bad : threadColors[j]) : p.line).frame(height: 3)
                        HStack(spacing: 5) {
                            ForEach(Array(model.st.w[j].enumerated()), id: \.offset) { _, ch in
                                if done || lost {
                                    Text(String(ch).uppercased()).font(.system(size: 16, weight: .heavy, design: .rounded)).frame(width: 30, height: 30)
                                        .background(lost ? p.bad : threadColors[j], in: Circle()).foregroundStyle(lost ? .white : threadInks[j])
                                } else {
                                    Circle().strokeBorder(style: StrokeStyle(lineWidth: 2, dash: [4])).foregroundStyle(p.line).background(Circle().fill(p.bg)).frame(width: 30, height: 30)
                                }
                            }
                            Spacer(minLength: 0)
                        }
                    }
                }
                .animation(.easeOut(duration: 0.3), value: done)
            }
        }
    }

    private var tangle: some View {
        Group {
            if model.isPlaying {
                FlowLayout(spacing: 6, lineSpacing: 8) {
                    ForEach(Array(model.st.s.enumerated()), id: \.offset) { i, ch in
                        if !model.st.removed[i] {
                            let selected = model.st.sel.contains(i)
                            let hint = model.st.hints.first { $0.i == i }
                            Button { model.toggle(i) } label: {
                                Text(String(ch).uppercased()).font(.system(size: 22, weight: .heavy, design: .rounded))
                                    .frame(width: 42, height: 42)
                                    .background(selected ? p.accent : p.surface, in: Circle())
                                    .overlay(Circle().stroke(selected ? p.accent : p.line, lineWidth: 2))
                                    .overlay { if let hint { Circle().stroke(threadColors[hint.j], lineWidth: 3).padding(-3) } }
                                    .foregroundStyle(selected ? p.accentInk : p.fg)
                                    .offset(y: selected ? -6 : 0)
                            }
                            .buttonStyle(.plain)
                            .modifier(Shake(animatableData: CGFloat(selected ? model.shakeTick : 0)))
                            .animation(.default, value: model.shakeTick)
                            .transition(.scale.combined(with: .opacity))
                        }
                    }
                }
                .animation(.easeOut(duration: 0.25), value: model.st.pulled.count)
            } else {
                Text(model.st.status == .won ? "Every thread pulled clean." : "The threads are shown above.").font(.system(size: 14)).foregroundStyle(p.muted)
            }
        }
        .padding(.vertical, 18).padding(.horizontal, 6)
        .frame(maxWidth: .infinity)
        .background(p.surface, in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(p.line))
    }

    private var needle: some View {
        HStack(spacing: 8) {
            Group {
                if model.selectedWord.isEmpty { Text(model.isPlaying ? "Tap the beads of one word, in any order." : "").font(.system(size: 14)).foregroundStyle(p.muted) }
                else { Text(model.selectedWord.uppercased()).font(.system(size: 26, weight: .heavy, design: .rounded)).tracking(3).lineLimit(1).minimumScaleFactor(0.5) }
            }
            Spacer(minLength: 4)
            Button { model.clear() } label: { Text("Clear").font(.system(size: 14, weight: .semibold)).frame(height: 40).padding(.horizontal, 12).background(p.key, in: RoundedRectangle(cornerRadius: 9)) }
                .foregroundStyle(p.fg).disabled(model.st.sel.isEmpty)
            Button { model.pull() } label: { Text("Pull").font(.system(size: 14, weight: .bold)).frame(height: 40).padding(.horizontal, 14).background(p.accent, in: RoundedRectangle(cornerRadius: 9)) }
                .foregroundStyle(p.accentInk).disabled(!model.isPlaying || model.selectedWord.isEmpty)
        }
        .padding(.leading, 14).padding(.trailing, 6).padding(.vertical, 6)
        .frame(maxWidth: .infinity, minHeight: 56)
        .background(p.surface, in: RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(p.line))
    }

    private var help: some View {
        HowToSheet(game: .tangle) {
            Text("Three words have been tangled into one string. Each word's letters stay in order, but the words are shuffled together. Pull them apart.")
            FlowLayout(spacing: 4, lineSpacing: 4) {
                ForEach(Array("pslilanveetr".enumerated()), id: \.offset) { i, ch in
                    let a = [0, 2, 5, 6, 8, 10].contains(i)
                    Text(String(ch).uppercased()).font(.system(size: 14, weight: .heavy, design: .rounded)).frame(width: 26, height: 26)
                        .background(a ? threadColors[0] : threadColors[1], in: Circle()).foregroundStyle(.white)
                }
            }
            Text("PLANET and SILVER, tangled.").font(.footnote).foregroundStyle(p.muted).frame(maxWidth: .infinity)
            Text("Tap the beads that make up one word, in any order, then Pull. Pulling a real word of the right length that isn't one of today's threads ties a knot. Four knots and the tangle is lost. Non-words cost nothing.")
            Text("\"Loose end\" marks the first bead of the longest thread still tangled; it costs a knot. New tangle every day at midnight.").font(.footnote).foregroundStyle(p.muted)
        }
    }

    private var result: some View {
        ResultSheet(game: .tangle, title: model.resultTitle, emoji: model.emoji, mode: model.st.mode, shareText: model.shareText, stats: StatsStore.load(.tangle), onPractice: practice) {
            VStack(spacing: 6) {
                ForEach(model.st.w.indices, id: \.self) { j in
                    let missed = model.st.status != .won && !model.st.pulled.contains(j)
                    HStack(spacing: 4) {
                        ForEach(Array(model.st.w[j].enumerated()), id: \.offset) { _, ch in
                            Text(String(ch).uppercased()).font(.system(size: 15, weight: .heavy, design: .rounded)).frame(width: 28, height: 28)
                                .background(missed ? p.bad : threadColors[j], in: Circle()).foregroundStyle(missed ? .white : threadInks[j])
                        }
                    }
                }
            }
        }
    }

    private func practice() {
        if Entitlements(isPlus: store.isPlus).canPractice(day: model.day) {
            if !store.isPlus { Entitlements.notePracticeUsed(day: model.day) }
            model.startPractice()
        } else { paywallReason = "That's today's free practice puzzle. Plus members untangle as many as they like, and can play every past tangle."; showPaywall = true }
    }
}
