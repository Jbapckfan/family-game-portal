import Foundation
import Observation

/// Tumbler: a five-letter lock. Each dial reports whether the secret letter is later (▲), earlier (▼) or locked (●).
@MainActor
@Observable
final class TumblerModel {
    static let maxGuesses = 6
    static let alphabet = Array("abcdefghijklmnopqrstuvwxyz")

    struct Guess: Codable, Hashable { var w: String; var f: [Int] }   // f: 0 locked, 1 secret later, -1 secret earlier

    struct State: Codable {
        var mode: PlayMode
        var day: Int
        var secret: String
        var guesses: [Guess]
        var typed: String
        var status: GameStatus
    }

    struct Ranges { var lo: [Int]; var hi: [Int]; var lock: [Bool] }

    private let lib = PuzzleLibrary.shared
    private(set) var st: State
    var toast: String?
    var shakeTick = 0

    var day: Int { st.day }
    var isPlaying: Bool { st.status == .playing }

    init(day: Int) {
        if let saved = Persist.load(State.self, key: "tumbler.day.\(day)"), saved.secret.count == 5 { st = saved }
        else { st = TumblerModel.newState(lib.tumbler.answers[lib.index(for: day, in: .tumbler)], mode: .daily, day: day) }
    }

    static func newState(_ secret: String, mode: PlayMode, day: Int) -> State { State(mode: mode, day: day, secret: secret, guesses: [], typed: "", status: .playing) }

    static func feedback(_ guess: String, _ secret: String) -> [Int] {
        zip(Array(guess), Array(secret)).map { g, s in g == s ? 0 : (s > g ? 1 : -1) }
    }

    static func emojiLine(_ s: State) -> String {
        switch s.status {
        case .won: "🔓 \(s.guesses.count)/\(maxGuesses)"
        case .lost: "🔒 ✕/\(maxGuesses)"
        case .playing: "\(s.guesses.count)/\(maxGuesses)"
        }
    }
    static func rowEmoji(_ f: [Int]) -> String { f.map { $0 == 0 ? "🟩" : $0 > 0 ? "🔼" : "🔽" }.joined() }
    static func emoji(_ s: State) -> String { s.guesses.isEmpty ? "⬜⬜⬜⬜⬜" : s.guesses.map { rowEmoji($0.f) }.joined(separator: "\n") }
    var emoji: String { TumblerModel.emoji(st) }

    static func summary(day: Int) -> DailySummary? {
        guard let s = Persist.load(State.self, key: "tumbler.day.\(day)") else { return nil }
        if s.status == .playing, s.guesses.isEmpty { return nil }
        return DailySummary(status: s.status, emoji: emojiLine(s), detail: s.status == .playing ? "\(s.guesses.count) of \(maxGuesses) tried" : s.status == .won ? "\(s.guesses.count) guess\(s.guesses.count == 1 ? "" : "es")" : "still locked")
    }

    var ranges: Ranges {
        var r = Ranges(lo: Array(repeating: 0, count: 5), hi: Array(repeating: 25, count: 5), lock: Array(repeating: false, count: 5))
        for g in st.guesses {
            for (i, ch) in g.w.enumerated() {
                let v = TumblerModel.alphabet.firstIndex(of: ch) ?? 0
                if g.f[i] == 0 { r.lo[i] = v; r.hi[i] = v; r.lock[i] = true }
                else if g.f[i] > 0 { r.lo[i] = max(r.lo[i], v + 1) }
                else { r.hi[i] = min(r.hi[i], v - 1) }
            }
        }
        return r
    }

    /// "dead" when the letter is impossible in every position, "lock" when it is a confirmed letter.
    func keyState(_ ch: Character) -> String {
        let r = ranges, v = TumblerModel.alphabet.firstIndex(of: ch) ?? 0
        if (0..<5).contains(where: { r.lock[$0] && st.secret[$0] == ch }) { return "lock" }
        return (0..<5).allSatisfy({ v < r.lo[$0] || v > r.hi[$0] }) ? "dead" : ""
    }

    func key(_ k: String) {
        guard isPlaying else { return }
        switch k {
        case "ENTER": submit()
        case "BACK": if !st.typed.isEmpty { st.typed.removeLast() }
        default: if k.count == 1, k.first!.isLetter, st.typed.count < 5 { st.typed += k.lowercased() }
        }
    }

    func submit() {
        let w = st.typed
        if w.count < 5 { toast = "Five letters"; shakeTick += 1; return }
        if st.guesses.contains(where: { $0.w == w }) { toast = "Already tried"; shakeTick += 1; return }
        if !lib.tumblerGuess.contains(w), w != st.secret { toast = "Not in word list"; shakeTick += 1; return }
        let f = TumblerModel.feedback(w, st.secret)
        st.guesses.append(Guess(w: w, f: f)); st.typed = ""
        if f.allSatisfy({ $0 == 0 }) { st.status = .won; toast = "\(w.uppercased()) · unlocked"; Haptics.success() }
        else if st.guesses.count >= TumblerModel.maxGuesses { st.status = .lost; toast = "It was \(st.secret.uppercased())"; Haptics.error() }
        else { let locked = f.filter { $0 == 0 }.count; toast = locked > 0 ? "\(locked) dial\(locked == 1 ? "" : "s") locked" : "Feel the arrows"; Haptics.tap() }
        persist()
        if st.status != .playing, st.mode == .daily, st.day == DailyClock.dayIndex() { StatsStore.record(.tumbler, day: st.day, didWin: st.status == .won, bucket: st.guesses.count - 1) }
    }

    func persist() { if st.mode == .daily { Persist.save(st, key: "tumbler.day.\(st.day)") } }

    func startPractice() {
        let a = lib.tumbler.answers
        var s: String
        repeat { s = a.randomElement()! } while a.count > 1 && s == a[lib.index(for: DailyClock.dayIndex(), in: .tumbler)]
        st = TumblerModel.newState(s, mode: .practice, day: st.day)
    }

    var shareText: String { "Tumbler \(st.mode == .daily ? "#\(st.day + 1)" : "(practice)") \(TumblerModel.emojiLine(st))\n\(emoji)" }
    var resultTitle: String {
        switch st.status {
        case .won: st.guesses.count <= 2 ? "Safecracker." : st.guesses.count <= 4 ? "Click. Open." : "Open, just."
        case .lost: "Still locked."
        case .playing: ""
        }
    }
}
