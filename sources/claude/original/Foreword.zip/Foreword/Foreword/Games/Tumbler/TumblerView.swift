import SwiftUI

struct TumblerView: View {
    @State private var model: TumblerModel
    init(day: Int = DailyClock.dayIndex()) { _model = State(initialValue: TumblerModel(day: day)) }
    @Environment(StoreManager.self) private var store
    @State private var showHelp = !UserDefaults.standard.bool(forKey: "seen.tumbler")
    @State private var showResult = false
    @State private var showPaywall = false
    @State private var paywallReason: String? = nil
    private let p = GameID.tumbler.palette
    private let dial = Color.hex(0x2A3038), dialWin = Color.hex(0x11141A), dialEdge = Color.hex(0x3B434D)

    var body: some View {
        VStack(spacing: 0) {
            ScrollView {
                VStack(spacing: 10) {
                    hud
                    dials
                    rows
                    Text("▲ the secret letter is later in the alphabet · ▼ earlier · ● locked. Each dial shows its remaining range.")
                        .font(.footnote).foregroundStyle(p.muted).multilineTextAlignment(.center)
                }
                .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 12)
            }
            if model.isPlaying {
                TumblerKeyboard(palette: p, state: { model.keyState($0) }) { model.key($0) }
                    .padding(.horizontal, 8).padding(.top, 8).padding(.bottom, 6)
                    .background(p.bg.shadow(.drop(color: .black.opacity(0.3), radius: 8, y: -2)))
            }
        }
        .background(p.bg.ignoresSafeArea())
        .preferredColorScheme(.dark)
        .navigationTitle("Tumbler")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 4) {
                    Button { showHelp = true } label: { Image(systemName: "questionmark.circle") }
                    Button { showResult = true } label: { Image(systemName: "chart.bar") }.disabled(model.isPlaying)
                }
            }
        }
        .toast($model.toast, palette: p)
        .onChange(of: model.st.status) { _, s in if s != .playing { Task { try? await Task.sleep(for: .seconds(1.0)); showResult = true } } }
        .onAppear { if !model.isPlaying { showResult = true } }
        .sheet(isPresented: $showHelp, onDismiss: { UserDefaults.standard.set(true, forKey: "seen.tumbler") }) { help }
        .sheet(isPresented: $showResult) { result }
        .sheet(isPresented: $showPaywall) { PaywallView(reason: paywallReason) }
    }

    private var hud: some View {
        let r = model.ranges, left = TumblerModel.maxGuesses - model.st.guesses.count
        return HStack {
            HStack(spacing: 6) { ForEach(0..<TumblerModel.maxGuesses, id: \.self) { i in Circle().fill(i < model.st.guesses.count ? p.accent : p.line).frame(width: 11, height: 11).shadow(color: i < model.st.guesses.count ? p.accent : .clear, radius: 4) } }
            Text(model.st.status == .won ? "Unlocked." : model.st.status == .lost ? "It was \(model.st.secret.uppercased())." : "\(left) guess\(left == 1 ? "" : "es") left").font(.system(size: 13, weight: .medium)).foregroundStyle(p.muted)
            Spacer()
            Text("\(r.lock.filter { $0 }.count) of 5 locked").font(.system(size: 13, weight: .medium)).foregroundStyle(p.muted)
        }
    }

    private var dials: some View {
        let r = model.ranges, A = TumblerModel.alphabet
        return HStack(spacing: 8) {
            ForEach(0..<5, id: \.self) { i in
                let locked = r.lock[i]
                let ch: String = locked ? String(model.st.secret[i]) : (i < model.st.typed.count ? String(model.st.typed[i]) : "")
                VStack(spacing: 0) {
                    Text(locked ? " " : String(A[r.hi[i]]).uppercased()).font(.system(size: 13, weight: .semibold, design: .monospaced)).foregroundStyle(locked ? p.good : p.muted).padding(.top, 5).padding(.bottom, 2)
                    Text(ch.uppercased()).font(.system(size: 30, weight: .bold, design: .monospaced))
                        .frame(maxWidth: .infinity, minHeight: 58)
                        .background(locked ? p.good : dialWin)
                        .foregroundStyle(locked ? p.goodInk : (!ch.isEmpty ? p.accent : p.fg))
                        .overlay(Rectangle().fill(dialEdge).frame(height: 1), alignment: .top)
                        .overlay(Rectangle().fill(dialEdge).frame(height: 1), alignment: .bottom)
                    Text(locked ? " " : String(A[r.lo[i]]).uppercased()).font(.system(size: 13, weight: .semibold, design: .monospaced)).foregroundStyle(p.muted).padding(.top, 2).padding(.bottom, 2)
                    Text(locked ? "locked" : "\(r.hi[i] - r.lo[i] + 1) left").font(.system(size: 10)).monospacedDigit().foregroundStyle(p.muted).padding(.bottom, 5)
                }
                .frame(maxWidth: .infinity)
                .background(dial, in: RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).stroke(dialEdge))
            }
        }
        .modifier(Shake(animatableData: CGFloat(model.shakeTick)))
        .animation(.default, value: model.shakeTick)
    }

    private var rows: some View {
        VStack(spacing: 6) {
            ForEach(0..<TumblerModel.maxGuesses, id: \.self) { k in
                HStack(spacing: 8) {
                    ForEach(0..<5, id: \.self) { i in
                        if k < model.st.guesses.count {
                            let g = model.st.guesses[k], eq = g.f[i] == 0
                            HStack(spacing: 4) {
                                Text(String(g.w[i]).uppercased()).font(.system(size: 20, weight: .bold, design: .monospaced))
                                Text(eq ? "●" : g.f[i] > 0 ? "▲" : "▼").font(.system(size: 12)).foregroundStyle(eq ? p.goodInk : p.accent)
                            }
                            .frame(maxWidth: .infinity, minHeight: 40)
                            .background(eq ? p.good : p.surface, in: RoundedRectangle(cornerRadius: 8))
                            .overlay(RoundedRectangle(cornerRadius: 8).stroke(eq ? .clear : p.line))
                            .foregroundStyle(eq ? p.goodInk : p.fg)
                        } else {
                            RoundedRectangle(cornerRadius: 8).strokeBorder(style: StrokeStyle(lineWidth: 1, dash: [4])).foregroundStyle(p.line).frame(maxWidth: .infinity, minHeight: 40).opacity(0.5)
                        }
                    }
                }
            }
        }
    }

    private var help: some View {
        HowToSheet(game: .tumbler) {
            Text("A five-letter word is locked behind five dials. Guess any five-letter word; each dial then tells you which way to turn.")
            HStack(spacing: 8) {
                ForEach(Array(zip("CRANE", ["▲", "▼", "●", "▼", "▲"]).enumerated()), id: \.offset) { _, pair in
                    Text("\(String(pair.0)) \(pair.1)").font(.system(size: 14, weight: .bold, design: .monospaced)).padding(.horizontal, 8).padding(.vertical, 4)
                        .background(pair.1 == "●" ? p.good : p.surface, in: RoundedRectangle(cornerRadius: 6)).foregroundStyle(pair.1 == "●" ? p.goodInk : p.fg)
                }
            }.frame(maxWidth: .infinity)
            Text("▲ means the secret letter in that position is later in the alphabet than yours. ▼ means earlier. ● means you locked it. Nothing about other positions: this is a lock, not a word-scramble.")
            Text("Each dial shows the range still possible. Narrow all five in six guesses.")
            Text("Letters that are impossible in every position fade on the keyboard.").font(.footnote).foregroundStyle(p.muted)
        }
        .preferredColorScheme(.dark)
    }

    private var result: some View {
        ResultSheet(game: .tumbler, title: model.resultTitle, emoji: model.emoji, mode: model.st.mode, shareText: model.shareText, stats: StatsStore.load(.tumbler), onPractice: practice) {
            Text(model.st.secret.uppercased()).font(.system(size: 28, weight: .bold, design: .monospaced)).tracking(6).foregroundStyle(p.accent)
        }
        .preferredColorScheme(.dark)
    }

    private func practice() {
        if Entitlements(isPlus: store.isPlus).canPractice(day: model.day) {
            if !store.isPlus { Entitlements.notePracticeUsed(day: model.day) }
            model.startPractice()
        } else { paywallReason = "That's today's free practice puzzle. Plus members crack as many locks as they like, and every past day."; showPaywall = true }
    }
}

/// Keyboard with per-key state (dead / lock) for Tumbler.
struct TumblerKeyboard: View {
    let palette: Palette
    let state: (Character) -> String
    let onKey: (String) -> Void
    private let rows = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]
    var body: some View {
        VStack(spacing: 6) {
            ForEach(Array(rows.enumerated()), id: \.offset) { i, row in
                HStack(spacing: 5) {
                    if i == 2 { wide("ENTER", label: "Enter") }
                    ForEach(Array(row), id: \.self) { ch in
                        let s = state(ch)
                        Button { onKey(String(ch)) } label: {
                            Text(String(ch).uppercased()).font(.system(size: 18, weight: .semibold).width(.condensed))
                                .frame(maxWidth: .infinity, minHeight: 48)
                                .background(s == "lock" ? palette.good : palette.key, in: RoundedRectangle(cornerRadius: 6))
                                .foregroundStyle(s == "lock" ? palette.goodInk : palette.fg)
                                .opacity(s == "dead" ? 0.28 : 1)
                        }
                    }
                    if i == 2 { wide("BACK", label: "⌫") }
                }
                .padding(.horizontal, i == 1 ? 18 : 0)
            }
        }
    }
    private func wide(_ key: String, label: String) -> some View {
        Button { onKey(key) } label: {
            Text(label).font(.system(size: 13, weight: .semibold)).frame(maxWidth: .infinity, minHeight: 48).background(palette.line, in: RoundedRectangle(cornerRadius: 6))
        }
        .foregroundStyle(palette.fg).frame(maxWidth: 64)
    }
}
