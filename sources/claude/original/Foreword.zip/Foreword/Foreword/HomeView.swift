import SwiftUI

struct HomeView: View {
    @Environment(StoreManager.self) private var store
    @State private var day = DailyClock.dayIndex()
    @State private var showPaywall = false
    @State private var showStats = false
    @State private var showArchive = false
    @State private var refresh = 0
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    header
                    meter
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 10), GridItem(.flexible(), spacing: 10)], spacing: 10) {
                        ForEach(GameID.allCases) { g in
                            NavigationLink { destination(g) } label: { GameTile(game: g, summary: summary(g)) }
                                .buttonStyle(.plain)
                        }
                    }
                    footer
                }
                .padding(16)
            }
            .background(Color(uiColor: .systemGroupedBackground).ignoresSafeArea())
            .navigationTitle("")
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showPaywall) { PaywallView() }
            .sheet(isPresented: $showStats) { StatsOverview() }
            .sheet(isPresented: $showArchive) { ArchiveView(day: day) }
            .onAppear { day = DailyClock.dayIndex(); refresh += 1 }
            .onChange(of: scenePhase) { _, phase in if phase == .active { day = DailyClock.dayIndex(); refresh += 1 } }
        }
    }

    @ViewBuilder private func destination(_ g: GameID) -> some View {
        switch g {
        case .dovetail: DovetailView()
        case .splice: SpliceView()
        case .sprout: SproutView()
        case .tangle: TangleView()
        case .keystone: KeystoneView()
        case .tumbler: TumblerView()
        }
    }

    private func summary(_ g: GameID) -> DailySummary? {
        _ = refresh
        switch g {
        case .dovetail: return DovetailModel.summary(day: day)
        case .splice: return SpliceModel.summary(day: day)
        case .sprout: return SproutModel.summary(day: day)
        case .tangle: return TangleModel.summary(day: day)
        case .keystone: return KeystoneModel.summary(day: day)
        case .tumbler: return TumblerModel.summary(day: day)
        }
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Foreword").font(.system(size: 34, weight: .bold, design: .serif))
                Text("No. \(day + 1) · \(Date.now.formatted(.dateTime.weekday(.wide).month(.abbreviated).day()))").font(.subheadline).foregroundStyle(.secondary)
            }
            Spacer()
            Button { showPaywall = true } label: {
                Label(store.isPlus ? "Plus" : "Get Plus", systemImage: store.isPlus ? "checkmark.seal.fill" : "sparkles")
                    .font(.system(size: 13, weight: .bold))
                    .padding(.horizontal, 12).padding(.vertical, 8)
                    .background(store.isPlus ? AnyShapeStyle(HierarchicalShapeStyle.quaternary) : AnyShapeStyle(TintShapeStyle()), in: Capsule())
                    .foregroundStyle(store.isPlus ? Color.primary : Color.white)
            }
        }
        .padding(.top, 8)
    }

    private var sixDone: Bool { GameID.allCases.allSatisfy { summary($0)?.status != nil && summary($0)?.status != .playing } }
    private var sixText: String { "Foreword #\(day + 1)\n" + GameID.allCases.map { "\($0.title) \(summary($0)?.emoji ?? "—")" }.joined(separator: "\n") }

    private var meter: some View {
        let played = GameID.allCases.filter { summary($0) != nil && summary($0)?.status != .playing }.count
        let won = GameID.allCases.filter { summary($0)?.status == .won }.count
        return VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .firstTextBaseline) {
                Text(sixDone ? (won == 6 ? "A perfect six." : "All six done.") : "Today's six").font(.system(size: 20, weight: .semibold, design: .serif))
                Spacer()
                Text(sixDone ? "\(won) of 6 solved" : "\(played) of 6 played").font(.subheadline).foregroundStyle(.secondary)
            }
            HStack(spacing: 5) {
                ForEach(GameID.allCases) { g in
                    let s = summary(g)
                    Capsule().fill(s != nil && s?.status != .playing ? g.palette.accent : Color(uiColor: .tertiarySystemFill)).frame(height: 9)
                        .overlay(alignment: .leading) { if s?.status == .playing { Capsule().fill(g.palette.accent).frame(width: 20, height: 9) } }
                }
            }
            if sixDone {
                ShareLink(item: sixText) { Label("Share today's six", systemImage: "square.and.arrow.up").font(.system(size: 15, weight: .bold)).frame(maxWidth: .infinity, minHeight: 44).background(Color.accentColor, in: RoundedRectangle(cornerRadius: 12)).foregroundStyle(Color.white) }
            }
        }
        .padding(16)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 16))
    }

    private var footer: some View {
        HStack(spacing: 10) {
            footerButton("Statistics", "chart.bar") { showStats = true }
            footerButton("Archive", store.isPlus ? "calendar" : "lock.fill") { if store.isPlus { showArchive = true } else { showPaywall = true } }
        }
        .padding(.top, 4)
    }

    private func footerButton(_ t: String, _ sym: String, _ a: @escaping () -> Void) -> some View {
        Button(action: a) {
            Label(t, systemImage: sym).font(.system(size: 14, weight: .semibold))
                .frame(maxWidth: .infinity, minHeight: 44)
                .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12))
        }
        .foregroundStyle(.primary)
    }
}

struct GameTile: View {
    let game: GameID
    let summary: DailySummary?
    var body: some View {
        let p = game.palette
        let stats = StatsStore.load(game)
        VStack(alignment: .leading, spacing: 8) {
            Image(systemName: game.symbol)
                .font(.system(size: 18, weight: .semibold))
                .frame(width: 40, height: 40)
                .background(p.accent.opacity(0.18), in: RoundedRectangle(cornerRadius: 12))
                .foregroundStyle(p.accent)
            Text(game.title).font(.system(size: 22, weight: .semibold, design: .serif)).lineLimit(1).minimumScaleFactor(0.8)
            Text(game.tagline).font(.system(size: 12)).foregroundStyle(.secondary).lineLimit(2).frame(minHeight: 32, alignment: .top)
            HStack(spacing: 6) {
                switch summary?.status {
                case .some(.won): Text(summary!.emoji).font(.system(size: 10)).lineLimit(1).minimumScaleFactor(0.6)
                case .some(.lost): Text(summary!.detail).font(.caption.weight(.bold)).foregroundStyle(.secondary)
                case .some(.playing): Text("In progress").font(.caption.weight(.bold)).foregroundStyle(p.accent)
                case .none: Text("Play").font(.caption.weight(.bold)).foregroundStyle(p.accent)
                }
                Spacer(minLength: 0)
                if stats.streak > 0 { Text("🔥\(stats.streak)").font(.caption.weight(.bold)).foregroundStyle(.secondary) }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 18))
        .overlay(alignment: .leading) { UnevenRoundedRectangle(topLeadingRadius: 18, bottomLeadingRadius: 18).fill(p.accent).frame(width: 6) }
        .clipShape(RoundedRectangle(cornerRadius: 18))
    }
}

struct StatsOverview: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                ForEach(GameID.allCases) { g in
                    let s = StatsStore.load(g)
                    Section(g.title) {
                        StatsGrid(stats: s, palette: g.palette).padding(.vertical, 6)
                        let mx = max(1, s.dist.max() ?? 1)
                        ForEach(Array(s.dist.enumerated()), id: \.offset) { k, v in
                            HStack(spacing: 8) {
                                Text("\(k)").font(.caption.monospacedDigit()).frame(width: 16)
                                GeometryReader { geo in
                                    RoundedRectangle(cornerRadius: 3).fill(v > 0 ? g.palette.accent : g.palette.line)
                                        .frame(width: max(18, geo.size.width * CGFloat(v) / CGFloat(mx)))
                                        .overlay(alignment: .trailing) { Text("\(v)").font(.caption2.bold()).foregroundStyle(v > 0 ? g.palette.accentInk : .secondary).padding(.trailing, 5) }
                                }
                                .frame(height: 16)
                            }
                        }
                        Text(g == .keystone ? "Wins by score bracket (6–7, 8–9, …)" : g == .tumbler ? "Wins by guesses (1–6)" : "Wins by mistakes made").font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
            .navigationTitle("Statistics")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
    }
}

/// Plus-only: every past puzzle, playable. Progress on a past day is saved like any other day; streaks only count today.
struct ArchiveView: View {
    let day: Int
    @Environment(\.dismiss) private var dismiss
    @State private var game: GameID = .dovetail
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("Game", selection: $game) { ForEach(GameID.allCases) { g in Text(g.title).tag(g) } }
                    .pickerStyle(.segmented).padding()
                List {
                    ForEach((0..<max(day, 0)).reversed(), id: \.self) { d in
                        let s = summary(game, d)
                        NavigationLink { destination(game, d) } label: {
                            HStack {
                                Text("No. \(d + 1)").font(.headline.monospacedDigit())
                                Text(dateLabel(d)).font(.subheadline).foregroundStyle(.secondary)
                                Spacer()
                                if let s { Text(s.status == .playing ? "In progress" : s.emoji).font(.caption) } else { Text("Not played").font(.caption).foregroundStyle(.secondary) }
                            }
                        }
                    }
                    if day == 0 { Text("The archive fills up from tomorrow. Today's puzzle is No. 1.").foregroundStyle(.secondary) }
                }
                .listStyle(.plain)
            }
            .navigationTitle("Archive")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Done") { dismiss() } } }
        }
    }
    private func dateLabel(_ d: Int) -> String {
        let date = Calendar.current.date(byAdding: .day, value: d, to: DailyClock.epoch) ?? .now
        return date.formatted(.dateTime.month(.abbreviated).day())
    }
    private func summary(_ g: GameID, _ d: Int) -> DailySummary? {
        switch g {
        case .dovetail: DovetailModel.summary(day: d)
        case .splice: SpliceModel.summary(day: d)
        case .sprout: SproutModel.summary(day: d)
        case .tangle: TangleModel.summary(day: d)
        case .keystone: KeystoneModel.summary(day: d)
        case .tumbler: TumblerModel.summary(day: d)
        }
    }
    @ViewBuilder private func destination(_ g: GameID, _ d: Int) -> some View {
        switch g {
        case .dovetail: DovetailView(day: d)
        case .splice: SpliceView(day: d)
        case .sprout: SproutView(day: d)
        case .tangle: TangleView(day: d)
        case .keystone: KeystoneView(day: d)
        case .tumbler: TumblerView(day: d)
        }
    }
}
