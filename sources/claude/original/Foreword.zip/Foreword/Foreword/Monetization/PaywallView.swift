import SwiftUI
import StoreKit

/// The single upsell surface. Shown from locked features (practice, archive, extra hints)
/// and from the home screen badge. Keep the copy benefit-led and the choice to three options.
struct PaywallView: View {
    @Environment(StoreManager.self) private var store
    @Environment(\.dismiss) private var dismiss
    @State private var busy = false
    @State private var message: String?
    var reason: String? = nil

    private let perks: [(String, String, String)] = [
        ("calendar", "The whole archive", "Every past Dovetail, Splice, Sprout and Tangle, from No. 1."),
        ("infinity", "Unlimited practice", "Fresh puzzles whenever you want them, not one a day."),
        ("lightbulb.max", "Unlimited hints", "Hints still cost a miss inside the game, but never run out."),
        ("flame", "Streak freeze", "Miss a day and keep your streaks. Once a week, automatically."),
        ("rectangle.slash", "No ads", "No cards between puzzles, ever."),
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Foreword Plus").font(.system(size: 32, weight: .bold, design: .serif))
                        Text(reason ?? "Four daily games are free forever. Plus is for people who want more than one a day.")
                            .foregroundStyle(.secondary)
                    }
                    VStack(alignment: .leading, spacing: 14) {
                        ForEach(perks, id: \.1) { p in
                            HStack(alignment: .top, spacing: 12) {
                                Image(systemName: p.0).font(.system(size: 18, weight: .semibold)).frame(width: 28)
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(p.1).font(.headline)
                                    Text(p.2).font(.subheadline).foregroundStyle(.secondary)
                                }
                            }
                        }
                    }
                    .padding(16)
                    .background(Color.secondary.opacity(0.12), in: RoundedRectangle(cornerRadius: 14))

                    if store.products.isEmpty {
                        VStack(spacing: 8) {
                            if store.isLoading { ProgressView() }
                            Text(store.lastError ?? "Products aren't available right now. In Xcode, select the Foreword.storekit configuration in the scheme to test purchases locally.")
                                .font(.footnote).foregroundStyle(.secondary).multilineTextAlignment(.center)
                        }
                        .frame(maxWidth: .infinity)
                    } else {
                        VStack(spacing: 10) {
                            if let y = store.yearly { productRow(y, badge: "Best value", subtitle: perMonth(y)) }
                            if let m = store.monthly { productRow(m, badge: nil, subtitle: "Cancel anytime") }
                            if let l = store.lifetime { productRow(l, badge: nil, subtitle: "One payment, forever") }
                        }
                    }

                    if let message { Text(message).font(.footnote).foregroundStyle(.secondary) }

                    HStack {
                        Button("Restore purchases") { Task { busy = true; await store.restore(); busy = false; message = store.isPlus ? "Plus restored." : "No purchases found for this Apple ID." } }
                        Spacer()
                        Link("Terms", destination: URL(string: "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/")!)
                        Text("·").foregroundStyle(.secondary)
                        Link("Privacy", destination: URL(string: "https://example.com/privacy")!)
                    }
                    .font(.footnote)

                    #if DEBUG
                    Toggle("Developer: pretend I'm a Plus member", isOn: Binding(get: { store.debugPlusOverride }, set: { store.setDebugPlus($0) }))
                        .font(.footnote)
                    #endif
                }
                .padding(20)
            }
            .navigationTitle("")
            .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { dismiss() } } }
            .disabled(busy)
            .onChange(of: store.isPlus) { _, plus in if plus { dismiss() } }
        }
    }

    private func perMonth(_ p: Product) -> String {
        guard let sub = p.subscription, sub.subscriptionPeriod.unit == .year else { return "" }
        let monthly = (p.price as NSDecimalNumber).doubleValue / 12
        let f = NumberFormatter(); f.numberStyle = .currency; f.locale = p.priceFormatStyle.locale
        return (f.string(from: NSNumber(value: monthly)) ?? "") + "/month, billed yearly"
    }

    private func productRow(_ p: Product, badge: String?, subtitle: String) -> some View {
        Button {
            Task { busy = true; let ok = await store.purchase(p); busy = false; if !ok, let e = store.lastError { message = e } }
        } label: {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 8) {
                        Text(p.displayName).font(.headline)
                        if let badge { Text(badge).font(.caption2.weight(.bold)).padding(.horizontal, 6).padding(.vertical, 2).background(Color.accentColor, in: Capsule()).foregroundStyle(Color.white) }
                    }
                    Text(subtitle).font(.footnote).foregroundStyle(.secondary)
                    if let intro = p.subscription?.introductoryOffer, intro.paymentMode == .freeTrial {
                        Text("\(intro.period.value)-\(intro.period.unit == .week ? "week" : "day") free trial").font(.footnote.weight(.semibold))
                    }
                }
                Spacer()
                Text(p.displayPrice).font(.title3.weight(.bold)).monospacedDigit()
            }
            .padding(14)
            .background(Color(uiColor: .secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12))
            .overlay(RoundedRectangle(cornerRadius: 12).stroke(badge == nil ? Color.secondary.opacity(0.25) : Color.accentColor, lineWidth: badge == nil ? 1 : 2))
        }
        .buttonStyle(.plain)
    }
}

/// Placeholder for an ad network slot. Wire AdMob / AppLovin here (see MONETIZATION.md).
/// It is shown only to free players and only after a finished puzzle, never during play.
struct AdSlotView: View {
    let palette: Palette
    var body: some View {
        VStack(spacing: 4) {
            Text("SPONSORED").font(.system(size: 10, weight: .bold)).tracking(1.2).foregroundStyle(palette.muted)
            Text("Ad slot · 320×100").font(.system(size: 13)).foregroundStyle(palette.muted)
        }
        .frame(maxWidth: .infinity, minHeight: 72)
        .background(palette.key.opacity(0.5), in: RoundedRectangle(cornerRadius: 10))
        .overlay(RoundedRectangle(cornerRadius: 10).strokeBorder(style: StrokeStyle(lineWidth: 1, dash: [4])).foregroundStyle(palette.line))
    }
}
