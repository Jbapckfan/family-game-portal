import Foundation
import Observation
import StoreKit

/// StoreKit 2 wrapper. Products are configured in `Foreword.storekit` for local testing
/// and must be created with the same identifiers in App Store Connect before release.
@MainActor
@Observable
final class StoreManager {
    enum ProductID {
        static let monthly = "com.cursedtoaster.foreword.plus.monthly"
        static let yearly = "com.cursedtoaster.foreword.plus.yearly"
        static let lifetime = "com.cursedtoaster.foreword.plus.lifetime"
        static let all = [monthly, yearly, lifetime]
    }

    private(set) var products: [Product] = []
    private(set) var purchasedIDs: Set<String> = []
    private(set) var isLoading = false
    var lastError: String?
    private var updatesTask: Task<Void, Never>?

    /// Debug-only override so the paywall gates can be tested in the simulator without a sandbox account.
    private(set) var debugPlusOverride = UserDefaults.standard.bool(forKey: "debug.plus")
    func setDebugPlus(_ on: Bool) {
        debugPlusOverride = on
        UserDefaults.standard.set(on, forKey: "debug.plus")
    }

    var isPlus: Bool {
        #if DEBUG
        if debugPlusOverride { return true }
        #endif
        return !purchasedIDs.isEmpty
    }

    var monthly: Product? { products.first { $0.id == ProductID.monthly } }
    var yearly: Product? { products.first { $0.id == ProductID.yearly } }
    var lifetime: Product? { products.first { $0.id == ProductID.lifetime } }

    func start() async {
        listenForTransactions()
        await loadProducts()
        await refreshEntitlements()
    }

    func loadProducts() async {
        isLoading = true
        defer { isLoading = false }
        do {
            let loaded = try await Product.products(for: ProductID.all)
            products = loaded.sorted { a, b in
                ProductID.all.firstIndex(of: a.id) ?? 99 < ProductID.all.firstIndex(of: b.id) ?? 99
            }
        } catch {
            lastError = "Couldn't load products: \(error.localizedDescription)"
        }
    }

    @discardableResult
    func purchase(_ product: Product) async -> Bool {
        do {
            let result = try await product.purchase()
            switch result {
            case .success(let verification):
                guard case .verified(let transaction) = verification else { return false }
                await transaction.finish()
                await refreshEntitlements()
                return true
            case .userCancelled, .pending:
                return false
            @unknown default:
                return false
            }
        } catch {
            lastError = error.localizedDescription
            return false
        }
    }

    func restore() async {
        try? await AppStore.sync()
        await refreshEntitlements()
    }

    func refreshEntitlements() async {
        var ids: Set<String> = []
        for await entitlement in Transaction.currentEntitlements {
            guard case .verified(let t) = entitlement, t.revocationDate == nil else { continue }
            if ProductID.all.contains(t.productID) { ids.insert(t.productID) }
        }
        purchasedIDs = ids
    }

    private func listenForTransactions() {
        updatesTask?.cancel()
        updatesTask = Task.detached { [weak self] in
            for await update in Transaction.updates {
                if case .verified(let t) = update {
                    await t.finish()
                    await self?.refreshEntitlements()
                }
            }
        }
    }
}

/// What the free tier and Foreword Plus each get. One place to tune the funnel.
struct Entitlements {
    let isPlus: Bool

    /// Hints are also paid for inside each game (they cost a miss / wilt / knot).
    /// Free players get one per game per day; Plus removes the daily cap.
    var hintsPerGamePerDay: Int { isPlus ? Int.max : 1 }
    /// Free players get one practice puzzle a day across the whole app.
    var practicePerDay: Int { isPlus ? Int.max : 1 }
    var archive: Bool { isPlus }
    var adFree: Bool { isPlus }

    static func hintsUsed(_ g: GameID, day: Int) -> Int { UserDefaults.standard.integer(forKey: "hints.\(g.rawValue).\(day)") }
    static func noteHintUsed(_ g: GameID, day: Int) { UserDefaults.standard.set(hintsUsed(g, day: day) + 1, forKey: "hints.\(g.rawValue).\(day)") }
    static func practiceUsed(day: Int) -> Int { UserDefaults.standard.integer(forKey: "practice.\(day)") }
    static func notePracticeUsed(day: Int) { UserDefaults.standard.set(practiceUsed(day: day) + 1, forKey: "practice.\(day)") }

    func canHint(_ g: GameID, day: Int) -> Bool { Entitlements.hintsUsed(g, day: day) < hintsPerGamePerDay }
    func canPractice(day: Int) -> Bool { Entitlements.practiceUsed(day: day) < practicePerDay }
}
