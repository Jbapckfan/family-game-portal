import SwiftUI

// MARK: - Toast

struct ToastModifier: ViewModifier {
    @Binding var message: String?
    let palette: Palette

    func body(content: Content) -> some View {
        content.overlay(alignment: .top) {
            if let message {
                Text(message)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(palette.bg)
                    .padding(.horizontal, 14).padding(.vertical, 9)
                    .background(palette.fg, in: RoundedRectangle(cornerRadius: 8))
                    .padding(.top, 8)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .task(id: message) {
                        try? await Task.sleep(for: .seconds(1.8))
                        withAnimation { self.message = nil }
                    }
            }
        }
        .animation(.easeOut(duration: 0.2), value: message)
    }
}

extension View {
    func toast(_ message: Binding<String?>, palette: Palette) -> some View { modifier(ToastModifier(message: message, palette: palette)) }
}

// MARK: - Icon buttons

struct CircleIconButton: View {
    let symbol: String
    let palette: Palette
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 16, weight: .semibold))
                .frame(width: 38, height: 38)
                .background(palette.surface, in: Circle())
                .overlay(Circle().stroke(palette.line, lineWidth: 1))
        }
        .foregroundStyle(palette.fg)
    }
}

// MARK: - Pills / dots for mistakes

struct MistakeDots: View {
    let total: Int
    let used: Int
    let palette: Palette
    var body: some View {
        HStack(spacing: 6) {
            ForEach(0..<total, id: \.self) { i in
                Circle()
                    .fill(i < used ? palette.line : palette.accent)
                    .frame(width: 12, height: 12)
                    .scaleEffect(i < used ? 0.7 : 1)
                    .animation(.easeOut(duration: 0.2), value: used)
            }
        }
    }
}

// MARK: - On-screen keyboard

struct KeyboardView: View {
    let palette: Palette
    let onKey: (String) -> Void
    private let rows = ["qwertyuiop", "asdfghjkl", "zxcvbnm"]

    var body: some View {
        VStack(spacing: 6) {
            ForEach(Array(rows.enumerated()), id: \.offset) { i, row in
                HStack(spacing: 5) {
                    if i == 2 { wide("ENTER", label: "Enter") }
                    ForEach(Array(row), id: \.self) { ch in
                        Button { onKey(String(ch)) } label: {
                            Text(String(ch).uppercased())
                                .font(.system(size: 18, weight: .semibold).width(.condensed))
                                .frame(maxWidth: .infinity, minHeight: 48)
                                .background(palette.key, in: RoundedRectangle(cornerRadius: 6))
                        }
                        .foregroundStyle(palette.fg)
                    }
                    if i == 2 { wide("BACK", label: "⌫") }
                }
                .padding(.horizontal, i == 1 ? 18 : 0)
            }
        }
    }

    private func wide(_ key: String, label: String) -> some View {
        Button { onKey(key) } label: {
            Text(label)
                .font(.system(size: 13, weight: .semibold))
                .frame(maxWidth: .infinity, minHeight: 48)
                .background(palette.line, in: RoundedRectangle(cornerRadius: 6))
        }
        .foregroundStyle(palette.fg)
        .frame(maxWidth: 64)
    }
}

// MARK: - Stats grid

struct StatsGrid: View {
    let stats: GameStats
    let palette: Palette
    var body: some View {
        HStack(spacing: 8) {
            cell("\(stats.played)", "Played")
            cell("\(stats.winPercent)", "Win %")
            cell("\(stats.streak)", "Streak")
            cell("\(stats.maxStreak)", "Best")
        }
    }
    private func cell(_ v: String, _ l: String) -> some View {
        VStack(spacing: 2) {
            Text(v).font(.system(size: 26, weight: .bold, design: .rounded)).monospacedDigit()
            Text(l.uppercased()).font(.system(size: 10, weight: .semibold)).tracking(0.8).foregroundStyle(palette.muted)
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Result sheet

struct ResultSheet<Detail: View>: View {
    let game: GameID
    let title: String
    let emoji: String
    let mode: PlayMode
    let shareText: String
    let stats: GameStats
    let onPractice: () -> Void
    @ViewBuilder let detail: () -> Detail
    @Environment(\.dismiss) private var dismiss
    @Environment(StoreManager.self) private var store

    var body: some View {
        let p = game.palette
        ScrollView {
            VStack(spacing: 16) {
                Text(title).font(.system(size: 26, weight: .bold, design: .serif)).multilineTextAlignment(.center)
                Text(emoji).font(.system(size: 22)).tracking(2)
                detail()
                if mode == .daily { StatsGrid(stats: stats, palette: p) }
                ShareLink(item: shareText) {
                    Label("Share", systemImage: "square.and.arrow.up")
                        .font(.system(size: 16, weight: .bold))
                        .frame(maxWidth: .infinity, minHeight: 48)
                        .background(p.accent, in: RoundedRectangle(cornerRadius: 12))
                        .foregroundStyle(p.accentInk)
                }
                if mode == .daily {
                    TimelineView(.periodic(from: .now, by: 1)) { ctx in
                        Text("Next puzzle in \(DailyClock.countdownString(to: DailyClock.nextMidnight(), from: ctx.date))")
                            .font(.system(size: 13, weight: .medium)).monospacedDigit().foregroundStyle(p.muted)
                    }
                }
                Button {
                    dismiss()
                    onPractice()
                } label: {
                    HStack {
                        Text("Practice another")
                        if !store.isPlus { Image(systemName: "lock.fill").font(.system(size: 12)) }
                    }
                    .font(.system(size: 15, weight: .semibold))
                    .frame(maxWidth: .infinity, minHeight: 46)
                    .background(p.key, in: RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(p.fg)
                }
                if !store.isPlus { AdSlotView(palette: p) }
            }
            .padding(20)
        }
        .background(p.surface)
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }
}

// MARK: - Flow layout (wrapping row)

struct FlowLayout: Layout {
    var spacing: CGFloat = 6
    var lineSpacing: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let width = proposal.width ?? 360
        var x: CGFloat = 0, y: CGFloat = 0, rowH: CGFloat = 0
        for s in subviews {
            let size = s.sizeThatFits(.unspecified)
            if x + size.width > width, x > 0 { x = 0; y += rowH + lineSpacing; rowH = 0 }
            x += size.width + spacing; rowH = max(rowH, size.height)
        }
        return CGSize(width: width, height: y + rowH)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let width = bounds.width
        // measure rows first so each row can be centered
        var rows: [[(Int, CGSize)]] = [[]]
        var x: CGFloat = 0
        for (i, s) in subviews.enumerated() {
            let size = s.sizeThatFits(.unspecified)
            if x + size.width > width, x > 0 { rows.append([]); x = 0 }
            rows[rows.count - 1].append((i, size)); x += size.width + spacing
        }
        var y = bounds.minY
        for row in rows {
            let rowW = row.reduce(0) { $0 + $1.1.width } + spacing * CGFloat(max(0, row.count - 1))
            let rowH = row.map { $0.1.height }.max() ?? 0
            var px = bounds.minX + (width - rowW) / 2
            for (i, size) in row {
                subviews[i].place(at: CGPoint(x: px, y: y), proposal: ProposedViewSize(size))
                px += size.width + spacing
            }
            y += rowH + lineSpacing
        }
    }
}

// MARK: - Shake effect

struct Shake: GeometryEffect {
    var amount: CGFloat = 6
    var shakesPerUnit = 3.0
    var animatableData: CGFloat
    func effectValue(size: CGSize) -> ProjectionTransform {
        ProjectionTransform(CGAffineTransform(translationX: amount * sin(animatableData * .pi * shakesPerUnit), y: 0))
    }
}

// MARK: - How-to-play sheet

struct HowToSheet<Content: View>: View {
    let game: GameID
    @ViewBuilder let content: () -> Content
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        let p = game.palette
        ScrollView {
            VStack(alignment: .leading, spacing: 14) {
                Text("How to play").font(.system(size: 26, weight: .bold, design: .serif))
                content()
                Button("Start") { dismiss() }
                    .font(.system(size: 16, weight: .bold))
                    .frame(maxWidth: .infinity, minHeight: 48)
                    .background(p.accent, in: RoundedRectangle(cornerRadius: 12))
                    .foregroundStyle(p.accentInk)
            }
            .padding(20)
        }
        .background(p.surface)
        .presentationDetents([.large])
    }
}
