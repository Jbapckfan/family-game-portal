# Foreword — monetization strategy

Six daily word games (Dovetail, Splice, Sprout, Tangle, Keystone, Tumbler) in one app. The business model copies what has actually worked for NYT Games and Wordle-likes, adjusted for an indie with no newsroom: **free dailies as the acquisition engine, a cheap subscription as the revenue engine, and ads only as a floor for the people who will never pay.**

## 1. The core bet

Daily puzzle games monetize on *retention*, not on *difficulty* or *content volume*. The whole design is built around one habit loop:

1. Open once a day (push at a consistent personal time, four streaks to protect).
2. Finish in 2–10 minutes.
3. Share a spoiler-free emoji result (free distribution).
4. Want more → hit a wall → that wall is the paywall.

Everything paid is "more", never "better". A free player never feels the game is rigged against them; they feel the day is over.

## 2. Tiers

| | Free | Foreword Plus |
|---|---|---|
| Today's six puzzles | ✓ | ✓ |
| Stats, streaks, share | ✓ | ✓ |
| Hints (still cost a miss in-game) | 1 per game per day | Unlimited |
| Practice puzzles | 1 per day, app-wide | Unlimited |
| Archive (every past puzzle) | — | ✓ |
| Streak freeze (1/week, automatic) | — | ✓ |
| Ads (post-game card only) | Yes | None |
| iCloud sync, alt icons, themes | — | ✓ (roadmap) |

**Pricing** (configured in `Foreword.storekit`, create the same IDs in App Store Connect):

- `com.cursedtoaster.foreword.plus.monthly` — $2.99/mo, 7-day free trial
- `com.cursedtoaster.foreword.plus.yearly` — $19.99/yr, 7-day free trial (≈ $1.67/mo; the anchor; shown first with a "Best value" badge)
- `com.cursedtoaster.foreword.plus.lifetime` — $39.99 one-time (for the subscription-averse; also a cheap price test — if lifetime sells well, yearly is underpriced)

Why these numbers: NYT Games is $6/mo for a much larger catalog, Wordle clones with a single game sell at $0.99–$2.99 lifetime. Four games with daily cadence sit in between. Yearly is priced so a hesitant player can justify it as "a coffee a quarter". Raise prices after you have a 60-day retention curve, not before.

## 3. Where the paywall lives (implemented)

The paywall (`PaywallView`) is reached only from *moments of demand*, each with its own one-line reason:

- **Practice button** after a finished puzzle, once the one free daily practice is spent.
- **Hint button** once the free hint for that game is spent.
- **Archive** button on the home screen (lock icon for free users).
- **Home header badge** ("Get Plus") for the curious.

It is never shown on launch, never interrupts a puzzle, and the free tier is stated plainly on it ("Four daily games are free forever").

## 4. Ads: a floor, not a strategy

Ads are shown to free players only, only *after* a finished puzzle, in a single 320×100 slot in the result sheet (`AdSlotView` is the placeholder). Expected yield is small (word-game audiences skew older and English-speaking, which is good eCPM, but one impression per game per day caps volume). The real job of the ad is to make Plus's "No ads" line true.

Recommended network order: Google AdMob (banner + rewarded) → AppLovin MAX as mediation once you pass ~5k DAU. **Rewarded video for an extra hint** is the one ad format worth adding early: it converts intent into revenue without a purchase, and it's a natural upsell ("or go unlimited with Plus"). Wire it into `Entitlements.canHint`.

Do not add interstitials. They are the fastest way to turn a daily habit into an uninstall.

## 5. Growth loops (what the product already does, and what to add)

Implemented:
- Emoji share text per game, with puzzle number, so results are comparable across friends.
- Six independent streaks plus a "Today's six" meter and combined share (the meter is the completionist hook; six is the number people will screenshot).
- Puzzle numbering from a fixed epoch, so "Dovetail #37" means the same puzzle for everyone.

Add in order of impact:
1. **Daily reminder push** at the time the player usually opens (local notification; ask after the second completed day, not on first launch).
2. **Streak freeze** for Plus (one per week, automatic). This is the single best subscription retention feature in the category.
3. **Share card as an image** (rendered with `ImageRenderer`) in addition to text — image posts travel further on Instagram/iMessage.
4. **Weekly recap** ("You solved 26 of 28 this week") — a push + share moment on Sundays.
5. **Friends leaderboard** via Game Center (no backend): compare misses on today's puzzles.

## 6. Numbers to watch

| Metric | Target at 90 days | Why |
|---|---|---|
| D1 / D7 / D30 retention | 45% / 25% / 12% | The whole model dies below ~20% D7 |
| Daily puzzles completed per DAU | ≥ 3 of 6 | Measures whether the bundle works vs one game |
| Share rate (shares / completions) | ≥ 8% | Free acquisition engine |
| Free → trial start | 3–5% of 7-day-retained users | Paywall hit rate |
| Trial → paid | ≥ 40% | If lower, the free tier is too generous or the archive isn't compelling |
| Yearly share of new subs | ≥ 55% | Confirms the anchor pricing works |
| Churn (monthly plan) | < 8% / month | Streak freeze + archive are the churn tools |

Instrument with a privacy-respecting SDK (TelemetryDeck or Mixpanel). Events to log: `puzzle_start`, `puzzle_finish(game, won, mistakes, seconds)`, `hint_used`, `practice_start`, `share`, `paywall_shown(reason)`, `trial_start`, `purchase(product)`.

## 7. Launch plan

1. **Soft launch** (TestFlight, 50–200 people): fix difficulty curves using `puzzle_finish` data. Each generator in `tools/` has thresholds; adjust and regenerate rather than hand-editing JSON.
2. **App Store launch**: lead with Dovetail (the most explainable mechanic) in screenshots; "Four new daily word games" as the subtitle; keywords around *daily word game, word puzzle, spelling, anagram*.
3. **Week 1–4**: post one puzzle's result card per day on Reddit (r/wordle, r/puzzles), Threads, and Bluesky from a studio account; the puzzle number is the hook.
4. **Month 2**: add the second-most-requested game variant as a Plus-only "bonus Sunday" to give the subscription a reason beyond archive.
5. **Month 3**: price test yearly at $24.99 for 50% of new users (StoreKit offers / A/B via a remote config flag).

## 8. Content pipeline (the hidden cost)

The puzzle banks shipped here are generated (77 / 73 / 128 / 160 / 58×3 / 1,054 puzzles) and machine-verified for uniqueness and solvability, which covers 2.5–5 months. Before launch:

- Run the generators with looser thresholds to get to 365+ per game, then **hand-curate** (an hour per 100 puzzles): kill obscure or awkward words, order by difficulty so Mondays are easy, and plant a few deliberately delightful ones (TEA→POT→ASH→RAM→PAGE→ANT→ARCTIC).
- Keep the banks in the app bundle (no server needed for v1). When you add remote puzzles later, keep the same JSON shape and fetch a month at a time.

## 9. What *not* to do

- No energy systems, no timers, no "watch an ad to continue". This audience punishes it in reviews.
- No daily puzzle behind the paywall. The free daily is the marketing.
- No pay-to-win hints that bypass the in-game cost. Plus removes the *cap*, not the *cost*.
- Don't launch with more than six games. Six is the pitch ("one for every kind of word-brain"); add a seventh as a Plus-only Sunday special, not a free daily.
