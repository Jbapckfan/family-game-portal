# Foreword

Six original daily word games in one SwiftUI app (and one web app):

| Game | One-line rule | Loss condition |
|---|---|---|
| **Dovetail** | Eight stacked words; each word joined to the one below spells a new word (SHOT→GUN→FIRE→WALL…). Top and bottom given, fill six. | 6 misses |
| **Splice** | Twelve word-halves; splice them into six words using every half once. Decoys everywhere, one perfect pairing. | 4 mistakes |
| **Sprout** | Grow a 3-letter seed into an 8-letter bloom, adding one soil letter per turn and rearranging everything. Some words are dead ends. | 5 wilts |
| **Tangle** | Three words interleaved into one string, each keeping its letter order. Pull them apart. | 4 knots |
| **Keystone** | A hidden word joins with five clue words (YARD, GROUND… → BACK). Two clues show; each wrong guess reveals another. Three arches a day, golf scoring. | 2 strikes after the 5th clue |
| **Tumbler** | A five-dial lock. Guess a five-letter word; each dial says whether the secret letter is ▲ later or ▼ earlier in the alphabet, and shows its remaining range. | 6 guesses |

Each game has a daily puzzle (No. 1 = 20 Oct 2026, local time), per-game streaks and stats, emoji share text, a practice mode, and an archive. The home screen shows a "Today's six" meter and a combined share once all six are done.

**Web version:** `web/foreword.html` is the same six games as one self-contained page (open it in any browser, no server needed). `web/<game>.html` are the standalone prototypes of the first four. Puzzle banks are generated and machine-verified (unique solutions / guaranteed solvable paths).

## Build

- Xcode 16 or newer (the project uses file-system-synchronized groups, so new files dropped into `Foreword/` are picked up automatically).
- iOS 17.0+ (uses `@Observable`).
- Open `Foreword.xcodeproj`, set your Team under Signing & Capabilities, run.
- No third-party dependencies.

If Xcode refuses the project file for any reason, create a new iOS App project named `Foreword`, delete its generated sources, and drag the `Foreword/` folder in (copy items, create groups). Everything inside is plain Swift + JSON + an asset catalog.

## Monetization layer

- `Monetization/StoreManager.swift` — StoreKit 2: loads products, purchases, restores, listens for transaction updates, exposes `isPlus`.
- `Monetization/PaywallView.swift` — the paywall and the `AdSlotView` placeholder.
- `Entitlements` (same file as StoreManager) — the free/Plus rules in one place: free users get 1 hint per game per day and 1 practice per day; Plus removes caps, unlocks the archive, hides ads.
- `Foreword.storekit` — local StoreKit configuration with the three products (monthly $2.99 w/ 7-day trial, yearly $19.99 w/ trial, lifetime $39.99). The shared scheme already points at it; if purchases show "not available", select it under *Edit Scheme → Run → Options → StoreKit Configuration*.
- In Debug builds the paywall has a "pretend I'm a Plus member" toggle for testing gates without a sandbox account.

Before shipping: create the same product IDs in App Store Connect, change `PRODUCT_BUNDLE_IDENTIFIER` (currently `com.cursedtoaster.foreword`) and the product ID prefix in `StoreManager.ProductID` if you want a different namespace, replace the privacy URL in `PaywallView`, and wire an ad SDK into `AdSlotView` (see `MONETIZATION.md`).

## Project layout

```
Foreword/
  ForewordApp.swift          app entry; injects StoreManager
  HomeView.swift             home (four cards, Plus badge), Statistics, Archive
  Core/Core.swift            DailyClock, GameID + palettes, persistence, stats, puzzle loader
  UI/Components.swift        toast, keyboard, result/how-to sheets, FlowLayout, shake
  Games/<Game>/<Game>Model.swift   pure game logic (@Observable), persisted per day (six games)
  Games/<Game>/<Game>View.swift    SwiftUI screen
  Monetization/              StoreKit 2, paywall, entitlements, ad slot
  Resources/Puzzles/*.json   puzzle banks + dictionaries
  Resources/Assets.xcassets  app icon, accent color
tools/                       Python generators that produced the banks (see below)
web/                         the four browser prototypes (single-file HTML), identical rules
```

## Regenerating puzzles

`tools/` holds the generators used to build the banks. They need Python 3 with `wordfreq`, `nltk` (WordNet corpus) and `english-words`:

```
pip install wordfreq nltk english-words
python -c "import nltk; nltk.download('wordnet')"
python tools/gen_dovetail.py   # writes dovetail_data.json (run first; the others reuse its word lists)
python tools/gen_splice.py
python tools/gen_sprout.py
python tools/gen_tangle.py
python tools/gen_keystone.py   # needs dovetail_data.json
python tools/gen_tumbler.py    # needs keystone_data.json
```

`tools/hub/build_hub.py` assembles `web/foreword.html` from the part files in `tools/hub/` and the generated JSON, and refreshes the iOS puzzle bundles.

Each script prints the puzzles it picked so you can curate by eye; thresholds (frequency floors, decoy density, chain length) are constants at the top of each file. Copy the resulting JSON into `Foreword/Resources/Puzzles/` and `web/`.

## Known gaps / next steps

- Local notifications for a daily reminder (ask after day 2).
- Streak freeze for Plus (entitlement exists in copy; logic not yet written).
- Image share cards via `ImageRenderer`.
- Game Center friends leaderboard.
- The dictionaries are frequency-filtered web English; expect to prune a few odd words after a round of play-testing.
- Tumbler forces dark appearance for its screen (a vault look); the rest of the app follows the system.
