import json, random, re, sys
from collections import defaultdict
from wordfreq import top_n_list, zipf_frequency
from nltk.corpus import wordnet as wn

random.seed(20261020)
ALPHA = re.compile(r'^[a-z]+$')
_wc = {}
def is_word(w):
    if w in _wc: return _wc[w]
    ss = wn.synsets(w)
    r = bool(ss) and not all(s.instance_hypernyms() for s in ss)
    _wc[w] = r
    return r

BAD = set("""ass arse sex tit tits cum cock dick fuck shit piss crap damn hell nazi rape rapist porn porno slut whore bitch cunt fag fags gay anal anus boob boobs nude nudes nigga negro retard queer jew jews homo semen sperm penis vagina pussy horny kink dildo orgy fetish incest""".split())
NAMES = set("""ben don sam tom ann bob jim joe dan ray jay kim lee amy eve ian ted tim jon ron roy guy ken len les liz meg nan pam pat rob tod tony tina mike john dave paul mary jane jose juan luis carl eric fred gary greg jack jeff joel josh karl kate kyle lisa mark matt neil nick noah owen pete phil ryan sean seth todd will zach adam alan alex andy bill brad chad chris dale dean doug duke earl ella emma erin gene glen hank hugh jake jess jill joan judy june kurt lane lynn marc nora olga otto reed rick ross ruth sara stan tara tess troy wade wes abe ali ana ava cal deb dee del dom dot eli gus hal ike jan jed jen jet kay kit lou mac max mel mia moe ned nat nia nik rex rod sal sid sol sue tad tam ty val vic zoe abby amir anna beth cara cory dana dora drew enzo evan ezra finn gabe hans ivan jace jada jody lars liam luca luke lyle mack mila nate nina noel olaf omar rosa rudy russ ruby sage shaw tomas vera wren yuri zara yves rose ian""".split())
SUFFIX = set("""ing est ers ies ied ier ily ity ive ous ful ment tion ness ism ist ion ent ling ette ella ish ese ess ure ize ise ees ary ory ial ual ics ide ine ene ane sts ted ded ned red ces ses zes ths des les tes kes pes mes nes ges bes ves eth eum ius""".split())
JUNK = set("""www http https com org net lol pls omg btw thx ppl gov edu jpg png gif pdf txt doc htm url rss faq xml php asp cgi exe mp3 mp4 avi mov zip rar tar iso dvd ios api app apps ui ux ads okay yea yeah yep nope hey hmm huh ugh wow yay meh duh aka etc inc ltd llc esp mrs blvd apt dept avg num pct qty ref ver vol fig para sec hrs mins secs wks yrs lbs kg mg ml km cm mm ind pos mon tue wed thu fri jan feb apr jun jul aug sep oct nov dec res ers ans ops ems tho thru ive wan hos tis til ere oft nth ult""".split())

def ok_token(w):
    return bool(ALPHA.match(w)) and w not in BAD and w not in JUNK

common_raw = top_n_list('en', 60000)
COMMON = [w for w in common_raw if ok_token(w) and 3 <= len(w) <= 9 and is_word(w)]
COMMON_SET = set(COMMON)
print('common', len(COMMON), file=sys.stderr)

def eligible(w):
    return (w in COMMON_SET and 3 <= len(w) <= 8 and zipf_frequency(w, "en") >= 3.55
            and w not in SUFFIX and w not in NAMES)
ELIG_SET = set(w for w in COMMON if eligible(w))
print('eligible', len(ELIG_SET), file=sys.stderr)

big = top_n_list('en', 250000)
FUSED = set()
BYLEFT = defaultdict(set)    # left -> {x}  (left+x fused, x common)
BYRIGHT = defaultdict(set)   # right -> {x} (x+right fused, x common)
EDGES = defaultdict(set)
FZ = {}
for w in big:
    if not ok_token(w) or not (6 <= len(w) <= 14): continue
    z = zipf_frequency(w, 'en')
    if z < 2.7: continue
    if not is_word(w): continue
    for i in range(3, len(w) - 2):
        a, b = w[:i], w[i:]
        if a in COMMON_SET and b in COMMON_SET and zipf_frequency(a,'en') >= 3.4 and zipf_frequency(b,'en') >= 3.4:
            FUSED.add(w); FZ[w] = z
            BYLEFT[a].add(b); BYRIGHT[b].add(a)
            if a in ELIG_SET and b in ELIG_SET and z >= 2.75 and a != b:
                EDGES[a].add(b)
print('fused', len(FUSED), 'edge-nodes', len(EDGES), 'edges', sum(len(v) for v in EDGES.values()), file=sys.stderr)

REV = defaultdict(set)
for a, bs in EDGES.items():
    for b in bs: REV[b].add(a)
deg = {a: len(EDGES[a]) + len(REV[a]) for a in set(EDGES) | set(REV)}

def alternates(left, mid, right):
    return [x for x in (BYLEFT[left] & BYRIGHT[right]) if x != mid and len(x) == len(mid)]

wcount = defaultdict(int); ecount = defaultdict(int)
picked = []
def run(L, target):
    chains = {}
    scored = []
    sys.setrecursionlimit(10000)

    def dfs(path, used, budget):
        if budget[0] <= 0: return
        if len(path) == L:
            chains[tuple(path)] = 1; budget[0] -= 1; return
        cur = path[-1]
        opts = list(EDGES[cur] - used)
        random.shuffle(opts)
        opts.sort(key=lambda b: deg.get(b, 0) + random.random() * 25)
        for b in opts[:9]:
            path.append(b); used.add(b)
            dfs(path, used, budget)
            path.pop(); used.discard(b)

    starts = [a for a in EDGES if a in ELIG_SET]
    random.shuffle(starts)
    for s in starts:
        dfs([s], {s}, [300])
    print('raw chains', len(chains), file=sys.stderr)

    scored = []
    for p in chains:
        fz = [FZ[p[i] + p[i+1]] for i in range(L - 1)]
        hubs = sum(1 for w in p if deg.get(w, 0) > 40)
        alts = [len(alternates(p[i-1], p[i], p[i+1])) for i in range(1, L - 1)]
        wz = [zipf_frequency(w, 'en') for w in p]
        score = min(fz) * 1.5 + sum(fz) / len(fz) + min(wz) * 0.6 - hubs * 0.9 - sum(alts) * 0.7 + random.random() * 0.3
        scored.append((score, list(p), fz, alts))
    scored.sort(key=lambda c: -c[0])

    rej = defaultdict(int)
    cands = []
    for score, p, fz, alts in scored:
        if sum(alts) > 5: continue
        stems = [wn.morphy(w) or w for w in p]
        if len(set(stems)) < L: continue
        if any((a + 's' == b or b + 's' == a or a + 'es' == b or b + 'es' == a) for a in p for b in p): continue
        cands.append((score, p))
    while len(picked) < target and cands:
        best = None; bi = -1
        for i, (score, p) in enumerate(cands):
            edges = [p[i2] + p[i2+1] for i2 in range(L - 1)]
            if any(ecount[e] >= 3 for e in edges): continue
            if any(wcount[w] >= 14 for w in p): continue
            s = score - sum(wcount[w] for w in p) * 0.45 - sum(ecount[e] for e in edges) * 1.0
            if best is None or s > best: best, bi = s, i
        if bi < 0: break
        score, p = cands.pop(bi)
        for w in p: wcount[w] += 1
        for e in [p[i2] + p[i2+1] for i2 in range(L - 1)]: ecount[e] += 1
        picked.append(p)
run(8, 120)
n8 = len(picked)
run(7, 200)
print('n8', n8, file=sys.stderr)
print('picked', len(picked), file=sys.stderr)
for p in picked:
    print(' > '.join(p).upper(), ' | ', ' '.join(p[i] + p[i+1] for i in range(len(p) - 1)))

json.dump({'puzzles': picked, 'common': sorted(COMMON_SET), 'fused': sorted(FUSED)}, open('dovetail_data.json', 'w'))
