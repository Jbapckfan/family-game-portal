import json, random, re, sys
from collections import defaultdict
from wordfreq import top_n_list, zipf_frequency
from nltk.corpus import wordnet as wn
from english_words import get_english_words_set

random.seed(5)
d = json.load(open('dovetail_data.json'))
_W2 = get_english_words_set(['web2'], lower=False) | get_english_words_set(['gcide'], lower=False)
BAD = set("ass asses arse arses tit tits boob boobs cock cocks dick dicks sex sexes gay gays jew jews homo homos nude nudes slut sluts whore whores bitch bitches cunt cunts fag fags playboy threesome piss pissed shit shitty fuck fucked fucker fucking bastard nigger faggot retard rapist rape incest erotica erotic sexual sexier horny porn porno anal anus semen sperm penis vagina pussy dildo orgy fetish".split())
JUNK = set("opec corp idps reis aires raines shat fart farts scrotum nato reit nigra maar bader smit tali cortina amir rami maria nist inst german germans chile capitol stein contra contras marge monte porte etna dane danes tamil vedic minoan croat croats belgian bengali michael ers ins ans ops ems tho thru ive wan hos tis til ere oft nth ult res pos mon tue wed thu fri jan feb apr jun jul aug sep oct nov dec sen gen rep comp prep sub pro con anti vis mis sup chi pol mil des las nas pas mas les mes nes tes ses ees ies ted ben der non ing est ness ment tion ist ism ous ful ive ize ise ees ary ory ial ual ics ide ine ene ane ling ette ish ese ess ure".split())
NAMES = set("ben don sam tom ann bob jim joe dan ray jay kim lee amy eve ian ted tim jon ron roy guy ken len les liz meg nan pam pat rob tod ali ana ava cal deb dee del dom dot eli gus hal ike jan jed jen jet kay kit lou mac max mel mia moe ned nat nia nik rex rod sal sid sol sue tad tam val vic zoe abe art bea bud dax eva fay gil ida ivy jax kai kip lex lia mae may ora pia rae reg stu tai una uri van vin wes zed tony tina mike john dave paul mary jane jose juan luis carl eric fred gary greg jack jeff joel josh karl kate kyle lisa mark matt neil nick noah owen pete phil ryan sean seth todd will zach adam alan alex andy bill brad chad chris dale dean doug duke earl ella emma erin gene glen hank hugh jake jess jill joan judy june kurt lane lynn marc nora olga otto reed rick ross ruth sara stan tara tess troy wade".split())
ALPHA = re.compile(r'^[a-z]+$')
_wc = {}
def is_word(w):
    if w in _wc: return _wc[w]
    ss = wn.synsets(w)
    _wc[w] = bool(ss) and not all(s.instance_hypernyms() for s in ss)
    return _wc[w]
def proper(w):
    base = wn.morphy(w) or w
    for x in (w, base):
        if x.capitalize() in _W2 and x not in _W2: return True
    return False
def lemma_like(w):
    return any(l.name() == w for s in wn.synsets(w) for l in s.lemmas())
Z = {}
def z(w):
    if w not in Z: Z[w] = zipf_frequency(w, 'en')
    return Z[w]

COMMON = set(w for w in d['common'] if w not in BAD and w not in JUNK and not proper(w))
print('common', len(COMMON), file=sys.stderr)

# bigger fusion set than dovetail's
FUSED = set(d['fused'])
for w in top_n_list('en', 300000):
    if not ALPHA.match(w) or not (6 <= len(w) <= 13) or w in BAD: continue
    if z(w) < 2.6: continue
    if not is_word(w): continue
    for i in range(3, len(w) - 2):
        a, b = w[:i], w[i:]
        if a in COMMON and b in COMMON and z(a) >= 3.3 and z(b) >= 3.3:
            FUSED.add(w)
print('fused', len(FUSED), file=sys.stderr)

# partner index
AFTER = defaultdict(set)   # K -> {X : K+X fused}
BEFORE = defaultdict(set)  # K -> {X : X+K fused}
for f in FUSED:
    for i in range(3, len(f) - 2):
        a, b = f[:i], f[i:]
        if a in COMMON and b in COMMON:
            AFTER[a].add(b); BEFORE[b].add(a)

IRREG = {('man','men'),('woman','women'),('child','children'),('foot','feet'),('tooth','teeth'),('mouse','mice'),('wife','wives'),('life','lives'),('leaf','leaves'),('knife','knives'),('goose','geese'),('person','people')}
SUFFIXY = set("ping ding sing ting ling ring ion ions ally able ability ant ance ence ism ist ive ful ness ment ery tor ace tally ted red led ned ses ting ings ers ier iest est".split())
def related(a, b):
    if (a, b) in IRREG or (b, a) in IRREG: return True
    if (wn.morphy(a) or a) == (wn.morphy(b) or b): return True
    if a.endswith('ies') and a[:-3] + 'y' == b: return True
    if b.endswith('ies') and b[:-3] + 'y' == a: return True
    return a == b or a in b or b in a or a + 's' == b or b + 's' == a or a + 'es' == b or b + 'es' == a

def joins(w, c):
    return (w + c) in FUSED or (c + w) in FUSED

def degree(c):
    return len(AFTER[c]) + len(BEFORE[c])

def solvers(clues):
    """all common words joining every clue"""
    first = clues[0]
    cands = (AFTER[first] | BEFORE[first])
    out = []
    for w in cands:
        if len(w) < 3 or any(related(w, c) for c in clues): continue
        if all(joins(w, c) for c in clues): out.append(w)
    return out

KEYS = [w for w in COMMON if 3 <= len(w) <= 6 and z(w) >= 3.6 and lemma_like(w) and w not in NAMES and w not in SUFFIXY]
print('keys', len(KEYS), file=sys.stderr)

puzzles = []
for K in KEYS:
    parts = []
    for X in AFTER[K]:
        if 3 <= len(X) <= 7 and z(X) >= 3.5 and not related(K, X) and X not in NAMES and X not in SUFFIXY and lemma_like(X): parts.append((X, 'after', z(K + X)))
    for X in BEFORE[K]:
        if 3 <= len(X) <= 7 and z(X) >= 3.5 and not related(K, X) and X not in NAMES and X not in SUFFIXY and lemma_like(X): parts.append((X, 'before', z(X + K)))
    # dedupe X (prefer higher fused zipf)
    best = {}
    for X, dr, fz in parts:
        if X not in best or fz > best[X][1]: best[X] = (dr, fz)
    if len(best) < 5: continue
    cand = sorted(best.items(), key=lambda kv: -kv[1][1])
    pool = cand[:14]
    found = None
    for attempt in range(40):
        pick = random.sample(pool, 5) if attempt else pool[:5]
        clues = [x for x, _ in pick]
        if any(related(clues[i], clues[j]) for i in range(5) for j in range(i + 1, 5)): continue
        sol = solvers(clues)
        if sol == [K] or (len(sol) == 1 and sol[0] == K):
            found = pick; break
    if not found: continue
    # order: most ambiguous clue first, decisive last
    found.sort(key=lambda kv: -degree(kv[0]))
    avgfz = sum(fz for _, (dr, fz) in found) / 5
    nparts = len(best)
    diff = (6 - min(z(K), 6)) * 1.2 + (12 - min(nparts, 12)) * 0.25 + (4.5 - min(avgfz, 4.5)) * 1.5
    puzzles.append({'k': K, 'clues': [{'w': X, 'd': dr} for X, (dr, fz) in found], 'diff': round(diff, 2), 'n': nparts})
print('puzzles', len(puzzles), file=sys.stderr)

puzzles.sort(key=lambda p: p['diff'])
n = len(puzzles)
easy, med, hard = puzzles[: n // 3], puzzles[n // 3: 2 * n // 3], puzzles[2 * n // 3:]
random.shuffle(easy); random.shuffle(med); random.shuffle(hard)
days = []
for i in range(min(len(easy), len(med), len(hard))):
    days.append([easy[i], med[i], hard[i]])
print('days', len(days), file=sys.stderr)
for dday in days[:40]:
    print(' || '.join(f"{p['k'].upper()} <- {' '.join((c['w'] + '+' if c['d'] == 'before' else '+' + c['w']) for c in p['clues'])} ({p['diff']})" for p in dday))
json.dump({'days': [[{'k': p['k'], 'clues': p['clues']} for p in dday] for dday in days], 'common': sorted(COMMON), 'fused': sorted(FUSED)}, open('keystone_data.json', 'w'))
