import json, random, sys
from collections import defaultdict
from wordfreq import zipf_frequency

random.seed(42)
d = json.load(open('dovetail_data.json'))
COMMON = set(d['common'])
FUSED = set(d['fused'])
BAD = set("asses arses tits boobs cocks dicks sexes gays jews homos nudes sluts whores bitches cunts fags playboy playboys threesome threesomes chilean hollywood peeling peeled".split())
JUNKT = set("ted ben der mil ins pol chi vis mis sup pee les non des las nas pas mas sen lan ers ans mes nes ies tes ses les ees ism ist ness ment tion ing est ous ive ful".split())
from nltk.corpus import wordnet as wn
def proper(w):
    ss = wn.synsets(w)
    return (not ss) or any(s.instance_hypernyms() for s in ss)
Z = {}
def z(w):
    if w not in Z: Z[w] = zipf_frequency(w, 'en')
    return Z[w]

def splits(w):
    out = []
    for i in range(3, len(w) - 2):
        a, b = w[:i], w[i:]
        if a in COMMON and b in COMMON and a not in JUNKT and b not in JUNKT and z(a) >= 3.4 and z(b) >= 3.4: out.append((a, b))
    return out

SPL = {w: splits(w) for w in FUSED if w not in BAD}
SPL = {w: s for w, s in SPL.items() if s}
SOL = [w for w in SPL if z(w) >= 3.2 and not proper(w)]
print('fused splittable', len(SPL), 'sol', len(SOL), file=sys.stderr)

SW = defaultdict(list)      # tile -> [(word, a, b)] over SOL
PARTN = defaultdict(set)    # tile -> partner tiles (any order) over all SPL
for w, ss in SPL.items():
    for a, b in ss:
        PARTN[a].add(b); PARTN[b].add(a)
        if w in SOL: SW[a].append((w, a, b)); SW[b].append((w, a, b))

def joined(a, b): return (a + b) in FUSED

def count_matchings(n, edges, limit=2):
    adj = defaultdict(set)
    for a, b in edges: adj[a].add(b); adj[b].add(a)
    cnt = 0
    def rec(unm):
        nonlocal cnt
        if cnt >= limit: return
        if not unm: cnt += 1; return
        u = min(unm)
        for v in adj[u]:
            if v in unm: rec(unm - {u, v})
    rec(frozenset(range(n)))
    return cnt

def build_puzzle(nw=6):
    first = random.choice(SOL)
    a, b = random.choice(SPL[first])
    words = [first]; parts = [(a, b)]; tiles = [a, b]
    tries = 0
    while len(words) < nw and tries < 60:
        tries += 1
        anchor = random.choice(tiles)
        ps = [y for y in PARTN[anchor] if y in SW]
        if not ps: continue
        y = random.choice(ps)
        cands = [t for t in SW[y] if t[0] not in words and t[1] not in tiles and t[2] not in tiles and t[1] != t[2]]
        if not cands: continue
        w, c, dd = random.choice(cands)
        words.append(w); parts.append((c, dd)); tiles += [c, dd]
    if len(words) < nw: return None
    n = 2 * nw
    if len(set(tiles)) < n: return None
    # no tile is a prefix/suffix of another tile's fused word confusion: keep simple
    edges = set(); npairs = 0
    for i in range(n):
        for j in range(n):
            if i != j and joined(tiles[i], tiles[j]):
                npairs += 1; edges.add((min(i, j), max(i, j)))
    if count_matchings(n, edges) != 1: return None
    deg = defaultdict(int)
    for i, j in edges: deg[i] += 1; deg[j] += 1
    lonely = sum(1 for i in range(n) if deg[i] < 2)
    if lonely > 2: return None
    if npairs < nw + 5: return None
    return {'words': words, 'parts': parts, 'tiles': tiles, 'pairs': npairs, 'lonely': lonely}

out = []; seen = set(); attempts = 0
while len(out) < 1500 and attempts < 60000:
    attempts += 1
    p = build_puzzle()
    if not p: continue
    key = tuple(sorted(p['words']))
    if key in seen: continue
    seen.add(key); out.append(p)
print('found', len(out), 'in', attempts, file=sys.stderr)
out.sort(key=lambda p: (-(p['pairs'] - p['lonely'] * 2), random.random()))
used = defaultdict(int); tused = defaultdict(int); picked = []
for p in out:
    if any(used[w] >= 2 for w in p['words']): continue
    if any(tused[t] >= 6 for t in p['tiles']): continue
    for w in p['words']: used[w] += 1
    for t in p['tiles']: tused[t] += 1
    picked.append(p)
    if len(picked) >= 200: break
random.shuffle(picked)
print('picked', len(picked), file=sys.stderr)
for p in picked:
    print(p['pairs'], p['lonely'], ' '.join(a + '|' + b for a, b in p['parts']))
json.dump({'puzzles': [p['parts'] for p in picked], 'fused': sorted(FUSED)}, open('splice_data.json', 'w'))
