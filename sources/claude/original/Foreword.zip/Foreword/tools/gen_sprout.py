import json, random, sys
from collections import defaultdict
from wordfreq import zipf_frequency
from nltk.corpus import wordnet as wn

random.seed(3)
d = json.load(open('dovetail_data.json'))
BADW = set("asses arses tits boobs cocks dicks sexes gays jews homos nudes sluts whores bitches cunts fags playboy threesome pissed shitty fucked fucker fucking bastard".split())
from english_words import get_english_words_set
_W2 = get_english_words_set(['web2'], lower=False) | get_english_words_set(['gcide'], lower=False)
JUNK = set("opec corp idps reis aires raines shat fart farts farting scrotum nato reit nigra maar bader smit tali cortina amir rami maria nist inst dna der non ben nary shite bullshit shit crap damn hell ass tit cum pee poo wee lol omg btw etc inc ltd ers ins ans ops ems tho thru ive wan hos tis til ere oft nth ult res pos mon tue wed thu fri jan feb apr jun jul aug sep oct nov dec sen gen rep comp prep sub pro con anti vis mis sup chi pol mil des las nas pas mas les mes nes tes ses ees ies german germans chile capitol stein steins contra contras marge monte porte etna ben dane danes leo tamil vedic minoan croat croats belgian bengali michael".split())
def _proper(w):
    base = wn.morphy(w) or w
    for x in (w, base):
        if x.capitalize() in _W2 and x not in _W2: return True
    ss = wn.synsets(w)
    return bool(ss) and all(s2.instance_hypernyms() for s2 in ss)
D = set(w for w in d['common'] if 3 <= len(w) <= 8 and w not in BADW and w not in JUNK and not _proper(w))
Z = {}
def lemma_like(w):
    return any(l.name() == w for s2 in wn.synsets(w) for l in s2.lemmas()) and not any(s2.instance_hypernyms() for s2 in wn.synsets(w))
def z(w):
    if w not in Z: Z[w] = zipf_frequency(w, 'en')
    return Z[w]
# seeds: very common 3-letter words; targets: common, lemma-like 8-letter words
NAMES = set('ben don sam tom ann bob jim joe dan ray jay kim lee amy eve ian ted tim jon ron roy guy ken len les liz meg nan pam pat rob tod ali ana ava cal deb dee del dom dot eli gus hal ike jan jed jen jet kay kit lou mac max mel mia moe ned nat nia nik rex rod sal sid sol sue tad tam val vic zoe abe art bea bud cy dax eva fay gil hew ida ivy jax jo kai kip lex lia mae may nan ora ozzy pia rae reg rhys sly stu tai ty una uri van vin wes zed'.split())
SEEDS = [w for w in D if len(w) == 3 and z(w) >= 4.0 and w not in NAMES and lemma_like(w)]
TARGETS = [w for w in D if len(w) == 8 and z(w) >= 3.4 and not w.endswith('s') and not w.endswith('ed') and not w.endswith('ing') and lemma_like(w)]
print('D', len(D), 'seeds', len(SEEDS), 'targets', len(TARGETS), file=sys.stderr)

ANA = defaultdict(list)
for w in D: ANA[''.join(sorted(w))].append(w)

def sub(ms, c):
    i = ms.index(c); return ms[:i] + ms[i + 1:]

# alive(ms, M): from multiset ms (sorted str), can we reach a word with letters M by adding letters of M-ms one at a time with each step a word?
def make_alive(M):
    memo = {}
    def rem(ms):
        r = list(M)
        for c in ms: r.remove(c)
        return r
    def alive(ms):
        if ms in memo: return memo[ms]
        if len(ms) == 8: memo[ms] = ms == M and bool(ANA.get(ms)); return memo[ms]
        ok = False
        for c in set(rem(ms)):
            n = ''.join(sorted(ms + c))
            if ANA.get(n) and alive(n): ok = True; break
        memo[ms] = ok; return ok
    return alive

def appendable_path(seed, M, alive):
    """is there an alive path where every step just appends/prepends one letter (no rearranging)?"""
    def rec(w):
        if len(w) == 8: return True
        used = ''.join(sorted(w)); rest = list(M)
        for c in used: rest.remove(c)
        for c in set(rest):
            for nw in (w + c, c + w):
                if nw in D and alive(''.join(sorted(nw))) and rec(nw): return True
        return False
    return rec(seed)

def build(target):
    M = ''.join(sorted(target))
    alive = make_alive(M)
    # find seeds contained in M that are alive
    cands = []
    for s in SEEDS:
        ms = ''.join(sorted(s)); ok = True; r = list(M)
        for c in ms:
            if c in r: r.remove(c)
            else: ok = False; break
        if ok and alive(ms): cands.append(s)
    if not cands: return None
    random.shuffle(cands)
    for seed in cands[:6]:
        ms = ''.join(sorted(seed)); r = list(M)
        for c in ms: r.remove(c)
        pool = ''.join(sorted(r))
        if appendable_path(seed, M, alive): continue
        levels = {}
        total_alive = 0; total_dead = 0
        for k in range(4, 9):
            alive_w = []; dead_w = []
            # words of length k containing seed letters, with the rest drawn from pool
            for key, ws in ANA.items():
                if len(key) != k: continue
                r2 = list(key); good = True
                for c in ms:
                    if c in r2: r2.remove(c)
                    else: good = False; break
                if not good: continue
                p2 = list(pool)
                for c in r2:
                    if c in p2: p2.remove(c)
                    else: good = False; break
                if not good: continue
                (alive_w if alive(key) else dead_w).extend(ws)
            if not alive_w: break
            levels[k] = {'a': sorted(alive_w), 'd': sorted(dead_w)}
            total_alive += len(alive_w); total_dead += len(dead_w)
        if len(levels) < 5: continue
        return {'seed': seed, 'pool': pool, 'target': target, 'levels': levels, 'alive': total_alive, 'dead': total_dead}
    return None

out = []
random.shuffle(TARGETS)
for t in TARGETS:
    p = build(t)
    if p: out.append(p)
    if len(out) >= 400: break
print('built', len(out), file=sys.stderr)
# difficulty: fewer alive words = harder; keep a range, prefer moderate
out = [p for p in out if 6 <= p['alive'] <= 60 and p['dead'] <= 40]
random.shuffle(out)
out.sort(key=lambda p: -z(p['target']))
picked = []; used = defaultdict(int)
for p in out:
    if used[p['seed']] >= 2: continue
    used[p['seed']] += 1; picked.append(p)
    if len(picked) >= 150: break
random.shuffle(picked)
print('picked', len(picked), file=sys.stderr)
for p in picked:
    print(p['seed'], p['pool'], '->', p['target'], 'alive', p['alive'], 'dead', p['dead'], '|', ' / '.join(','.join(p['levels'][k]['a'][:4]) for k in range(4, 9)))
json.dump({'puzzles': [{'seed': p['seed'], 'pool': p['pool'], 'levels': {str(k): v for k, v in p['levels'].items()}} for p in picked]}, open('sprout_data.json', 'w'))
