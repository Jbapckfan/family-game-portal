import json, random, sys
from collections import defaultdict, Counter
from wordfreq import zipf_frequency
from nltk.corpus import wordnet as wn
from english_words import get_english_words_set

random.seed(11)
d = json.load(open('dovetail_data.json'))
_W2 = get_english_words_set(['web2'], lower=False) | get_english_words_set(['gcide'], lower=False)
BAD = set("asses arses boobs cocks dicks sexes gays jews homos nudes sluts whores bitches cunts fags playboy threesome pissed shitty fucked fucker fucking bastard nigger faggot retard rapist incest erotica erotic sexual sexier horny".split())
JUNK = set("opec corp idps reis aires raines shat fart farts farting scrotum nato reit nigra maar bader smit tali cortina amir rami maria nist inst german germans chile capitol stein contra contras marge monte porte etna dane danes tamil vedic minoan croat croats belgian bengali michael".split())
def proper(w):
    base = wn.morphy(w) or w
    for x in (w, base):
        if x.capitalize() in _W2 and x not in _W2: return True
    ss = wn.synsets(w)
    return bool(ss) and all(s.instance_hypernyms() for s in ss)
DICT = set(w for w in d['common'] if 5 <= len(w) <= 7 and w not in BAD and w not in JUNK and not proper(w))
def lemma_like(w):
    return any(l.name() == w for s in wn.synsets(w) for l in s.lemmas())
POOL = [w for w in DICT if zipf_frequency(w, 'en') >= 3.8 and lemma_like(w) and not w.endswith('s')]
print('dict', len(DICT), 'pool', len(POOL), file=sys.stderr)

# prefix sets per length
PREF = defaultdict(set)
for w in DICT:
    for i in range(1, len(w) + 1): PREF[len(w)].add(w[:i])
WORDS_BY_LEN = defaultdict(set)
for w in DICT: WORDS_BY_LEN[len(w)].add(w)

def count_solutions(s, lens, limit):
    """count labelings of s into subsequences of given lengths that are all dictionary words (slots ordered)"""
    k = len(lens); n = len(s)
    cnt = 0
    bufs = [''] * k
    # remaining letters needed per slot
    def rec(i):
        nonlocal cnt
        if cnt >= limit: return
        if i == n:
            if all(bufs[j] in WORDS_BY_LEN[lens[j]] for j in range(k)): cnt += 1
            return
        # pruning: remaining positions must suffice
        for j in range(k):
            if len(bufs[j]) < lens[j]:
                nb = bufs[j] + s[i]
                if nb in PREF[lens[j]]:
                    bufs[j] = nb
                    rec(i + 1)
                    bufs[j] = bufs[j][:-1]
                    if cnt >= limit: return
    rec(0)
    return cnt

def interleave(words):
    # random merge with max run 2 and each word not starting too late
    idx = [0] * len(words); out = []; owner = []
    lastw = -1; run = 0
    total = sum(len(w) for w in words)
    while len(out) < total:
        cands = [j for j in range(len(words)) if idx[j] < len(words[j]) and not (j == lastw and run >= 2)]
        if not cands: return None
        # bias toward words with more remaining letters
        weights = [len(words[j]) - idx[j] for j in cands]
        j = random.choices(cands, weights=weights)[0]
        out.append(words[j][idx[j]]); owner.append(j); idx[j] += 1
        run = run + 1 if j == lastw else 1; lastw = j
    return ''.join(out), owner

def build():
    lens = random.choice([(5, 5, 6), (5, 6, 6), (5, 6, 7), (6, 6, 6), (5, 5, 7), (6, 6, 7)])
    words = []
    for L in lens:
        c = [w for w in POOL if len(w) == L and w not in words]
        words.append(random.choice(c))
    # avoid heavy letter overlap making it a soup
    letters = Counter(''.join(words))
    if max(letters.values()) > 4: return None
    if len(set(words)) < 3: return None
    r = interleave(words)
    if not r: return None
    s, owner = r
    # each word should start within the first 6 letters? no: but first letters shouldn't all be the word's own start in order
    mult = 1
    for v in Counter(lens).values():
        for t in range(2, v + 1): mult *= t
    c = count_solutions(s, list(lens), mult + 1)
    if c != mult: return None
    return {'s': s, 'words': words, 'owner': owner}

out = []; seen = set(); attempts = 0
while len(out) < 160 and attempts < 60000:
    attempts += 1
    p = build()
    if not p: continue
    key = tuple(sorted(p['words']))
    if key in seen: continue
    seen.add(key); out.append(p)
    if len(out) % 20 == 0: print(len(out), attempts, file=sys.stderr)
print('found', len(out), 'in', attempts, file=sys.stderr)
for p in out: print(p['s'], ' '.join(p['words']))
json.dump({'puzzles': [{'s': p['s'], 'w': p['words'], 'o': p['owner']} for p in out], 'dict': sorted(DICT)}, open('tangle_data.json', 'w'))
