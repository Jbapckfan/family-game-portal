import json, random, sys
from wordfreq import zipf_frequency, top_n_list
from nltk.corpus import wordnet as wn
from english_words import get_english_words_set

random.seed(9)
d = json.load(open('keystone_data.json'))
COMMON = set(d['common'])
_W2 = get_english_words_set(['web2'], lower=False) | get_english_words_set(['gcide'], lower=False)
BAD = set("silva boobs cocks dicks sexes nudes sluts whore bitch cunts fucks shits penis pussy porno horny semen sperm negro nazis".split())
def proper(w):
    base = wn.morphy(w) or w
    for x in (w, base):
        if x.capitalize() in _W2 and x not in _W2: return True
    ss = wn.synsets(w)
    return bool(ss) and all(s.instance_hypernyms() for s in ss)
def lemma_like(w):
    return any(l.name() == w for s in wn.synsets(w) for l in s.lemmas())

GUESS = sorted(w for w in COMMON if len(w) == 5 and w not in BAD)
ANS = [w for w in GUESS if zipf_frequency(w, 'en') >= 3.6 and lemma_like(w) and not proper(w) and len(set(w)) >= 3]
# drop plural-looking (ends in s but singular base exists) and -ed forms
ANS = [w for w in ANS if not (w.endswith('s') and (w[:-1] in COMMON or w[:-2] in COMMON) and not w.endswith('ss')) and not (w.endswith('ed') and (w[:-2] in COMMON or w[:-1] in COMMON))]
print('guess', len(GUESS), 'answers', len(ANS), file=sys.stderr)

# simulate: how many guesses does a "consistent random" player need with hi/lo-per-position feedback?
def fb(guess, secret):
    return tuple(0 if g == s else (1 if s > g else -1) for g, s in zip(guess, secret))
def consistent(w, hist):
    return all(fb(g, w) == f for g, f in hist)
def sim(secret, pool, opener):
    hist = []; g = opener
    for n in range(1, 12):
        f = fb(g, secret)
        if all(x == 0 for x in f): return n
        hist.append((g, f))
        cands = [w for w in pool if consistent(w, hist)]
        if not cands: return 99
        g = random.choice(cands)
    return 12
sample = random.sample(ANS, 300)
pool = ANS  # a strong player picks consistent words from the answer-ish vocabulary
for opener in ['moist', 'leant', 'cores', 'noisy', 'plant', 'lemon']:
    if opener not in GUESS: continue
    res = [sim(s, pool, opener) for s in sample]
    print(opener, 'mean', round(sum(res) / len(res), 2), 'max', max(res), 'p(<=6)', round(sum(1 for r in res if r <= 6) / len(res), 3), 'p(<=7)', round(sum(1 for r in res if r <= 7) / len(res), 3), file=sys.stderr)

random.shuffle(ANS)
print('\n'.join(ANS[:60]))
json.dump({'answers': ANS, 'guess': GUESS}, open('tumbler_data.json', 'w'))
