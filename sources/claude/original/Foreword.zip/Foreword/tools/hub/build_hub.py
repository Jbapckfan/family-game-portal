import json, re, os
H = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(H)
def rd(p): return open(os.path.join(H, p)).read()

GENERIC_L = dict(good='#CFE4D8', good_ink='#0E3D27', warn='#D99A12', warn_ink='#5A3E00', bad='#D04444', bad_soft='#F8DADA')
GENERIC_D = dict(good='#1C3A28', good_ink='#BFEFD3', warn='#F1B83A', warn_ink='#2A1D00', bad='#F06A6A', bad_soft='#4A1F1F')
PAL = {
  'hub': dict(font="var(--hub-display)", weight='400', size='28px', track='0', case='none',
    L=dict(bg='#EEF0F3', surface='#FFFFFF', fg='#14171C', muted='#646B76', line='#CBD1D9', accent='#C9892B', accent_ink='#FFFFFF', key='#D7DCE3', **GENERIC_L),
    D=dict(bg='#121418', surface='#1B1E24', fg='#ECEEF1', muted='#959CA8', line='#2E333B', accent='#E0A64A', accent_ink='#2A1D00', key='#2A2F37', **GENERIC_D)),
  'dovetail': dict(font="'Alfa Slab One','Rockwell',serif", weight='400', size='28px', track='.5px', case='none',
    L=dict(bg='#E6EAE4', surface='#FBFBF9', fg='#1E2722', muted='#66716B', line='#C9D1CB', accent='#D65A2C', accent_ink='#FFFFFF', key='#D3DBD4', wood='#CD8F4E', wood_dark='#8C5726', wood_light='#E8C48E', wood_ink='#3B2410', good='#CD8F4E', good_ink='#3B2410', warn='#D99A12', warn_ink='#5A3E00', bad='#D04444', bad_soft='#F8DADA'),
    D=dict(bg='#1A1F1B', surface='#252B26', fg='#EDEBE3', muted='#9BA69E', line='#3A423B', accent='#F27A4E', accent_ink='#FFFFFF', key='#343C36', wood='#C9894A', wood_dark='#6E421B', wood_light='#E2B57A', wood_ink='#2A1708', good='#C9894A', good_ink='#2A1708', warn='#F1B83A', warn_ink='#2A1D00', bad='#F06A6A', bad_soft='#4A1F1F')),
  'splice': dict(font="'Big Shoulders Display','Oswald','Arial Narrow',sans-serif", weight='800', size='34px', track='2px', case='uppercase',
    L=dict(bg='#EDF0F2', surface='#FFFFFF', fg='#121519', muted='#687079', line='#C7CED5', frame='#2B3137', accent='#0E97A3', accent_ink='#FFFFFF', good='#D3EEF0', good_ink='#0B4E55', key='#D9DEE3', warn='#D99A12', warn_ink='#5A3E00', bad='#D04444', bad_soft='#F8DADA'),
    D=dict(bg='#111417', surface='#1B2025', fg='#E8EBEE', muted='#8E969E', line='#343B42', frame='#0B0E11', accent='#30CCD8', accent_ink='#06282B', good='#103D42', good_ink='#BFF0F4', key='#2A3138', warn='#F1B83A', warn_ink='#2A1D00', bad='#F06A6A', bad_soft='#4A1F1F')),
  'sprout': dict(font="'Fraunces','Georgia',serif", weight='700', size='30px', track='-.3px', case='none',
    L=dict(bg='#E6EEE8', surface='#FFFFFF', fg='#13211A', muted='#5F7367', line='#BFCFC4', accent='#1F7D4F', accent_ink='#FFFFFF', good='#CFE9D8', good_ink='#13211A', bloom='#D94F7E', bloom_ink='#FFFFFF', bloom_soft='#F7D3DF', soil='#7A5436', soil_soft='#E9D8C8', warn='#D7A11C', warn_ink='#4A3600', key='#D3DFD7', bad='#D04444', bad_soft='#F8DADA'),
    D=dict(bg='#0F1712', surface='#18231B', fg='#E7EFE9', muted='#8DA394', line='#2E3E33', accent='#3FB874', accent_ink='#06301A', good='#1C3A28', good_ink='#E7EFE9', bloom='#FF7FA8', bloom_ink='#3B0D1E', bloom_soft='#4A1F2E', soil='#C49B73', soil_soft='#3A2B1F', warn='#F0B93C', warn_ink='#3A2900', key='#263128', bad='#F06A6A', bad_soft='#4A1F1F')),
  'tangle': dict(font="'Baloo 2','Nunito',sans-serif", weight='800', size='32px', track='-.5px', case='none',
    L=dict(bg='#F0EDF6', surface='#FFFFFF', fg='#241F30', muted='#6D6682', line='#CDC7DD', accent='#5A49D6', accent_ink='#FFFFFF', t0='#E25B4A', t1='#1F9A8C', t2='#D9A520', t0_ink='#FFFFFF', t1_ink='#FFFFFF', t2_ink='#2E2300', good='#DDD8F2', good_ink='#241F30', key='#DAD6E6', warn='#D9A520', warn_ink='#2E2300', bad='#D04444', bad_soft='#F8DADA'),
    D=dict(bg='#15121D', surface='#201B2B', fg='#EEEAF6', muted='#9A93AE', line='#39324F', accent='#8C7CFF', accent_ink='#120A3A', t0='#FF7A69', t1='#36C9B7', t2='#F2C14E', t0_ink='#3A0E08', t1_ink='#05302B', t2_ink='#2E2300', good='#2A2440', good_ink='#EEEAF6', key='#2E2840', warn='#F2C14E', warn_ink='#2E2300', bad='#F26D6D', bad_soft='#4A1F1F')),
  'keystone': dict(font="'Bricolage Grotesque','Helvetica Neue',sans-serif", weight='800', size='28px', track='-.3px', case='none',
    L=dict(bg='#E8ECEF', surface='#FBFBFC', fg='#1B2229', muted='#5F6C78', line='#C5CED6', accent='#2F6F8F', accent_ink='#FFFFFF', stone='#D9CFC0', stone_ink='#2B2117', good='#D6E6EE', good_ink='#123A4D', warn='#C9892B', warn_ink='#2A1D00', bad='#C04A3A', bad_soft='#F6DCD8', key='#D3DAE0'),
    D=dict(bg='#14181C', surface='#1E242A', fg='#E9EEF2', muted='#93A0AB', line='#303A44', accent='#5FB0D4', accent_ink='#06202C', stone='#4A4036', stone_ink='#EFE6DA', good='#16323F', good_ink='#CFE8F2', warn='#E0A64A', warn_ink='#2A1D00', bad='#F07A6A', bad_soft='#4A2320', key='#2A323A')),
  'tumbler': dict(font="'Chakra Petch','Share Tech',monospace", weight='700', size='30px', track='2px', case='uppercase',
    L=dict(bg='#16191D', surface='#22272D', fg='#ECE6D6', muted='#8E94A0', line='#343B44', accent='#D9B35A', accent_ink='#2A1D00', good='#3BAF73', good_ink='#06301A', dial='#2A3038', dial_win='#11141A', dial_edge='#3B434D', warn='#D9B35A', warn_ink='#2A1D00', bad='#F07A6A', bad_soft='#4A2320', key='#2E353E'),
    D=None),
}
PAL['tumbler']['D'] = PAL['tumbler']['L']

def tokens(p, d):
    out = [f"--{k.replace('_', '-')}:{v}" for k, v in d.items()]
    out += [f"--display:{p['font']}", f"--display-weight:{p['weight']}", f"--display-size:{p['size']}", f"--display-track:{p['track']}", f"--display-case:{p['case']}"]
    return ';'.join(out)

root_light = tokens(PAL['hub'], PAL['hub']['L'])
css = []
css.append("@media (prefers-color-scheme: dark){ :root:not([data-theme=\"light\"]){" + tokens(PAL['hub'], PAL['hub']['D']) + ";color-scheme:dark} }")
css.append(":root[data-theme=\"dark\"]{" + tokens(PAL['hub'], PAL['hub']['D']) + ";color-scheme:dark}")
for gid, p in PAL.items():
    if gid == 'hub': continue
    dark = p['D']
    css.append(f":root[data-game=\"{gid}\"]{{{tokens(p, p['L'])}{';color-scheme:dark' if gid == 'tumbler' else ''}}}")
    css.append(f"@media (prefers-color-scheme: dark){{ :root:not([data-theme=\"light\"])[data-game=\"{gid}\"]{{{tokens(p, dark)};color-scheme:dark}} }}")
    css.append(f":root[data-theme=\"dark\"][data-game=\"{gid}\"]{{{tokens(p, dark)};color-scheme:dark}}")
    if gid == 'tumbler':
        css.append(f":root[data-theme=\"light\"][data-game=\"tumbler\"]{{{tokens(p, p['L'])};color-scheme:dark}}")
gamecss = '\n'.join(css) + '\n' + rd('part2_gamecss.css')

head = rd('part1_head.html').replace('__TOKENS__', '  ' + root_light.replace(';', ';\n  ') + ';').replace('__GAMECSS__', gamecss)
body = rd('part3_body.html')

# ---- data ----
ks = json.load(open(os.path.join(S, 'keystone_data.json')))
C = set(ks['common'])
dv_html = open('/home/claude/dovetail.html').read()
dv = json.loads(re.search(r'const PUZZLES = (\[.*?\]);\n', dv_html).group(1))
dv = [p for p in dv if all(w in C for w in p)]
sp = json.load(open(os.path.join(S, 'splice_data.json')))['puzzles']
sr_html = open('/home/claude/sprout.html').read()
sr = json.loads(re.search(r'const PUZZLES = (\[.*?\]);\n', sr_html).group(1))
tg = json.load(open(os.path.join(S, 'tangle_data.json')))['puzzles']
tb = json.load(open(os.path.join(S, 'tumbler_data.json')))
data = {'common': ' '.join(ks['common']), 'fused': ' '.join(ks['fused']), 'dovetail': dv, 'splice': sp, 'sprout': sr, 'tangle': tg, 'keystone': ks['days'], 'tumbler': {'answers': tb['answers'], 'guess': ' '.join(tb['guess'])}}
js = rd('part4_shell.js').replace('__DATA__', json.dumps(data, separators=(',', ':')))
for part in ['part5_dovetail.js', 'part6_splice.js', 'part7_sprout.js', 'part8_tangle.js', 'part9_keystone.js', 'part10_tumbler.js']:
    js += '\n' + rd(part)
js += "\nboot();\n"
html = head + '\n' + body + '\n<script>\n' + js + '</script>\n'
open('/home/claude/foreword.html', 'w').write(html)
open(os.path.join(H, 'foreword_full.js'), 'w').write(js)
# also write puzzle bundles for iOS
ios = '/home/claude/Foreword/Foreword/Resources/Puzzles/'
json.dump({'puzzles': dv, 'common': ks['common'], 'fused': ks['fused']}, open(ios + 'dovetail.json', 'w'), separators=(',', ':'))
json.dump({'days': ks['days']}, open(ios + 'keystone.json', 'w'), separators=(',', ':'))
json.dump({'answers': tb['answers'], 'guess': tb['guess']}, open(ios + 'tumbler.json', 'w'), separators=(',', ':'))
print('html KB', len(html) // 1024, 'dovetail', len(dv), 'splice', len(sp), 'sprout', len(sr), 'tangle', len(tg), 'keystone days', len(ks['days']), 'tumbler', len(tb['answers']))
