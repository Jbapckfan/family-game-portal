/* ===================== TUMBLER ===================== */
GAMES.tumbler = (() => {
  const id = 'tumbler', MAX = 6, ANS = DATA.tumbler.answers, GUESS = new Set(DATA.tumbler.guess.split(' '));
  const g = { id, title: 'Tumbler', tagline: 'Crack a five-letter lock by feel.', noun: 'lock', practiceLabel: 'Practice another lock', distTitle: 'Guesses per cracked lock', keyboard: true, st: null,
    bucketLabel: k => k < 6 ? String(k + 1) : null, bucket: () => g.st.guesses.length - 1 };
  const key = d => `${id}.day.${d}`;
  const daily = day => ANS[((day % ANS.length) + ANS.length) % ANS.length];
  const A = 'abcdefghijklmnopqrstuvwxyz';
  const newState = (secret, mode, day) => ({ mode, day, secret, guesses: [], typed: '', status: 'playing' });
  const fb = (guess, secret) => guess.split('').map((c, i) => c === secret[i] ? 0 : secret[i] > c ? 1 : -1);
  const rowEmoji = f => f.map(x => x === 0 ? '🟩' : x > 0 ? '🔼' : '🔽').join('');
  const emojiOf = s => s.guesses.map(x => rowEmoji(x.f)).join('\n') || '⬜⬜⬜⬜⬜';
  const emojiLine = s => s.status === 'won' ? `🔓 ${s.guesses.length}/${MAX}` : s.status === 'lost' ? `🔒 ✕/${MAX}` : `${s.guesses.length}/${MAX}`;
  function ranges(s){
    const lo = [0, 0, 0, 0, 0], hi = [25, 25, 25, 25, 25], lock = [0, 0, 0, 0, 0];
    for (const x of s.guesses) for (let i = 0; i < 5; i++){ const v = A.indexOf(x.w[i]); if (x.f[i] === 0){ lo[i] = hi[i] = v; lock[i] = 1; } else if (x.f[i] > 0) lo[i] = Math.max(lo[i], v + 1); else hi[i] = Math.min(hi[i], v - 1); }
    return { lo, hi, lock };
  }
  g.load = day => { const saved = store.get(key(day)); g.st = saved && saved.secret ? saved : newState(daily(day), 'daily', day); };
  g.summary = day => { const s = day === today && g.st && g.st.mode === 'daily' ? g.st : store.get(key(day)); if (!s || !s.secret) return null; if (s.status === 'playing' && !s.guesses.length) return null; return { status: s.status, emoji: emojiLine(s), detail: s.status === 'playing' ? `${s.guesses.length} of ${MAX} tried` : s.status === 'won' ? `${s.guesses.length} guess${s.guesses.length === 1 ? '' : 'es'}` : 'still locked' }; };
  g.emoji = () => emojiOf(g.st);
  const save = () => { if (g.st.mode === 'daily') store.set(key(g.st.day), g.st); };
  g.keyState = ch => { const st = g.st; if (!st) return ''; const { lo, hi, lock } = ranges(st); const v = A.indexOf(ch); if (lock.some((l, i) => l && st.secret[i] === ch)) return 'lock'; return [0, 1, 2, 3, 4].every(i => v < lo[i] || v > hi[i]) ? 'dead' : ''; };
  g.key = k => {
    const st = g.st;
    if (k === 'ENTER') return submit();
    if (k === 'BACK'){ st.typed = st.typed.slice(0, -1); return g.render(); }
    if (/^[a-z]$/.test(k) && st.typed.length < 5){ st.typed += k; g.render(); }
  };
  function submit(){
    const st = g.st, w = st.typed, row = () => document.querySelector('.tb-dials');
    if (w.length < 5){ toast('Five letters'); return shake(row()); }
    if (st.guesses.some(x => x.w === w)){ toast('Already tried'); return shake(row()); }
    if (!GUESS.has(w) && w !== st.secret){ toast('Not in word list'); return shake(row()); }
    const f = fb(w, st.secret); st.guesses.push({ w, f }); st.typed = '';
    if (f.every(x => x === 0)){ st.status = 'won'; toast(`<b>${w.toUpperCase()}</b> · unlocked`, 1600); }
    else if (st.guesses.length >= MAX){ st.status = 'lost'; toast(`It was <b>${st.secret.toUpperCase()}</b>`, 2400); }
    else { const locked = f.filter(x => x === 0).length; toast(locked ? `${locked} dial${locked === 1 ? '' : 's'} locked` : 'Feel the arrows', 1200); }
    save(); g.render(); paintKeyboard();
    if (st.status !== 'playing') finish(g, st.status === 'won', g.bucket());
  }
  g.render = () => {
    const st = g.st, playing = st.status === 'playing', { lo, hi, lock } = ranges(st); setSub(g);
    let h = `<div class="hud"><div class="left"><div class="tb-light">${Array.from({ length: MAX }, (_, i) => `<i class="${i < st.guesses.length ? 'on' : ''}"></i>`).join('')}</div><span>${st.status === 'won' ? 'Unlocked.' : st.status === 'lost' ? `It was ${st.secret.toUpperCase()}.` : `${MAX - st.guesses.length} guess${MAX - st.guesses.length === 1 ? '' : 'es'} left`}</span></div><span>${lock.filter(Boolean).length} of 5 locked</span></div>`;
    h += `<div class="tb-dials">${[0, 1, 2, 3, 4].map(i => { const ch = lock[i] ? st.secret[i] : (st.typed[i] || ''); const n = hi[i] - lo[i] + 1; return `<div class="tb-dial${lock[i] ? ' lock' : ''}${!lock[i] && st.typed[i] ? ' typed' : ''}"><span class="b hi">${lock[i] ? '' : A[hi[i]]}</span><div class="mid">${ch}</div><span class="b lo">${lock[i] ? '' : A[lo[i]]}</span><span class="n">${lock[i] ? 'locked' : n + ' left'}</span></div>`; }).join('')}</div>`;
    h += `<div class="tb-rows">${st.guesses.map(x => `<div class="tb-row">${x.w.split('').map((c, i) => `<div class="tb-c${x.f[i] === 0 ? ' eq' : ''}">${c}<span class="a">${x.f[i] === 0 ? '●' : x.f[i] > 0 ? '▲' : '▼'}</span></div>`).join('')}</div>`).join('')}`;
    for (let r = st.guesses.length + (playing ? 0 : 0); r < MAX; r++) h += `<div class="tb-row">${'<div class="tb-c empty"></div>'.repeat(5)}</div>`;
    h += `</div><div class="note">▲ the secret letter is later in the alphabet · ▼ earlier · ● locked. Each dial shows its remaining range.</div>`;
    $('#gbody').innerHTML = h;
  };
  g.practice = () => { let s; do { s = ANS[Math.floor(Math.random() * ANS.length)]; } while (ANS.length > 1 && s === daily(today)); g.st = newState(s, 'practice', today); };
  g.shareText = () => `Tumbler ${g.st.mode === 'daily' ? '#' + (g.st.day + 1) : '(practice)'} ${emojiLine(g.st)}\n${emojiOf(g.st)}`;
  g.resultTitle = () => g.st.status === 'won' ? (g.st.guesses.length <= 2 ? 'Safecracker.' : g.st.guesses.length <= 4 ? 'Click. Open.' : 'Open, just.') : 'Still locked.';
  g.resultDetail = () => `<div class="tb-sol">${g.st.secret}</div>`;
  g.help = `<p>A five-letter word is locked behind five dials. Guess any five-letter word; each dial then tells you which way to turn.</p>
    <div class="ex" style="flex-direction:row;gap:8px"><span style="padding:4px 8px;border-radius:6px;background:var(--surface);border:1px solid var(--line)">C ▲</span><span style="padding:4px 8px;border-radius:6px;background:var(--surface);border:1px solid var(--line)">R ▼</span><span style="padding:4px 8px;border-radius:6px;background:var(--good);color:var(--good-ink)">A ●</span><span style="padding:4px 8px;border-radius:6px;background:var(--surface);border:1px solid var(--line)">N ▼</span><span style="padding:4px 8px;border-radius:6px;background:var(--surface);border:1px solid var(--line)">E ▲</span></div>
    <p>▲ means the secret letter in that position is <b>later</b> in the alphabet than yours. ▼ means earlier. ● means you locked it. Nothing about other positions: this is a lock, not a word-scramble.</p>
    <p>Each dial shows the range still possible. Narrow all five in six guesses.</p>
    <p class="muted">Letters that are impossible in every position fade on the keyboard.</p>`;
  g.startLabel = 'Crack it';
  return g;
})();
