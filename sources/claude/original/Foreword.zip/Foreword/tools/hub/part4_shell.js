/* ===================== DATA ===================== */
const DATA = __DATA__;
const COMMON = new Set(DATA.common.split(' '));
const FUSED = new Set(DATA.fused.split(' '));
const joins = (a, b) => FUSED.has(a + b) || FUSED.has(b + a);
const EPOCH = new Date(2026, 9, 20);
function dayIndex(d){ const n = new Date(d.getFullYear(), d.getMonth(), d.getDate()); return Math.round((n - EPOCH) / 86400000); }
const today = dayIndex(new Date());
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const store = { get(k){ try { return JSON.parse(localStorage.getItem(k)); } catch(e){ return null; } }, set(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch(e){} } };
function seeded(seed){ let s = (seed * 9301 + 49297) % 233280; return () => (s = (s * 9301 + 49297) % 233280) / 233280; }
function seededShuffle(arr, seed){ const a = arr.slice(), r = seeded(seed); for (let i = a.length - 1; i > 0; i--){ const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
function msToMidnight(){ const n = new Date(), m = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1); return m - n; }
function fmt(ms){ const s = Math.max(0, Math.floor(ms / 1000)); return [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60].map(x => String(x).padStart(2, '0')).join(':'); }
const dateLabel = () => new Date().toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });

/* ===================== STATS ===================== */
function loadStats(id){ return store.get(id + '.stats') || { played: 0, won: 0, streak: 0, max: 0, last: null, dist: [0, 0, 0, 0, 0, 0, 0] }; }
function recordResult(id, day, won, bucket){
  const s = loadStats(id); if (s.last === day) return s;
  s.played++;
  if (won){ s.won++; s.streak = s.last === day - 1 ? s.streak + 1 : 1; s.max = Math.max(s.max, s.streak); s.dist[Math.min(6, Math.max(0, bucket))]++; } else s.streak = 0;
  s.last = day; store.set(id + '.stats', s); return s;
}
function statGrid(s){ return `<div class="statgrid"><div class="stat"><b>${s.played}</b><span>Played</span></div><div class="stat"><b>${s.played ? Math.round(100 * s.won / s.played) : 0}</b><span>Win %</span></div><div class="stat"><b>${s.streak}</b><span>Streak</span></div><div class="stat"><b>${s.max}</b><span>Best</span></div></div>`; }
function distBars(g, s, hl){ const mx = Math.max(1, ...s.dist); return `<div class="dist">${s.dist.map((v, k) => g.bucketLabel(k) === null ? '' : `<div class="bar${hl === k ? ' hl' : ''}"><span>${g.bucketLabel(k)}</span><i style="width:${Math.max(8, 100 * v / mx)}%">${v}</i></div>`).join('')}</div>`; }

/* ===================== UI HELPERS ===================== */
let toastT;
function toast(html, ms = 1700){ const t = $('#toast'); t.innerHTML = html; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), ms); }
function shake(el){ if (!el) return; el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake'); }
function copy(text, btn){
  const done = () => { const o = btn.textContent; btn.textContent = 'Copied'; setTimeout(() => btn.textContent = o, 1600); };
  const fb = () => { const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); done(); } catch(e){ toast('Select and copy the text above'); } ta.remove(); };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, fb); else fb();
}
function openDialog(id, html){ const d = $(id); d.querySelector('.dlg').innerHTML = `<button class="icon close" aria-label="Close">✕</button>` + html; d.querySelector('.close').onclick = () => d.close(); if (!d.open) d.showModal(); return d; }
function countdown(el){ const tick = () => { if (el && el.isConnected){ el.textContent = fmt(msToMidnight()); setTimeout(tick, 1000); } }; tick(); }

/* ===================== KEYBOARD ===================== */
function buildKeyboard(){
  const rows = ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'], inner = $('#kbdInner'); inner.innerHTML = '';
  rows.forEach((r, ri) => {
    const kr = document.createElement('div'); kr.className = 'krow';
    if (ri === 1){ const sp = document.createElement('span'); sp.className = 'sp'; kr.appendChild(sp); }
    if (ri === 2){ const b = document.createElement('button'); b.className = 'key wide'; b.textContent = 'Enter'; b.onclick = () => onKey('ENTER'); kr.appendChild(b); }
    for (const ch of r){ const b = document.createElement('button'); b.className = 'key'; b.dataset.k = ch; b.textContent = ch; b.setAttribute('aria-label', ch); b.onclick = () => onKey(ch); kr.appendChild(b); }
    if (ri === 2){ const b = document.createElement('button'); b.className = 'key wide'; b.textContent = '⌫'; b.setAttribute('aria-label', 'Backspace'); b.onclick = () => onKey('BACK'); kr.appendChild(b); }
    if (ri === 1){ const sp = document.createElement('span'); sp.className = 'sp'; kr.appendChild(sp); }
    inner.appendChild(kr);
  });
}
function paintKeyboard(){ const g = current; document.querySelectorAll('.key[data-k]').forEach(b => { const s = g && g.keyState ? g.keyState(b.dataset.k) : ''; b.className = 'key' + (s ? ' ' + s : ''); }); }
function onKey(k){ if (current && current.key && current.st && current.st.status === 'playing' && !document.querySelector('dialog[open]')) current.key(k); }
document.addEventListener('keydown', e => {
  if (e.metaKey || e.ctrlKey || e.altKey || document.querySelector('dialog[open]')) return;
  if (!current) return;
  if (e.key === 'Enter'){ e.preventDefault(); onKey('ENTER'); }
  else if (e.key === 'Backspace'){ e.preventDefault(); onKey('BACK'); }
  else if (e.key === 'Escape'){ onKey('ESC'); }
  else if (/^[a-zA-Z]$/.test(e.key)) onKey(e.key.toLowerCase());
});

/* ===================== GAME REGISTRY & ROUTER ===================== */
const GAMES = {};   // id -> game object (filled in below)
const ORDER = ['dovetail', 'splice', 'sprout', 'tangle', 'keystone', 'tumbler'];
let current = null;

function showHome(){
  current = null;
  document.documentElement.removeAttribute('data-game');
  document.body.classList.remove('kb'); $('#kbd').hidden = true;
  $('#game').hidden = true; $('#home').hidden = false;
  if (location.hash) history.replaceState(null, '', location.pathname + location.search);
  renderHome();
}
function openGame(id){
  const g = GAMES[id]; if (!g) return showHome();
  current = g;
  document.documentElement.setAttribute('data-game', id);
  $('#home').hidden = true; $('#game').hidden = false;
  $('#gTitle').textContent = g.title;
  if (!g.st || g.st.day !== today && g.st.mode === 'daily') g.load(today);
  $('#kbd').hidden = !g.keyboard; document.body.classList.toggle('kb', !!g.keyboard);
  if (location.hash !== '#' + id) history.replaceState(null, '', '#' + id);
  g.render(); paintKeyboard();
  window.scrollTo(0, 0);
  if (!store.get('seen.' + id)) showHelp(g);
  else if (g.st.status !== 'playing') setTimeout(() => showResult(g), 300);
}
function setSub(g){ $('#gSub').textContent = g.st.mode === 'daily' ? `No. ${g.st.day + 1} · ${dateLabel()}` : 'Practice'; }
function showHelp(g){ const d = openDialog('#helpDlg', `<h2>How to play</h2>${g.help}<button class="btn primary full" id="helpOk">${g.startLabel || 'Start'}</button>`); $('#helpOk').onclick = () => { d.close(); store.set('seen.' + g.id, 1); if (g.st.status !== 'playing') setTimeout(() => showResult(g), 200); }; }
function finish(g, won, bucket){
  if (g.st.mode === 'daily' && g.st.day === today) recordResult(g.id, g.st.day, won, bucket);
  setTimeout(() => showResult(g), 1000);
}
function showResult(g){
  const s = loadStats(g.id), daily = g.st.mode === 'daily';
  openDialog('#resultDlg', `
    <h2>${g.resultTitle()}</h2>
    <div class="share-pre">${g.emoji()}</div>
    ${g.resultDetail()}
    ${daily ? statGrid(s) : ''}
    <button class="btn primary full" id="shareBtn">Share</button>
    ${daily ? `<p class="muted" style="text-align:center">Next ${g.noun} in <span class="next" id="cd"></span></p>` : ''}
    <button class="btn full" id="practiceBtn">${g.practiceLabel}</button>
    <button class="btn ghost full" id="homeBtn">Back to today's six</button>`);
  $('#shareBtn').onclick = e => copy(g.shareText(), e.currentTarget);
  $('#practiceBtn').onclick = () => { $('#resultDlg').close(); g.practice(); setSub(g); g.render(); paintKeyboard(); };
  $('#homeBtn').onclick = () => { $('#resultDlg').close(); showHome(); };
  if (daily) countdown($('#cd'));
}
function showStats(g){
  if (g){
    const s = loadStats(g.id); const hl = g.st.status === 'won' && g.st.mode === 'daily' ? g.bucket() : -1;
    openDialog('#statsDlg', `<h2>Statistics</h2>${statGrid(s)}<p class="muted">${g.distTitle}</p>${distBars(g, s, hl)}${g.st.status !== 'playing' ? '<button class="btn primary full" id="stShare">Share</button>' : ''}`);
    const sh = $('#stShare'); if (sh) sh.onclick = e => copy(g.shareText(), e.currentTarget);
  } else {
    openDialog('#statsDlg', `<h2>Statistics</h2><div class="allstats">${ORDER.map(id => { const gg = GAMES[id], s = loadStats(id); return `<div class="g"><h3><i style="background:var(--c-${id})"></i>${gg.title}</h3>${statGrid(s)}</div>`; }).join('')}</div>`);
  }
}

/* ===================== HOME ===================== */
const GLYPHS = {
  dovetail: '<svg viewBox="0 0 24 24"><path d="M4 6h16v4H4zM4 14h16v4H4zM10 10l2 4 2-4"/></svg>',
  splice: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M12 5v14M7 9h.01M7 15h.01M17 9h.01M17 15h.01"/></svg>',
  sprout: '<svg viewBox="0 0 24 24"><path d="M12 21V11M12 11c0-4 3-6 7-6 0 4-3 6-7 6zM12 15c0-3-2-5-6-5 0 3 2 5 6 5z"/></svg>',
  tangle: '<svg viewBox="0 0 24 24"><path d="M4 8c4 0 4 8 8 8s4-8 8-8M4 16c4 0 4-8 8-8s4 8 8 8"/></svg>',
  keystone: '<svg viewBox="0 0 24 24"><path d="M9 4h6l2 7H7zM3 20l2-8h4l-1 8zM21 20l-2-8h-4l1 8zM9 12h6v8H9z"/></svg>',
  tumbler: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/></svg>',
};
function renderHome(){
  $('#homeSub').textContent = `No. ${today + 1} · ${dateLabel()}`;
  const grid = $('#grid'); grid.innerHTML = '';
  let played = 0, won = 0, allDone = true;
  const segs = $('#segs'); segs.innerHTML = '';
  for (const id of ORDER){
    const g = GAMES[id], sum = g.summary(today), s = loadStats(id);
    const seg = document.createElement('i'); seg.style.setProperty('--seg', `var(--c-${id})`);
    if (sum && sum.status !== 'playing'){ played++; if (sum.status === 'won') won++; seg.className = 'on'; } else { allDone = false; if (sum) seg.className = 'half'; }
    segs.appendChild(seg);
    const t = document.createElement('button'); t.className = 'tile'; t.style.setProperty('--tc', `var(--c-${id})`);
    const status = !sum ? `<span>Play</span>` : sum.status === 'playing' ? `<span>In progress · ${esc(sum.detail)}</span>` : `<span class="em">${sum.emoji}</span>`;
    t.innerHTML = `<div class="glyph">${GLYPHS[id]}</div><div class="name">${g.title}</div><div class="tag">${g.tagline}</div><div class="status ${sum && sum.status === 'won' ? 'done' : sum && sum.status === 'lost' ? 'lost' : ''}">${status}${s.streak > 0 ? `<span class="fl">🔥${s.streak}</span>` : ''}</div>`;
    t.onclick = () => openGame(id);
    grid.appendChild(t);
  }
  $('#meterSub').textContent = allDone ? `${won} of 6 solved` : `${played} of 6 played`;
  $('#meterTitle').textContent = allDone ? (won === 6 ? 'A perfect six.' : 'All six done.') : "Today's six";
  $('#sixShare').hidden = !allDone;
}
function sixShareText(){ return `Foreword #${today + 1}\n` + ORDER.map(id => { const g = GAMES[id], s = g.summary(today); return `${g.title} ${s ? s.emoji : '—'}`; }).join('\n'); }

function boot(){
  buildKeyboard();
  $('#backBtn').onclick = showHome;
  $('#gHelp').onclick = () => showHelp(current);
  $('#gStats').onclick = () => showStats(current);
  $('#homeStats').onclick = () => showStats(null);
  $('#homeHelp').onclick = () => openDialog('#helpDlg', `<h2>Six games. One a day each.</h2><p>Every game gives you one puzzle a day, the same puzzle for everyone, numbered from No. 1. Each keeps its own streak and stats, and each has a practice mode once today's is done.</p><div class="legend">${ORDER.map(id => `<div class="sw" style="background:var(--c-${id})"></div><div><b>${GAMES[id].title}</b> · ${GAMES[id].tagline}</div>`).join('')}</div><p class="muted">Finish all six to share one combined result. New puzzles at midnight, your local time.</p><button class="btn primary full" id="helpOk">Got it</button>`).querySelector('#helpOk').onclick = () => $('#helpDlg').close();
  $('#sixShare').onclick = e => copy(sixShareText(), e.currentTarget);
  for (const id of ORDER) GAMES[id].load(today);
  const h = (location.hash || '').replace('#', '');
  if (GAMES[h]) openGame(h); else showHome();
  window.addEventListener('hashchange', () => { const h = (location.hash || '').replace('#', ''); if (GAMES[h]) { if (current !== GAMES[h]) openGame(h); } else if (current) showHome(); });
  document.addEventListener('visibilitychange', () => { if (!document.hidden && dayIndex(new Date()) !== today) location.reload(); });
}
