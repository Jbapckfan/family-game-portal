/* ===================== DOVETAIL ===================== */
GAMES.dovetail = (() => {
  const id = 'dovetail', MAX = 6, PUZ = DATA.dovetail;
  const g = { id, title: 'Dovetail', tagline: 'Eight words. Each joins the next.', noun: 'chain', practiceLabel: 'Practice another chain', distTitle: 'Misses per solved chain', keyboard: true, st: null,
    bucketLabel: k => k === 6 ? '6+' : String(k), bucket: () => Math.min(6, g.st.misses) };
  const key = d => `${id}.day.${d}`;
  const newState = (words, mode, day) => { const n = words.length; return { mode, day, words: words.slice(), solved: words.map((_, i) => i === 0 || i === n - 1), guesses: words.map(() => []), hints: words.map(() => 0), misses: 0, status: 'playing', active: 1, typed: '' }; };
  const emojiOf = s => { let o = ''; for (let i = 1; i < s.words.length - 1; i++) o += !s.solved[i] ? '🟥' : (s.guesses[i].length || s.hints[i]) ? '🟨' : '🟩'; return o; };
  g.load = day => { const saved = store.get(key(day)); g.st = saved && saved.words ? saved : newState(PUZ[((day % PUZ.length) + PUZ.length) % PUZ.length], 'daily', day); };
  g.summary = day => { const s = day === today && g.st && g.st.mode === 'daily' ? g.st : store.get(key(day)); if (!s || !s.words) return null; const n = s.solved.filter(Boolean).length - 2; if (s.status === 'playing' && n === 0 && s.misses === 0) return null; return { status: s.status, emoji: emojiOf(s), detail: s.status === 'playing' ? `${n} of ${s.words.length - 2} placed` : s.status === 'won' ? `${s.misses} miss${s.misses === 1 ? '' : 'es'}` : 'chain broke' }; };
  g.emoji = () => emojiOf(g.st);
  const save = () => { if (g.st.mode === 'daily') store.set(key(g.st.day), g.st); };
  const nextOpen = from => { const n = g.st.words.length; for (let k = 1; k < n; k++){ const j = (from + k) % n; if (!g.st.solved[j]) return j; } return -1; };
  function judge(i, word){
    const st = g.st, sol = st.words[i];
    if (word.length !== sol.length) return { kind: 'short' };
    if (st.guesses[i].some(x => x.w === word)) return { kind: 'dupe' };
    if (word === sol) return { kind: 'solve', word };
    const left = st.solved[i - 1] ? st.words[i - 1] : null, right = st.solved[i + 1] ? st.words[i + 1] : null;
    const fitUp = !!left && FUSED.has(left + word), fitDown = !!right && FUSED.has(word + right);
    if (left && right && fitUp && fitDown && COMMON.has(word)) return { kind: 'solve', word, alt: true };
    if (!COMMON.has(word)) return { kind: 'notword' };
    return { kind: 'miss', fitUp, fitDown, left, right };
  }
  g.key = k => {
    const st = g.st; if (st.active < 0) return;
    const len = st.words[st.active].length, h = st.hints[st.active];
    if (k === 'ENTER') return submit();
    if (k === 'BACK'){ if (st.typed.length > h) st.typed = st.typed.slice(0, -1); return g.render(); }
    if (/^[a-z]$/.test(k) && st.typed.length < len){ st.typed += k; g.render(); }
  };
  function submit(){
    const st = g.st, i = st.active, word = st.typed, r = judge(i, word), row = () => document.querySelector(`.dv-row[data-i="${i}"]`);
    if (r.kind === 'short'){ toast('Too short'); return shake(row()); }
    if (r.kind === 'dupe'){ toast('Already tried'); return shake(row()); }
    if (r.kind === 'notword'){ toast('Not in word list'); return shake(row()); }
    if (r.kind === 'solve'){
      st.words[i] = r.word; st.solved[i] = true; st.typed = '';
      const up = st.solved[i - 1] ? (st.words[i - 1] + r.word).toUpperCase() : null, dn = st.solved[i + 1] ? (r.word + st.words[i + 1]).toUpperCase() : null;
      toast([up, dn].filter(Boolean).map(x => `<b>${x}</b>`).join(' · ') || 'Fits!', 1800);
      if (st.solved.every(Boolean)) st.status = 'won'; else st.active = nextOpen(i);
      g.render(); const nr = row(); if (nr) nr.classList.add('pop'); save();
      if (st.status === 'won') finish(g, true, g.bucket());
      return;
    }
    st.guesses[i].push({ w: word, up: r.fitUp, down: r.fitDown }); st.misses++; st.typed = st.words[i].slice(0, st.hints[i]);
    const W = word.toUpperCase();
    if (r.fitUp && r.fitDown) toast(`<b>${(r.left + word).toUpperCase()}</b> and <b>${(word + r.right).toUpperCase()}</b> are words, but not this chain`, 2400);
    else if (r.fitUp) toast(`<b>${(r.left + word).toUpperCase()}</b> fits above, but ${W} doesn't reach below`, 2400);
    else if (r.fitDown) toast(`<b>${(word + r.right).toUpperCase()}</b> fits below, but above doesn't reach ${W}`, 2400);
    else toast(`${W} joins neither side`, 1600);
    if (st.misses >= MAX) st.status = 'lost';
    g.render(); shake(row()); save();
    if (st.status === 'lost') finish(g, false, 6);
  }
  function hint(){
    const st = g.st; if (st.status !== 'playing' || st.active < 0) return;
    const i = st.active, len = st.words[i].length; if (st.hints[i] >= len - 1) return;
    st.hints[i]++; st.misses++; st.typed = st.words[i].slice(0, st.hints[i]);
    if (st.misses >= MAX) st.status = 'lost';
    g.render(); save();
    if (st.status === 'lost') finish(g, false, 6); else toast('Letter revealed · 1 miss');
  }
  g.render = () => {
    const st = g.st, n = st.words.length; setSub(g);
    const left = MAX - st.misses;
    let h = `<div class="hud"><div class="left"><div class="dots">${Array.from({ length: MAX }, (_, k) => `<span class="dv-pin${k < st.misses ? ' used' : ''}"></span>`).join('')}</div><span>${st.status === 'won' ? 'Joined!' : st.status === 'lost' ? 'The chain broke' : `${left} miss${left === 1 ? '' : 'es'} left`}</span></div><button class="pill" id="dvHint" ${st.status !== 'playing' || st.active < 0 || st.hints[st.active] >= st.words[st.active].length - 1 ? 'disabled' : ''}>Reveal a letter · costs 1</button></div><div class="dv-board">`;
    for (let i = 0; i < n; i++){
      const w = st.words[i], known = st.solved[i], lost = st.status === 'lost' && !known, given = i === 0 || i === n - 1;
      const cls = 'dv-row ' + (i === 0 ? 'first ' : i === n - 1 ? 'last ' : '') + (given ? 'given' : known ? 'solved' : lost ? 'broken' : 'open') + (w.length > 8 ? ' long' : '') + (i === st.active && st.status === 'playing' ? ' active' : '');
      let cells = '';
      for (let k = 0; k < w.length; k++){
        let ch = '', c = '';
        if (known || lost) ch = w[k]; else if (k < st.hints[i]){ ch = w[k]; c = ' hintl'; } else if (i === st.active && k < st.typed.length){ ch = st.typed[k]; c = ' filled'; }
        cells += `<div class="dv-cell${c}">${ch}</div>`;
      }
      let chips = '';
      if (!known && !lost && st.guesses[i].length) chips = `<div class="dv-chips">${st.guesses[i].map(x => `<span class="dv-chip${x.up || x.down ? ' fit' : ''}">${x.up ? '<span class="arr">▲</span>' : ''}${x.w}${x.down ? '<span class="arr">▼</span>' : ''}</span>`).join('')}</div>`;
      h += `<div class="${cls}" data-i="${i}"><div class="dv-cells">${cells}</div>${chips}</div>`;
      if (i < n - 1 && (known || lost) && (st.solved[i + 1] || st.status === 'lost')) h += `<div class="dv-seamwrap"><span class="dv-seam">${st.words[i] + st.words[i + 1]}</span></div>`;
    }
    h += `</div><div class="note">Each word, joined to the next, spells a new word.</div>`;
    $('#gbody').innerHTML = h;
    $('#dvHint').onclick = hint;
    document.querySelectorAll('.dv-row.open').forEach(r => r.onclick = () => { if (st.status !== 'playing') return; st.active = +r.dataset.i; st.typed = st.words[st.active].slice(0, st.hints[st.active]); g.render(); });
  };
  g.practice = () => { let idx; do { idx = Math.floor(Math.random() * PUZ.length); } while (PUZ.length > 1 && PUZ[idx] === PUZ[((today % PUZ.length) + PUZ.length) % PUZ.length]); g.st = newState(PUZ[idx], 'practice', today); };
  g.shareText = () => `Dovetail ${g.st.mode === 'daily' ? '#' + (g.st.day + 1) : '(practice)'}\n${g.emoji()}\n${g.st.status === 'won' ? g.st.misses + ' miss' + (g.st.misses === 1 ? '' : 'es') : 'Chain broke ✕'}`;
  g.resultTitle = () => g.st.status === 'won' ? (g.st.misses === 0 ? 'Flawless joinery.' : g.st.misses <= 2 ? 'Tight joints.' : 'Joined.') : 'The chain broke.';
  g.resultDetail = () => { const st = g.st, n = st.words.length; let l = ''; for (let i = 0; i < n - 1; i++) l += `<div><span class="${st.status === 'lost' && !st.solved[i] ? 'miss' : ''}">${st.words[i]}</span><span class="fz">${st.words[i] + st.words[i + 1]}</span></div>`; return `<div class="chainlist">${l}<div><span>${st.words[n - 1]}</span></div></div>`; };
  g.help = `<p>Eight words stack into a chain. Each word, joined to the one below it, spells a new word. The top and bottom are given. Fill in the six between.</p>
    <div class="ex"><div>FIRE</div><div class="f">fire+arm = firearm</div><div style="color:var(--wood-dark)">ARM</div><div class="f">arm+pit = armpit</div><div>PIT</div></div>
    <p>Joins can be real compounds (BOOK+WORM) or pure spelling (CAR+PET, THIN+KING). Only the letters matter.</p>
    <div class="legend"><div class="sw" style="background:var(--wood)"></div><div>Correct. The planks join.</div><div class="sw" style="background:var(--warn)"></div><div>Wrong, but it fits one neighbor. The chip shows which.</div><div class="sw" style="background:var(--key)"></div><div>Wrong, fits neither.</div></div>
    <p class="muted">Tap any row to type there. Six misses break the chain. Revealing a letter costs one miss.</p>`;
  return g;
})();
