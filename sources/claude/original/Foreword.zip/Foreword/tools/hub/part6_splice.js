/* ===================== SPLICE ===================== */
GAMES.splice = (() => {
  const id = 'splice', MAX = 4, PUZ = DATA.splice;
  const g = { id, title: 'Splice', tagline: 'Twelve halves. Six words. One way.', noun: 'bin', practiceLabel: 'Practice another bin', distTitle: 'Mistakes per solved bin', keyboard: false, st: null,
    bucketLabel: k => k <= 3 ? String(k) : null, bucket: () => Math.min(3, g.st.mistakes) };
  const key = d => `${id}.day.${d}`;
  const daily = day => PUZ[((day % PUZ.length) + PUZ.length) % PUZ.length];
  const newState = (parts, mode, day, seed) => ({ mode, day, parts, order: seededShuffle(parts.flat().map((_, i) => i), seed + 11), done: [], mistakes: 0, status: 'playing', sel: [], attempts: [], tried: [] });
  const emojiOf = s => s.attempts.map(x => x ? '🟩' : '🟥').join('');
  g.load = day => { const saved = store.get(key(day)); g.st = saved && saved.parts ? saved : newState(daily(day), 'daily', day, day); };
  g.summary = day => { const s = day === today && g.st && g.st.mode === 'daily' ? g.st : store.get(key(day)); if (!s || !s.parts) return null; if (s.status === 'playing' && !s.attempts.length) return null; return { status: s.status, emoji: emojiOf(s), detail: s.status === 'playing' ? `${s.done.length} of 6 spliced` : s.status === 'won' ? (s.mistakes ? `${s.mistakes} mistake${s.mistakes === 1 ? '' : 's'}` : 'clean cut') : 'reel cut' }; };
  g.emoji = () => emojiOf(g.st);
  const save = () => { if (g.st.mode === 'daily') store.set(key(g.st.day), g.st); };
  const tiles = () => g.st.parts.flat();
  function judge(i, j){
    const t = tiles(), a = t[i], b = t[j];
    if (g.st.tried.includes(a + '+' + b)) return { kind: 'dupe' };
    if (Math.floor(i / 2) === Math.floor(j / 2) && i % 2 === 0 && j === i + 1) return { kind: 'solve', pair: Math.floor(i / 2), word: a + b };
    if (FUSED.has(a + b)) return { kind: 'miss', word: a + b };
    return { kind: 'notword', word: a + b };
  }
  function splice(){
    const st = g.st; if (st.sel.length !== 2) return;
    const [i, j] = st.sel, r = judge(i, j), W = (r.word || '').toUpperCase();
    if (r.kind === 'dupe') return toast('Already tried that');
    if (r.kind === 'notword'){ toast(`${W} isn't a word`); shakeSel(); st.sel = []; return g.render(); }
    if (r.kind === 'solve'){
      toast(`<b>${W}</b>`, 1200); document.querySelectorAll('.sp-tile.sel').forEach(t => t.classList.add('out'));
      st.done.push(r.pair); st.attempts.push(1); st.sel = [];
      if (st.done.length === st.parts.length) st.status = 'won';
      save(); setTimeout(() => { g.render(); if (st.status === 'won') finish(g, true, g.bucket()); }, 280); return;
    }
    st.tried.push(tiles()[i] + '+' + tiles()[j]); st.mistakes++; st.attempts.push(0); st.sel = [];
    toast(`<b>${W}</b> is a word, but it strands another half`, 2200);
    if (st.mistakes >= MAX) st.status = 'lost';
    shakeSel(); save(); g.render();
    if (st.status === 'lost') finish(g, false, 0);
  }
  const shakeSel = () => document.querySelectorAll('.sp-tile.sel').forEach(shake);
  g.render = () => {
    const st = g.st, t = tiles(), left = MAX - st.mistakes; setSub(g);
    const show = st.status === 'lost' ? [...st.done, ...st.parts.map((_, k) => k).filter(k => !st.done.includes(k))] : st.done;
    let h = `<div class="hud"><span>${st.status === 'won' ? 'All six spliced.' : st.status === 'lost' ? 'The reel is cut.' : `${6 - st.done.length} words to go · ${left} mistake${left === 1 ? '' : 's'} left`}</span><div class="dots">${Array.from({ length: MAX }, (_, k) => `<span class="dot${k < st.mistakes ? ' off' : ''}"></span>`).join('')}</div></div>`;
    h += `<div class="sp-reel">${show.map(k => `<div class="sp-strip${st.done.includes(k) ? '' : ' missed'}"><span>${st.parts[k][0]}</span><span class="seam"></span><span>${st.parts[k][1]}</span></div>`).join('')}</div>`;
    const join = st.sel.length === 2 ? `<span>${t[st.sel[0]]}</span><span class="plus">+</span><span>${t[st.sel[1]]}</span>` : st.sel.length === 1 ? `<span>${t[st.sel[0]]}</span><span class="plus">+</span><span class="ph">pick a second half</span>` : `<span class="ph">${st.status === 'playing' ? 'Pick two halves to splice them.' : st.status === 'won' ? 'Nice cut.' : 'Better luck tomorrow.'}</span>`;
    h += `<div class="sp-bar"><div class="join">${join}</div><div class="ctl">${st.sel.length === 2 ? '<button class="btn" id="spFlip" aria-label="Swap order">⇄</button><button class="btn primary" id="spGo">Splice</button>' : ''}</div></div>`;
    if (st.status === 'playing'){
      h += `<div class="sp-bin">${st.order.filter(i => !st.done.includes(Math.floor(i / 2))).map(i => `<button class="sp-tile${t[i].length > 6 ? ' long' : ''}${st.sel.includes(i) ? ' sel' : ''}" data-i="${i}" aria-pressed="${st.sel.includes(i)}">${t[i]}</button>`).join('')}</div>`;
      h += `<div class="sp-tools"><button class="btn ghost" id="spShuffle">Shuffle</button><button class="btn ghost" id="spClear" ${st.sel.length ? '' : 'disabled'}>Deselect</button></div>`;
    }
    h += `<div class="note">Every half pairs with something. Only one way uses them all.</div>`;
    $('#gbody').innerHTML = h;
    document.querySelectorAll('.sp-tile').forEach(b => b.onclick = () => { const i = +b.dataset.i, k = st.sel.indexOf(i); if (k >= 0) st.sel.splice(k, 1); else if (st.sel.length < 2) st.sel.push(i); else st.sel[1] = i; g.render(); });
    const f = $('#spFlip'); if (f) f.onclick = () => { st.sel.reverse(); g.render(); };
    const go = $('#spGo'); if (go) go.onclick = splice;
    const sh = $('#spShuffle'); if (sh) sh.onclick = () => { for (let i = st.order.length - 1; i > 0; i--){ const j = Math.floor(Math.random() * (i + 1)); [st.order[i], st.order[j]] = [st.order[j], st.order[i]]; } g.render(); };
    const cl = $('#spClear'); if (cl) cl.onclick = () => { st.sel = []; g.render(); };
  };
  g.key = k => { if (k === 'ENTER') splice(); else if (k === 'ESC' || k === 'BACK'){ g.st.sel = []; g.render(); } };
  g.practice = () => { let idx; do { idx = Math.floor(Math.random() * PUZ.length); } while (PUZ.length > 1 && PUZ[idx] === daily(today)); g.st = newState(PUZ[idx], 'practice', today, today + idx); };
  g.shareText = () => `Splice ${g.st.mode === 'daily' ? '#' + (g.st.day + 1) : '(practice)'}\n${g.emoji()}\n${g.st.status === 'won' ? (g.st.mistakes ? g.st.mistakes + ' mistake' + (g.st.mistakes === 1 ? '' : 's') : 'Clean cut') : g.st.done.length + '/6 before the cut'}`;
  g.resultTitle = () => g.st.status === 'won' ? (g.st.mistakes === 0 ? 'Clean cut.' : 'Spliced.') : 'The reel is cut.';
  g.resultDetail = () => `<div class="sp-reel">${g.st.parts.map((p, k) => `<div class="sp-strip${g.st.done.includes(k) ? '' : ' missed'}" style="font-size:18px;padding:6px 10px"><span>${p[0]}</span><span class="seam" style="height:18px"></span><span>${p[1]}</span></div>`).join('')}</div>`;
  g.help = `<p>Twelve word-halves are in the bin. Splice them into six words, using every half exactly once.</p>
    <div class="ex" style="flex-direction:row;gap:6px;flex-wrap:wrap"><span style="border:2px solid var(--accent);background:var(--good);border-radius:4px;padding:2px 8px;font-size:15px">FIRE</span><span style="border:2px solid var(--frame);border-radius:4px;padding:2px 8px;font-size:15px">WOOD</span><span style="border:2px solid var(--accent);background:var(--good);border-radius:4px;padding:2px 8px;font-size:15px">PLACE</span><span style="border:2px solid var(--frame);border-radius:4px;padding:2px 8px;font-size:15px">WORK</span></div>
    <p>FIRE could take WOOD or PLACE. That's the trap: many pairs make real words, but only one set of six uses all twelve. A splice that spells a real word but isn't in today's set costs a mistake. One that isn't a word costs nothing.</p>
    <p class="muted">Tap two halves, then Splice. Use ⇄ to swap the order. Four mistakes and the reel is cut.</p>`;
  return g;
})();
