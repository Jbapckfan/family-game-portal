/* ===================== SPROUT ===================== */
GAMES.sprout = (() => {
  const id = 'sprout', MAX = 5, PUZ = DATA.sprout;
  const g = { id, title: 'Sprout', tagline: 'Grow a seed into a bloom.', noun: 'seed', practiceLabel: 'Plant a practice seed', distTitle: 'Wilts per bloom', keyboard: false, st: null,
    bucketLabel: k => k <= 4 ? (k === 4 ? '4+' : String(k)) : null, bucket: () => Math.min(4, g.st.wilts) };
  const key = d => `${id}.day.${d}`;
  const daily = day => PUZ[((day % PUZ.length) + PUZ.length) % PUZ.length];
  const sortl = s => s.split('').sort().join('');
  const newState = (p, mode, day) => ({ mode, day, seed: p.seed, pool: p.pool, levels: p.levels, stack: [p.seed], soilUsed: p.pool.split('').map(() => false), typed: [], wilts: 0, status: 'playing', lvlWilt: {}, hint: null });
  const cur = () => g.st.stack[g.st.stack.length - 1];
  const level = () => cur().length + 1;
  const remPool = () => g.st.pool.split('').filter((c, i) => !g.st.soilUsed[i]);
  const emojiOf = s => { let o = '🌱'; for (let k = 4; k <= 8; k++) o += s.stack.some(w => w.length === k) ? (s.lvlWilt[k] ? '🟨' : '🟩') : '⬜'; return o + (s.status === 'won' ? '🌸' : s.status === 'lost' ? '🥀' : ''); };
  g.load = day => { const saved = store.get(key(day)); g.st = saved && saved.stack ? saved : newState(daily(day), 'daily', day); };
  g.summary = day => { const s = day === today && g.st && g.st.mode === 'daily' ? g.st : store.get(key(day)); if (!s || !s.stack) return null; if (s.status === 'playing' && s.stack.length === 1 && s.wilts === 0) return null; const len = s.stack[s.stack.length - 1].length; return { status: s.status, emoji: emojiOf(s), detail: s.status === 'playing' ? `${len} letters tall` : s.status === 'won' ? (s.wilts ? `${s.wilts} wilt${s.wilts === 1 ? '' : 's'}` : 'no wilts') : `died at ${len}` }; };
  g.emoji = () => emojiOf(g.st);
  const save = () => { if (g.st.mode === 'daily') store.set(key(g.st.day), g.st); };
  function judge(word){
    const c = cur(), k = c.length + 1; if (word.length !== k) return { kind: 'short' };
    let rest = word.split(''); for (const ch of c){ const j = rest.indexOf(ch); if (j < 0) return { kind: 'bad' }; rest.splice(j, 1); }
    if (rest.length !== 1 || !remPool().includes(rest[0])) return { kind: 'bad' };
    const L = g.st.levels[String(k)];
    if (L && L.a.includes(word)) return { kind: 'grow', word, added: rest[0] };
    if (L && L.d.includes(word)) return { kind: 'dead', word };
    return { kind: 'notword' };
  }
  function hintLetter(){ const c = sortl(cur()), L = g.st.levels[String(level())]; if (!L) return null; for (const ch of [...new Set(remPool())].sort()){ const k2 = sortl(c + ch); if (L.a.some(w => sortl(w) === k2)) return ch; } return null; }
  function grow(){
    const st = g.st; if (st.status !== 'playing') return;
    const word = st.typed.map(e => e.ch).join(''), k = level(), r = judge(word), W = word.toUpperCase(), row = () => document.querySelector('.sr-lvl.active');
    if (r.kind === 'short'){ toast(`Use all ${k} letters`); return shake(row()); }
    if (r.kind === 'bad'){ toast('Use every letter you have, plus one from the soil'); return shake(row()); }
    if (r.kind === 'notword'){ toast('Not in word list'); return shake(row()); }
    if (r.kind === 'dead'){
      st.lvlWilt[k] = (st.lvlWilt[k] || 0) + 1; st.wilts++; st.typed = [];
      toast(`<b>${W}</b> is a word, but nothing grows from it`, 2300);
      if (st.wilts >= MAX) st.status = 'lost';
      g.render(); shake(row()); save(); if (st.status === 'lost') finish(g, false, 0); return;
    }
    st.stack.push(r.word); const idx = st.pool.split('').findIndex((c, i) => c === r.added && !st.soilUsed[i]); st.soilUsed[idx] = true; st.typed = []; st.hint = null;
    if (r.word.length === 8) st.status = 'won';
    toast(st.status === 'won' ? `<b>${W}</b> · in bloom` : `<b>${W}</b>`, 1400);
    g.render('grow'); save(); if (st.status === 'won') finish(g, true, g.bucket());
  }
  function hint(){
    const st = g.st; if (st.status !== 'playing' || st.hint) return;
    const c = hintLetter(); if (!c) return toast('Nothing grows here. Check your word.');
    st.hint = c; st.wilts++; st.lvlWilt[level()] = (st.lvlWilt[level()] || 0) + 1;
    if (st.wilts >= MAX) st.status = 'lost';
    save(); g.render(); if (st.status === 'lost') finish(g, false, 0); else toast(`Add <b>${c.toUpperCase()}</b> · 1 wilt`);
  }
  function examplePath(){
    const st = g.st; let path = st.stack.slice(), c = path[path.length - 1]; const used = st.soilUsed.slice();
    while (c.length < 8){ const L = st.levels[String(c.length + 1)]; if (!L) break; const rem = st.pool.split('').filter((x, i) => !used[i]); let f = null;
      for (const w of L.a){ let rest = w.split(''), ok = true; for (const ch of c){ const j = rest.indexOf(ch); if (j < 0){ ok = false; break; } rest.splice(j, 1); } if (ok && rest.length === 1 && rem.includes(rest[0])){ f = [w, rest[0]]; break; } }
      if (!f) break; path.push(f[0]); used[st.pool.split('').findIndex((x, i) => x === f[1] && !used[i])] = true; c = f[0]; }
    return path;
  }
  g.render = anim => {
    const st = g.st, c = cur(), k = level(), playing = st.status === 'playing'; setSub(g);
    let h = `<div class="hud"><div class="left"><div class="dots">${Array.from({ length: MAX }, (_, i) => `<span class="leaf${i < st.wilts ? ' wilted' : ''}"></span>`).join('')}</div><span>${st.status === 'won' ? 'Bloomed!' : st.status === 'lost' ? 'The plant died.' : `${8 - c.length} to bloom`}</span></div><button class="pill" id="srHint" ${!playing || st.hint ? 'disabled' : ''}>Which letter? · costs 1</button></div><div class="sr-stem">`;
    for (let n = 8; n >= 3; n--){
      const w = st.stack.find(x => x.length === n);
      if (w) h += `<div class="sr-lvl filled${n === 8 ? ' top' : ''}${n === 3 ? ' seed' : ''}${anim === 'grow' && n === c.length ? ' grow' : ''}">${w.split('').map(ch => `<span class="sr-t">${ch}</span>`).join('')}</div>`;
      else if (n === k && playing) h += `<div class="sr-lvl active">${Array.from({ length: n }, (_, i) => { const e = st.typed[i]; return `<span class="sr-t${e ? ' typed' + (e.src === 'soil' ? ' fromsoil' : '') : ''}" data-i="${i}">${e ? e.ch : ''}</span>`; }).join('')}</div>`;
      else h += `<div class="sr-lvl ghost">${'<span class="sr-t"></span>'.repeat(n)}</div>`;
    }
    h += `</div><div class="sr-rack"><div class="lab">Your word</div><div class="sr-tiles">${c.split('').map((ch, i) => `<button class="sr-tile${st.typed.some(e => e.src === 'cur' && e.i === i) ? ' used' : ''}" data-src="cur" data-i="${i}" ${!playing ? 'disabled' : ''}>${ch}</button>`).join('')}</div>`;
    const soilTaken = st.typed.some(e => e.src === 'soil');
    h += `<div class="lab">Soil · add one</div><div class="sr-tiles">${st.pool.split('').map((ch, i) => { if (st.soilUsed[i]) return ''; const used = st.typed.some(e => e.src === 'soil' && e.i === i); return `<button class="sr-tile soil${used || soilTaken ? ' used' : ''}${st.hint === ch && !used ? ' hint' : ''}" data-src="soil" data-i="${i}" ${used || soilTaken || !playing ? 'disabled' : ''}>${ch}</button>`; }).join('')}</div>`;
    h += `<div class="sr-ctl"><button class="btn" id="srClear" ${st.typed.length ? '' : 'disabled'}>Clear</button><button class="btn" id="srBack" ${st.typed.length ? '' : 'disabled'}>⌫</button><button class="btn primary" id="srGrow" ${!playing || st.typed.length !== k ? 'disabled' : ''}>Grow</button></div></div><div class="note">Add one letter, rearrange everything, grow a new word.</div>`;
    $('#gbody').innerHTML = h;
    $('#srHint').onclick = hint; $('#srGrow').onclick = grow; $('#srBack').onclick = () => { st.typed.pop(); g.render(); }; $('#srClear').onclick = () => { st.typed = []; g.render(); };
    document.querySelectorAll('.sr-tile').forEach(b => b.onclick = () => tap(b.dataset.src, +b.dataset.i));
    document.querySelectorAll('.sr-lvl.active .sr-t.typed').forEach(t => t.onclick = () => { st.typed.splice(+t.dataset.i, 1); g.render(); });
  };
  function tap(src, i){ const st = g.st; if (st.status !== 'playing' || st.typed.length >= level()) return; if (src === 'soil' && st.typed.some(e => e.src === 'soil')) return toast('Only one soil letter per turn'); st.typed.push({ src, i, ch: src === 'cur' ? cur()[i] : st.pool[i] }); g.render(); }
  g.key = k => { const st = g.st; if (k === 'ENTER') return grow(); if (k === 'BACK'){ st.typed.pop(); return g.render(); } if (!/^[a-z]$/.test(k)) return;
    const c = cur(); for (let i = 0; i < c.length; i++) if (c[i] === k && !st.typed.some(e => e.src === 'cur' && e.i === i)) return tap('cur', i);
    for (let i = 0; i < st.pool.length; i++) if (st.pool[i] === k && !st.soilUsed[i] && !st.typed.some(e => e.src === 'soil' && e.i === i)) return tap('soil', i);
    toast(`No ${k.toUpperCase()} available`); };
  g.practice = () => { let idx; do { idx = Math.floor(Math.random() * PUZ.length); } while (PUZ.length > 1 && PUZ[idx] === daily(today)); g.st = newState(PUZ[idx], 'practice', today); };
  g.shareText = () => `Sprout ${g.st.mode === 'daily' ? '#' + (g.st.day + 1) : '(practice)'}\n${g.emoji()}\n${g.st.status === 'won' ? (g.st.wilts ? g.st.wilts + ' wilt' + (g.st.wilts === 1 ? '' : 's') : 'No wilts') : 'Died at ' + cur().length + ' letters'}`;
  g.resultTitle = () => g.st.status === 'won' ? (g.st.wilts === 0 ? 'Perfect bloom.' : 'In bloom.') : 'The plant died.';
  g.resultDetail = () => { const won = g.st.status === 'won', path = won ? g.st.stack : examplePath(); return `${won ? '' : '<p class="muted" style="text-align:center">One way it could have grown:</p>'}<div class="sr-path">${path.map((w, i) => `<span class="w ${i === 0 ? 'seedw' : w.length === 8 ? 'top' : ''}">${w}</span>`).join('')}</div>`; };
  g.startLabel = 'Plant';
  g.help = `<p>Start from a three-letter seed. Each turn, take one letter from the soil, add it to the letters you have, and rearrange them all into a new word. Reach eight letters to bloom.</p>
    <div class="ex"><span>EAR</span><span class="f">+ T</span><span>RATE</span><span class="f">+ C</span><span>CRATE</span><span class="f">+ N … + I … + O</span><span>REACTION</span></div>
    <p>Many paths work. But some real words are dead ends: nothing grows from them. Planting one wilts a leaf and sends you back a step. Five wilts and the plant dies.</p>
    <p class="muted">Tap letters to spell, then Grow. Tap a letter in the row to put it back. "Which letter?" marks a soil letter that keeps the plant alive; it costs a wilt.</p>`;
  return g;
})();
