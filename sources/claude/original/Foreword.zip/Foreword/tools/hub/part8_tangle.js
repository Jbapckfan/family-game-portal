/* ===================== TANGLE ===================== */
GAMES.tangle = (() => {
  const id = 'tangle', MAX = 4, PUZ = DATA.tangle;
  const g = { id, title: 'Tangle', tagline: 'Three words, shuffled together.', noun: 'tangle', practiceLabel: 'Practice another tangle', distTitle: 'Knots per untangling', keyboard: false, st: null,
    bucketLabel: k => k <= 3 ? String(k) : null, bucket: () => Math.min(3, g.st.knots) };
  const key = d => `${id}.day.${d}`;
  const daily = day => PUZ[((day % PUZ.length) + PUZ.length) % PUZ.length];
  const isWord = w => COMMON.has(w);
  const newState = (p, mode, day) => ({ mode, day, s: p.s, w: p.w, o: p.o, removed: p.s.split('').map(() => false), pulled: [], sel: [], knots: 0, status: 'playing', attempts: [], hints: [], tried: [] });
  const emojiOf = s => s.attempts.map(x => x ? '🟩' : '🟥').join('') + (s.status === 'won' ? '🧵' : s.status === 'lost' ? '🪢' : '');
  const remaining = () => g.st.w.map((_, j) => j).filter(j => !g.st.pulled.includes(j));
  const selWord = () => g.st.sel.slice().sort((a, b) => a - b).map(i => g.st.s[i]).join('');
  g.load = day => { const saved = store.get(key(day)); g.st = saved && saved.s ? saved : newState(daily(day), 'daily', day); };
  g.summary = day => { const s = day === today && g.st && g.st.mode === 'daily' ? g.st : store.get(key(day)); if (!s || !s.s) return null; if (s.status === 'playing' && !s.attempts.length && !s.hints.length) return null; return { status: s.status, emoji: emojiOf(s), detail: s.status === 'playing' ? `${s.pulled.length} of 3 pulled` : s.status === 'won' ? (s.knots ? `${s.knots} knot${s.knots === 1 ? '' : 's'}` : 'no knots') : 'knotted up' }; };
  g.emoji = () => emojiOf(g.st);
  const save = () => { if (g.st.mode === 'daily') store.set(key(g.st.day), g.st); };
  function judge(){
    const st = g.st, word = selWord(), rem = remaining(); if (!word) return { kind: 'empty' };
    const lens = rem.map(j => st.w[j].length); if (!lens.includes(word.length)) return { kind: 'badlen', lens: lens.sort(), word };
    const hit = rem.find(j => st.w[j] === word); if (hit !== undefined) return { kind: 'pull', j: hit, word };
    if (st.tried.includes(word)) return { kind: 'dupe', word };
    if (isWord(word)) return { kind: 'knot', word };
    return { kind: 'notword', word };
  }
  function pull(){
    const st = g.st; if (st.status !== 'playing') return;
    const r = judge(), W = (r.word || '').toUpperCase();
    if (r.kind === 'empty') return;
    if (r.kind === 'badlen'){ toast(`Threads left are ${r.lens.join(', ')} letters`); return shakeSel(); }
    if (r.kind === 'dupe') return toast('Already tried that');
    if (r.kind === 'notword'){ toast(`${W} isn't a word`); shakeSel(); st.sel = []; return g.render(); }
    if (r.kind === 'pull'){
      toast(`<b>${W}</b>`, 1200); document.querySelectorAll('.tg-bead').forEach(b => { if (st.o[+b.dataset.i] === r.j) b.classList.add('out'); });
      st.o.forEach((own, i) => { if (own === r.j) st.removed[i] = true; }); st.pulled.push(r.j); st.attempts.push(1); st.sel = [];
      if (st.pulled.length === st.w.length) st.status = 'won';
      save(); setTimeout(() => { g.render(); if (st.status === 'won') finish(g, true, g.bucket()); }, 280); return;
    }
    st.tried.push(r.word); st.knots++; st.attempts.push(0); st.sel = [];
    toast(`<b>${W}</b> is a word, but it isn't one of these threads`, 2200);
    if (st.knots >= MAX) st.status = 'lost';
    save(); g.render(); if (st.status === 'lost') finish(g, false, 0);
  }
  const shakeSel = () => document.querySelectorAll('.tg-bead.sel').forEach(shake);
  function hintBead(){ const st = g.st, rem = remaining(); if (!rem.length) return null; const j = rem.slice().sort((a, b) => st.w[b].length - st.w[a].length || a - b)[0]; const i = st.o.findIndex((own, i) => own === j && !st.removed[i]); return i >= 0 && !st.hints.some(h => h.i === i) ? { i, j } : null; }
  function hint(){ const st = g.st; if (st.status !== 'playing') return; const h = hintBead(); if (!h) return; st.hints.push(h); st.knots++; if (st.knots >= MAX) st.status = 'lost'; save(); g.render(); if (st.status === 'lost') finish(g, false, 0); else toast(`That bead starts the ${st.w[h.j].length}-letter thread · 1 knot`, 2200); }
  g.render = () => {
    const st = g.st, playing = st.status === 'playing', left = MAX - st.knots, n = st.w.length - st.pulled.length; setSub(g);
    let h = `<div class="hud"><div class="left"><div class="dots">${Array.from({ length: MAX }, (_, i) => `<span class="dot${i < st.knots ? ' off' : ''}"></span>`).join('')}</div><span>${st.status === 'won' ? 'Untangled!' : st.status === 'lost' ? 'Knotted up.' : `${n} thread${n === 1 ? '' : 's'} left · ${left} knot${left === 1 ? '' : 's'} to spare`}</span></div><button class="pill" id="tgHint" ${!playing || !hintBead() ? 'disabled' : ''}>Loose end · costs 1</button></div>`;
    const order = st.w.map((_, j) => j).sort((a, b) => st.w[a].length - st.w[b].length || a - b);
    h += `<div class="tg-threads">${order.map(j => { const done = st.pulled.includes(j), lost = st.status === 'lost' && !done; return `<div class="tg-thread c${j}${lost ? ' missed' : ''}"><span class="lab">${st.w[j].length} letters</span><div class="row">${(done || lost) ? st.w[j].split('').map(c => `<span class="b">${c}</span>`).join('') : `<div class="ghost">${'<span></span>'.repeat(st.w[j].length)}</div>`}</div></div>`; }).join('')}</div>`;
    h += `<div class="tg-tangle">${playing ? st.s.split('').map((c, i) => { if (st.removed[i]) return ''; const hh = st.hints.find(x => x.i === i); return `<button class="tg-bead${st.sel.includes(i) ? ' sel' : ''}${hh ? ' h' + hh.j : ''}" data-i="${i}" aria-pressed="${st.sel.includes(i)}">${c}</button>`; }).join('') : `<span style="color:var(--muted);font-size:14px">${st.status === 'won' ? 'Every thread pulled clean.' : 'The threads are shown above.'}</span>`}</div>`;
    const w = selWord();
    h += `<div class="tg-needle"><div class="word">${w ? w : `<span class="ph">${playing ? 'Tap the beads of one word, in any order.' : ''}</span>`}</div><div class="ctl"><button class="btn" id="tgClear" ${st.sel.length ? '' : 'disabled'}>Clear</button><button class="btn primary" id="tgPull" ${!playing || !w ? 'disabled' : ''}>Pull</button></div></div><div class="note">Three words, shuffled together. Each keeps its letter order.</div>`;
    $('#gbody').innerHTML = h;
    $('#tgHint').onclick = hint; $('#tgPull').onclick = pull; $('#tgClear').onclick = () => { st.sel = []; g.render(); };
    document.querySelectorAll('.tg-bead').forEach(b => b.onclick = () => { const i = +b.dataset.i, k = st.sel.indexOf(i); if (k >= 0) st.sel.splice(k, 1); else st.sel.push(i); g.render(); });
  };
  g.key = k => { if (k === 'ENTER') pull(); else if (k === 'BACK'){ g.st.sel.pop(); g.render(); } else if (k === 'ESC'){ g.st.sel = []; g.render(); } };
  g.practice = () => { let idx; do { idx = Math.floor(Math.random() * PUZ.length); } while (PUZ.length > 1 && PUZ[idx] === daily(today)); g.st = newState(PUZ[idx], 'practice', today); };
  g.shareText = () => `Tangle ${g.st.mode === 'daily' ? '#' + (g.st.day + 1) : '(practice)'}\n${g.emoji()}\n${g.st.status === 'won' ? (g.st.knots ? g.st.knots + ' knot' + (g.st.knots === 1 ? '' : 's') : 'No knots') : g.st.pulled.length + '/3 threads'}`;
  g.resultTitle = () => g.st.status === 'won' ? (g.st.knots === 0 ? 'Clean pull.' : 'Untangled.') : 'Knotted up.';
  g.resultDetail = () => `<div class="tg-threads">${g.st.w.map((w, j) => `<div class="tg-thread c${j}${g.st.status === 'won' || g.st.pulled.includes(j) ? '' : ' missed'}"><span class="lab">${w.length}</span><div class="row">${w.split('').map(c => `<span class="b">${c}</span>`).join('')}</div></div>`).join('')}</div>`;
  g.help = `<p>Three words have been tangled into one string. Each word's letters stay in order, but the words are shuffled together. Pull them apart.</p>
    <div class="ex" style="flex-direction:row;flex-wrap:wrap;gap:4px">${'pslilanveetr'.split('').map((c, i) => `<span style="width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:14px;background:${[0, 2, 5, 6, 8, 10].includes(i) ? 'var(--t0)' : 'var(--t1)'};color:#fff">${c}</span>`).join('')}</div>
    <p class="muted" style="text-align:center">PLANET and SILVER, tangled.</p>
    <p>Tap the beads that make up one word, in any order, then Pull. Pulling a real word of the right length that isn't one of today's threads ties a knot. Four knots and the tangle is lost. Non-words cost nothing.</p>
    <p class="muted">"Loose end" marks the first bead of the longest thread still tangled; it costs a knot.</p>`;
  return g;
})();
