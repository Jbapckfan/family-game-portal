/* ===================== KEYSTONE ===================== */
GAMES.keystone = (() => {
  const id = 'keystone', DAYS = DATA.keystone, ROUNDS = 3;
  const g = { id, title: 'Keystone', tagline: 'One hidden word holds five others up.', noun: 'arch', practiceLabel: 'Practice another arch', distTitle: 'Total score on solved days (lower is better)', keyboard: true, st: null,
    bucketLabel: k => (6 + k * 2) + (k === 6 ? '+' : '–' + (7 + k * 2)), bucket: () => Math.min(6, Math.floor((total() - 6) / 2)) };
  const key = d => `${id}.day.${d}`;
  const daily = day => DAYS[((day % DAYS.length) + DAYS.length) % DAYS.length];
  const SCORE_EMOJI = { 2: '🟩', 3: '🟨', 4: '🟧', 5: '🟥', 6: '⬛' };
  const newState = (rounds, mode, day) => ({ mode, day, rounds: rounds.map(r => ({ k: r.k, clues: r.clues.map(c => c.w), dirs: r.clues.map(c => c.d), revealed: 2, strikes: 0, guesses: [], status: 'playing', score: 0 })), cur: 0, status: 'playing', typed: '' });
  const total = (s = g.st) => s.rounds.reduce((a, r) => a + (r.status === 'playing' ? 0 : r.score), 0);
  const emojiOf = s => s.rounds.map(r => r.status === 'playing' ? '⬜' : SCORE_EMOJI[r.score]).join('') + (s.status === 'playing' ? '' : ` ${total(s)}`);
  g.load = day => { const saved = store.get(key(day)); g.st = saved && saved.rounds ? saved : newState(daily(day), 'daily', day); };
  g.summary = day => { const s = day === today && g.st && g.st.mode === 'daily' ? g.st : store.get(key(day)); if (!s || !s.rounds) return null; if (s.status === 'playing' && s.cur === 0 && !s.rounds[0].guesses.length) return null; const done = s.rounds.filter(r => r.status !== 'playing').length; return { status: s.status, emoji: emojiOf(s), detail: s.status === 'playing' ? `arch ${done + 1} of 3` : s.status === 'won' ? `score ${total(s)}` : `score ${total(s)}` }; };
  g.emoji = () => emojiOf(g.st);
  const save = () => { if (g.st.mode === 'daily') store.set(key(g.st.day), g.st); };
  const round = () => g.st.rounds[g.st.cur];
  const fused = (w, c, d) => d === 'before' ? c + w : w + c;
  function fitsOf(word, r){ return r.clues.slice(0, r.revealed).map(c => joins(word, c)); }
  function judge(word){
    const r = round();
    if (word.length < 3) return { kind: 'short' };
    if (r.guesses.some(x => x.w === word)) return { kind: 'dupe' };
    if (word === r.k) return { kind: 'solve' };
    if (r.clues.includes(word)) return { kind: 'clue' };
    if (!COMMON.has(word)) return { kind: 'notword' };
    return { kind: 'miss', fits: fitsOf(word, r) };
  }
  function advance(){
    const st = g.st;
    if (st.rounds.every(r => r.status !== 'playing')){ st.status = st.rounds.every(r => r.status === 'won') ? 'won' : 'lost'; save(); g.render(); finish(g, st.status === 'won', g.bucket()); return; }
    st.cur = st.rounds.findIndex(r => r.status === 'playing'); st.typed = ''; save(); g.render();
  }
  g.key = k => {
    const st = g.st;
    if (k === 'ENTER') return submit();
    if (k === 'BACK'){ st.typed = st.typed.slice(0, -1); return g.render(); }
    if (/^[a-z]$/.test(k) && st.typed.length < 9){ st.typed += k; g.render(); }
  };
  function submit(){
    const st = g.st, r = round(), word = st.typed, j = judge(word), stone = () => document.querySelector('.ks-key');
    if (j.kind === 'short'){ toast('Three letters or more'); return shake(stone()); }
    if (j.kind === 'dupe'){ toast('Already tried'); return shake(stone()); }
    if (j.kind === 'clue'){ toast("That's one of the clues"); return shake(stone()); }
    if (j.kind === 'notword'){ toast('Not in word list'); return shake(stone()); }
    if (j.kind === 'solve'){
      r.status = 'won'; r.score = r.revealed; st.typed = '';
      toast(`<b>${r.k.toUpperCase()}</b> · ${r.clues.map((c, i) => fused(r.k, c, r.dirs[i]).toUpperCase()).slice(0, 3).join(', ')}…`, 2600);
      save(); g.render(); setTimeout(advance, 1300); return;
    }
    r.guesses.push({ w: word, fits: j.fits }); st.typed = '';
    const n = j.fits.filter(Boolean).length, m = j.fits.length;
    if (r.revealed < 5){ r.revealed++; toast(n === m ? `<b>${word.toUpperCase()}</b> fits all ${m}, but it isn't the keystone. New clue.` : `<b>${word.toUpperCase()}</b> fits ${n} of ${m}. New clue.`, 2200); }
    else { r.strikes++; toast(r.strikes >= 2 ? `The keystone was <b>${r.k.toUpperCase()}</b>` : `<b>${word.toUpperCase()}</b> fits ${n} of 5. Last try.`, 2200); if (r.strikes >= 2){ r.status = 'lost'; r.score = 6; } }
    save(); g.render(); shake(stone());
    if (r.status === 'lost') setTimeout(advance, 1500);
  }
  g.render = () => {
    const st = g.st, r = round(), playing = st.status === 'playing'; setSub(g);
    let h = `<div class="ks-rounds">${st.rounds.map((x, i) => `<div class="ks-round${i === st.cur && playing ? ' cur' : ''}${x.status === 'won' ? ' done' : ''}"><span>Arch ${i + 1}</span><b>${x.status === 'playing' ? (i === st.cur ? `${x.revealed} clues` : '—') : x.status === 'won' ? `${x.score}` : '✕'}</b></div>`).join('')}</div>`;
    h += `<div class="hud"><span>${playing ? `Which word joins all of these?` : st.status === 'won' ? 'All three arches stand.' : 'An arch fell.'}</span><div class="ks-strikes">${[0, 1].map(i => `<i class="${r.revealed >= 5 && i < r.strikes ? 'on' : ''}"></i>`).join('')}</div></div>`;
    h += `<div class="ks-arch">`;
    const last = r.guesses[r.guesses.length - 1];
    for (let i = 0; i < 5; i++){
      if (i < r.revealed || r.status !== 'playing') h += `<div class="ks-stone">${r.status !== 'playing' ? fused(r.k, r.clues[i], r.dirs[i]) : r.clues[i]}${r.status === 'playing' && last && i < last.fits.length ? `<span class="fit ${last.fits[i] ? 'y' : ''}">${last.fits[i] ? '✓ ' + last.w : '✗'}</span>` : ''}</div>`;
      else h += `<div class="ks-stone hidden-stone">clue ${i + 1}</div>`;
    }
    const keyCls = r.status === 'won' ? ' solved' : r.status === 'lost' ? ' lost' : '';
    h += `<div class="ks-key${keyCls}">${r.status !== 'playing' ? r.k : st.typed ? st.typed + '<span class="cur"></span>' : '<span class="ph">type the keystone</span>'}</div></div>`;
    if (r.guesses.length) h += `<div class="ks-log">${r.guesses.slice().reverse().map(x => `<div class="ks-g"><span class="w">${x.w}</span><div class="m">${x.fits.map((f, i) => `<span class="${f ? 'y' : ''}">${f ? (FUSED.has(x.w + r.clues[i]) ? x.w + r.clues[i] : r.clues[i] + x.w) : r.clues[i] + ' ✗'}</span>`).join('')}</div></div>`).join('')}</div>`;
    h += `<div class="note">Every wrong guess reveals another clue. Fewer clues, better score.</div>`;
    $('#gbody').innerHTML = h;
  };
  g.practice = () => { let idx; do { idx = Math.floor(Math.random() * DAYS.length); } while (DAYS.length > 1 && DAYS[idx] === daily(today)); g.st = newState(DAYS[idx], 'practice', today); };
  g.shareText = () => `Keystone ${g.st.mode === 'daily' ? '#' + (g.st.day + 1) : '(practice)'}\n${g.st.rounds.map(r => SCORE_EMOJI[r.score] || '⬜').join('')} ${total()}\n${g.st.status === 'won' ? (total() === 6 ? 'Perfect 6' : `Score ${total()} (6 is perfect)`) : 'An arch fell'}`;
  g.resultTitle = () => g.st.status === 'won' ? (total() === 6 ? 'Perfect six.' : total() <= 9 ? 'Solid masonry.' : 'All three stand.') : 'An arch fell.';
  g.resultDetail = () => `<div class="ks-sum">${g.st.rounds.map((r, i) => `<div class="r"><b>${r.k}</b><span class="c">${r.clues.map((c, k) => fused(r.k, c, r.dirs[k])).join(' · ')}</span><span>${r.status === 'won' ? r.score : '✕'}</span></div>`).join('')}</div>`;
  g.help = `<p>A hidden word joins with five clue words to make five new words. Find it. Two clues show at first; every wrong guess reveals another.</p>
    <div class="ex"><span style="font-size:14px;letter-spacing:1px">SNOW · FOOT · BASKET · ROOM · PIN</span><span class="f">all join with</span><span style="color:var(--accent)">BALL</span><span class="f">snowball · football · basketball · ballroom · pinball</span></div>
    <p>The hidden word can go before or after a clue, and the join can be a real compound or pure spelling (CAR+PET, THIN+KING). Only the letters matter.</p>
    <p>Score is how many clues you needed: 2 is perfect, 5 is a scrape. After all five show you get two last tries. Three arches a day, easy to hard.</p>
    <p class="muted">Wrong guesses still teach: each clue shows ✓ if your word joins it.</p>`;
  return g;
})();
