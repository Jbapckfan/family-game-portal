# Pebbles — Monetization Strategy

*A freemium plan for the Pebbles daily word-game suite (CAIRN · MORPH · TANGLE · HUNCH · CIRCUIT · QUARTET), designed to convert daily habit into subscription revenue without poisoning the puzzle experience.*

---

## 1. Product shape

Six daily word games under one roof, one streak across all three ("Today's mountains"). The suite is the moat: single-game clones are everywhere, but a shared streak, shared stats and one home-screen icon create switching costs. Players don't quit a game — they quit a streak.

**Core loop:** open app (push/badge) → play 6 puzzles (10–20 min) → share emoji grid → see streak grow → return tomorrow. Monetization attaches to the loop at moments of *frustration* (stuck on a puzzle) and *pride* (streak, stats, sharing) — never at the moment of play itself.

## 2. Revenue model — three layers, in priority order

### Layer 1 — Pebbles+ subscription (primary, 70–80% of revenue)

| Plan | Price | Purpose |
|---|---|---|
| Monthly | $2.99/mo | Low-friction trial; anchor for yearly |
| **Yearly** | **$19.99/yr** (save 44%) | **Hero plan** — daily games sell best on annual commitment; the streak is a year-long asset |
| Lifetime | $39.99 | Whale capture + cash up front; capped at ~2× yearly so it doesn't cannibalize LTV |

**What subscribers get (in order of perceived value):**
1. **Unlimited hints** — the #1 conversion trigger (see §3). Free tier: 1 hint per game per day.
2. **Full puzzle archive** — 839 CAIRN + 450 MORPH + 430 TANGLE + 937 HUNCH + 286 CIRCUIT + 420 QUARTET puzzles already ship with the app; archive access turns existing content into a paid benefit at zero marginal cost.
3. **Deep stats** — guess distribution, solve-time graphs, per-game history. Costs little to build, loved by the exact cohort that pays.
4. **Tile themes + supporter badge** — cosmetic, shows up in shared screenshots = free marketing.

**Free tier stays genuinely playable forever** — full daily puzzles, streaks, basic stats, sharing. Paying is for depth, not access.

### Layer 2 — Rewarded ads (secondary, 15–25% of revenue)

- **One rewarded video = one extra hint** when the free daily hint is spent. This is the standard, best-converting placement in word/puzzle games (Words With Friends, NYT-app adjacent titles all use hint-for-ad).
- Optional rewarded ad to **unlock one archive puzzle** per day.
- **Never** interstitials between levels, never banners on the play screen — puzzle players churn on visual noise, and they're the cohort most likely to subscribe. Ad-free is implicitly part of Pebbles+.
- Cap: 2 rewarded ads per game per day — scarcity protects subscription value.

### Layer 3 — One-off IAP & merchandise (opportunistic, <5%)

- "Hint pack" consumables (10 hints, $0.99) for ad-averse non-subscribers.
- Seasonal theme packs ($1.99) — holiday tile sets.
- Later: physical (pin of the cairn logo) for the superfan tail. Not a plan, just don't block it.

## 3. The conversion funnel — where paying happens

1. **The stuck moment.** Player fails twice on level 6 of CAIRN → hint button pulses → free hint used → next stuck moment offers *Pebbles+ unlimited hints* or *watch an ad*. This is 60%+ of conversions in comparable games.
2. **The streak-save moment.** Day 40, player about to break a streak (didn't finish all six) → offer "streak freeze" as a Pebbles+ perk (one per week). Streak anxiety is the strongest retention hook this genre has — Wordle-style games live on it.
3. **The share moment.** Win screens carry the emoji grid + "Get Pebbles" link. Shared grids are the entire top of funnel — every viral grid carries the brand.
4. **Paywall timing.** Never before the first win. First upsell impression appears after day-3 completion, once the habit exists. Upsell impressions capped at 1 per session.

## 4. iOS path (App Store)

The current build is a PWA — installable today via Safari → Add to Home Screen. For the App Store:

1. **Wrap with Capacitor** — the React/Vite build drops into a native shell unchanged; keeps one codebase for iOS + Android.
2. **StoreKit 2 / RevenueCat** for subscriptions: monthly/yearly with a 7-day free trial on yearly, lifetime as non-consumable IAP. RevenueCat handles receipts, trials, win-back offers, and cross-platform restore.
3. **AdMob / Unity LevelPlay** rewarded placements behind the same hint API already stubbed in the demo.
4. **App Review notes:** IAP must unlock real functionality (it does — hints/archive/themes); "Restore purchase" required (already stubbed in the premium sheet); no external payment links (Apple rule 3.1.1).
5. **ASO:** keywords — *daily word game, word puzzle, anagram, word ladder, boggle, wordle-style, brain training*. Title: **"Pebbles: Daily Word Games"**. Screenshots lead with the emoji share grid (recognizable genre signal) and the three-game streak.

## 5. Retention = revenue (the loops to protect)

- **Streaks:** per-game streaks + the all-3 suite streak. Streak freeze = Pebbles+ perk.
- **Push/local notifications:** "Your mountains are waiting" at the player's usual play hour (local notification — no server needed).
- **Midnight rollover + countdown** already built; add a "yesterday's answers" recap for lapsed days.
- **Weekly summary card** (shareable): puzzles solved, best medal, streak — a second viral surface beyond daily grids.
- **Hard-mode / weekend special puzzles** as recurring reasons to re-open.

## 6. KPIs & targets (year 1)

| Metric | Target | Note |
|---|---|---|
| D1 / D7 / D30 retention | 60% / 35% / 18% | Word-game genre norms (Wordle-likes skew high) |
| DAU/MAU ("stickiness") | ≥40% | Daily cadence makes this the health metric |
| Free → paid conversion | 2–4% of MAU | NYT Games ≈ genre ceiling; 2% is healthy |
| Trial → paid | ≥40% | Yearly-with-trial default |
| ARPDAU (ads) | $0.01–0.02 | Rewarded-only, capped impressions |
| Blended ARPU (yr 1) | $0.60–1.00 per MAU | At 100k MAU → $60–100k/yr, mostly subscription |

**North star:** suite streak length distribution — every additional streak day compounds retention and the willingness to pay to protect it.

## 7. What *not* to do

- No paywalling the daily puzzle itself — kills the viral share loop, which is the only free growth channel the genre has.
- No energy/lives timers — read as predatory in this genre and clash with the calm aesthetic.
- No interstitial/banner ads on the play screen.
- Don't exceed one upsell surface per session; conversion beats frequency.

## 8. What's already wired in the demo build

- Premium state (`pebbles:premium`) with real in-game effect: **unlimited hints across all three games** when active.
- Premium sheet with the three plans, demo purchase flow (StoreKit wiring point), restore-purchase stub.
- Upsell card on the hub, honest "Demo build" toasts at every payment touchpoint.
- Share grids with brand line, countdown-to-midnight on every win screen, per-game + suite streaks — the retention plumbing is in place.
