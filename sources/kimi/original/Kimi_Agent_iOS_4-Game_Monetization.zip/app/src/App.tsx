import { Suspense, lazy } from 'react'
import { Route, Routes } from 'react-router'
import Home from '@/games/suite/Home'

const CairnPage = lazy(() => import('@/games/cairn/CairnPage'))
const MorphPage = lazy(() => import('@/games/morph/MorphPage'))
const TanglePage = lazy(() => import('@/games/tangle/TanglePage'))
const HunchPage = lazy(() => import('@/games/hunch/HunchPage'))
const CircuitPage = lazy(() => import('@/games/circuit/CircuitPage'))
const QuartetPage = lazy(() => import('@/games/quartet/QuartetPage'))

function GameFallback() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center">
      <div className="animate-pulse font-display text-xl font-extrabold text-muted-foreground">stacking stones…</div>
    </div>
  )
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route
        path="/cairn"
        element={
          <Suspense fallback={<GameFallback />}>
            <CairnPage />
          </Suspense>
        }
      />
      <Route
        path="/morph"
        element={
          <Suspense fallback={<GameFallback />}>
            <MorphPage />
          </Suspense>
        }
      />
      <Route
        path="/tangle"
        element={
          <Suspense fallback={<GameFallback />}>
            <TanglePage />
          </Suspense>
        }
      />
      <Route
        path="/hunch"
        element={
          <Suspense fallback={<GameFallback />}>
            <HunchPage />
          </Suspense>
        }
      />
      <Route
        path="/circuit"
        element={
          <Suspense fallback={<GameFallback />}>
            <CircuitPage />
          </Suspense>
        }
      />
      <Route
        path="/quartet"
        element={
          <Suspense fallback={<GameFallback />}>
            <QuartetPage />
          </Suspense>
        }
      />
      <Route path="*" element={<Home />} />
    </Routes>
  )
}
