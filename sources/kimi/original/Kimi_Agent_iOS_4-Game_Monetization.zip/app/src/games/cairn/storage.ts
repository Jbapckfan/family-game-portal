import type { LevelResult } from './engine'

export interface Stats {
  played: number
  completed: number
  perfect: number
  currentStreak: number
  maxStreak: number
  lastCompletedDay: number | null
  totalMisses: number
}

export const EMPTY_STATS: Stats = {
  played: 0,
  completed: 0,
  perfect: 0,
  currentStreak: 0,
  maxStreak: 0,
  lastCompletedDay: null,
  totalMisses: 0,
}

const STATS_KEY = 'cairn:stats'
const SEEN_KEY = 'cairn:seen-help'
const SOUND_KEY = 'cairn:sound'

function read<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : null
  } catch {
    return null
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* storage unavailable */
  }
}

export function loadStats(): Stats {
  return { ...EMPTY_STATS, ...(read<Partial<Stats>>(STATS_KEY) ?? {}) }
}

export function saveStats(stats: Stats) {
  write(STATS_KEY, stats)
}

export function hasSeenHelp(): boolean {
  return read<boolean>(SEEN_KEY) === true
}

export function markHelpSeen() {
  write(SEEN_KEY, true)
}

export function loadSoundOn(): boolean {
  const v = read<boolean>(SOUND_KEY)
  return v === null ? true : v
}

export function saveSoundOn(on: boolean) {
  write(SOUND_KEY, on)
}

/* ---------------- per-day progress ---------------- */

export interface DayProgress {
  level: number
  results: LevelResult[]
  misses: number
  hints: number
  slots: (number | null)[]
  finished: boolean
  countedPlayed: boolean
}

const dayKey = (day: number) => `cairn:day:${day}`

export function loadDayProgress(day: number): DayProgress | null {
  const p = read<DayProgress>(dayKey(day))
  if (!p || typeof p.level !== 'number' || !Array.isArray(p.results)) return null
  return p
}

export function saveDayProgress(day: number, p: DayProgress) {
  write(dayKey(day), p)
}
