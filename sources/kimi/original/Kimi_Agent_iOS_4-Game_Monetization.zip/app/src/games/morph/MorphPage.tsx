import { useEffect, useState } from 'react'
import { useMorph } from './useMorph'
import { dateLabel } from '../shared/share'
import { GameHeader } from '../shared/GameHeader'
import { SimpleStatsModal } from '../shared/SimpleStatsModal'
import { PracticeBanner, ToastHost, fireConfetti } from '../shared/effects'
import { MorphBoard } from './MorphBoard'
import { MorphHelpModal } from './MorphHelpModal'
import { MorphWinModal } from './MorphWinModal'

const HELP_KEY = 'morph:seen-help'

function LadderLogo() {
  return (
    <svg width="26" height="30" viewBox="0 0 26 30" fill="none" aria-hidden="true">
      <rect x="2" y="2" width="4" height="26" rx="2" fill="hsl(200 82% 60%)" />
      <rect x="20" y="2" width="4" height="26" rx="2" fill="hsl(340 75% 58%)" />
      <rect x="4" y="5" width="18" height="4" rx="2" fill="hsl(145 55% 55%)" />
      <rect x="4" y="13" width="18" height="4" rx="2" fill="hsl(24 92% 58%)" />
      <rect x="4" y="21" width="18" height="4" rx="2" fill="hsl(275 58% 60%)" />
    </svg>
  )
}

export default function MorphPage() {
  const { state, actions } = useMorph()
  const [helpOpen, setHelpOpen] = useState(false)
  const [statsOpen, setStatsOpen] = useState(false)
  const [winOpen, setWinOpen] = useState(false)

  useEffect(() => {
    if (state.phase === 'playing' && !localStorage.getItem(HELP_KEY)) {
      setHelpOpen(true)
      localStorage.setItem(HELP_KEY, '1')
    }
  }, [state.phase])

  useEffect(() => {
    if (!state.finished) return
    const t = window.setTimeout(() => setWinOpen(true), 800)
    if (!state.gaveUp) fireConfetti()
    return () => window.clearTimeout(t)
  }, [state.finished, state.gaveUp])

  return (
    <div className="flex min-h-dvh flex-col">
      <GameHeader
        title="MORPH"
        subtitle={state.mode === 'daily' ? `No. ${state.puzzleNo} · ${dateLabel()}` : 'Practice round'}
        logo={<LadderLogo />}
        onHelp={() => setHelpOpen(true)}
        onStats={() => setStatsOpen(true)}
      />
      <ToastHost toast={state.toast} />

      <main className="flex flex-1 flex-col">
        {state.phase === 'loading' ? (
          <div className="flex flex-1 items-center justify-center">
            <p className="font-display text-lg font-bold text-muted-foreground">Building ladder…</p>
          </div>
        ) : (
          <>
            {state.mode === 'practice' && <PracticeBanner onExit={actions.exitPractice} />}
            <div className="my-auto w-full">
              <MorphBoard state={state} actions={actions} />
              {state.finished && (
                <div className="mt-4 mb-8 flex justify-center">
                  <button type="button" onClick={() => setWinOpen(true)} className="btn3d btn3d-accent h-12 px-6 text-base">
                    See results
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </main>

      <footer className="pb-6 text-center text-xs font-semibold text-muted-foreground">
        A new ladder every midnight · Progress is saved in this browser
      </footer>

      <MorphHelpModal open={helpOpen} onOpenChange={setHelpOpen} />
      <SimpleStatsModal open={statsOpen} onOpenChange={setStatsOpen} stats={state.stats} title="Your ladders" />
      {state.puzzle && (
        <MorphWinModal
          open={winOpen && state.finished}
          onOpenChange={setWinOpen}
          mode={state.mode}
          puzzle={state.puzzle}
          puzzleNo={state.puzzleNo}
          rows={state.rows}
          misses={state.misses}
          gaveUp={state.gaveUp}
          onPractice={() => {
            setWinOpen(false)
            actions.startPractice()
          }}
          onNewPractice={() => {
            setWinOpen(false)
            actions.startPractice()
          }}
          onBackToDaily={() => {
            setWinOpen(false)
            actions.exitPractice()
          }}
        />
      )}
    </div>
  )
}
