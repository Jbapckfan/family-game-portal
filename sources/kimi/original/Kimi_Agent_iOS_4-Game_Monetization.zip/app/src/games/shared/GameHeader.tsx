import { Link } from 'react-router'
import { ArrowLeft, BarChart3, CircleHelp, Volume2, VolumeX } from 'lucide-react'
import { useEffect, useState } from 'react'
import { loadSoundOn, saveSoundOn } from './stats'
import { setSoundEnabled, sfx } from './sound'

interface Props {
  title: string
  subtitle: string
  logo: React.ReactNode
  onHelp?: () => void
  onStats?: () => void
}

function IconButton({
  label,
  onClick,
  to,
  children,
}: {
  label: string
  onClick?: () => void
  to?: string
  children: React.ReactNode
}) {
  const cls =
    'flex h-11 w-11 cursor-pointer items-center justify-center rounded-2xl text-foreground/70 transition-colors duration-150 hover:bg-secondary hover:text-foreground focus-visible:outline-3 focus-visible:outline-ring'
  if (to) {
    return (
      <Link to={to} aria-label={label} title={label} className={cls}>
        {children}
      </Link>
    )
  }
  return (
    <button type="button" aria-label={label} title={label} onClick={onClick} className={cls}>
      {children}
    </button>
  )
}

export function GameHeader({ title, subtitle, logo, onHelp, onStats }: Props) {
  const [soundOn, setSoundOn] = useState(loadSoundOn())
  useEffect(() => {
    setSoundEnabled(loadSoundOn())
  }, [])
  const toggle = () => {
    const on = !soundOn
    setSoundOn(on)
    saveSoundOn(on)
    setSoundEnabled(on)
    if (on) sfx.tap()
  }
  return (
    <header className="sticky top-0 z-40 border-b-2 border-border/60 bg-background/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-lg items-center justify-between px-3">
        <div className="flex items-center gap-2.5">
          <IconButton label="Back to all games" to="/">
            <ArrowLeft className="h-5 w-5" />
          </IconButton>
          <div aria-hidden="true">{logo}</div>
          <div className="leading-tight">
            <div className="font-display text-2xl font-extrabold tracking-wide">{title}</div>
            <div className="text-xs font-semibold text-muted-foreground">{subtitle}</div>
          </div>
        </div>
        <div className="flex items-center gap-0.5">
          {onStats && (
            <IconButton label="Statistics" onClick={onStats}>
              <BarChart3 className="h-5 w-5" />
            </IconButton>
          )}
          <IconButton label={soundOn ? 'Mute sounds' : 'Unmute sounds'} onClick={toggle}>
            {soundOn ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
          </IconButton>
          {onHelp && (
            <IconButton label="How to play" onClick={onHelp}>
              <CircleHelp className="h-5 w-5" />
            </IconButton>
          )}
        </div>
      </div>
    </header>
  )
}
