import dictUrl from '@/games/cairn/data/dict.txt?url'

let dictSet: Set<string> | null = null
let loading: Promise<Set<string>> | null = null

export function loadDict(): Promise<Set<string>> {
  if (dictSet) return Promise.resolve(dictSet)
  if (loading) return loading
  loading = fetch(dictUrl)
    .then((r) => r.text())
    .then((text) => {
      dictSet = new Set(text.split('\n'))
      return dictSet
    })
  return loading
}

export function isValidWord(word: string): boolean {
  return dictSet?.has(word) ?? false
}
