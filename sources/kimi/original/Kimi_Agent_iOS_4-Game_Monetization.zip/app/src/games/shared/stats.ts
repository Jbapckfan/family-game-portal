/* Lightweight per-game stats + daily progress storage (localStorage). */

export interface GameStats {
  played: number
  completed: number
  currentStreak: number
  maxStreak: number
  lastCompletedDay: number | null
}

export const EMPTY_GAME_STATS: GameStats = {
  played: 0,
  completed: 0,
  currentStreak: 0,
  maxStreak: 0,
  lastCompletedDay: null,
}

function read<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : null
  } catch {
    return null
  }
}

function write(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* ignore */
  }
}

export function loadGameStats(game: string): GameStats {
  return { ...EMPTY_GAME_STATS, ...(read<Partial<GameStats>>(`${game}:stats`) ?? {}) }
}

export function saveGameStats(game: string, s: GameStats) {
  write(`${game}:stats`, s)
}

export function loadDayProgress<T>(game: string, day: number): T | null {
  return read<T>(`${game}:day:${day}`)
}

export function saveDayProgress(game: string, day: number, p: unknown) {
  write(`${game}:day:${day}`, p)
}

export function loadSoundOn(): boolean {
  const v = read<boolean>('pebbles:sound')
  return v === null ? true : v
}

export function saveSoundOn(on: boolean) {
  write('pebbles:sound', on)
}
