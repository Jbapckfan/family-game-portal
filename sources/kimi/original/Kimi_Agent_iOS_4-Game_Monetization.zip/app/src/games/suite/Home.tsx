import { useMemo, useState } from 'react'
import { Link } from 'react-router'
import { ChevronRight, Crown, Flame } from 'lucide-react'
import { dateLabel, todayDayNumber } from '../shared/share'
import { PremiumModal } from './PremiumModal'
import { isPremium } from '../shared/premium'

interface GameCard {
  id: string
  name: string
  tagline: string
  path: string
  logo: React.ReactNode
  tint: string
}

function CairnMark() {
  return (
    <div className="flex flex-col-reverse items-center" style={{ gap: 3 }} aria-hidden="true">
      <div className="rounded-full" style={{ width: 46, height: 12, background: 'hsl(200 82% 66%)', transform: 'rotate(-2deg)' }} />
      <div className="rounded-full" style={{ width: 34, height: 12, background: 'hsl(24 92% 58%)', transform: 'rotate(1.5deg)' }} />
      <div className="rounded-full" style={{ width: 22, height: 12, background: 'hsl(340 75% 58%)', transform: 'rotate(-1.5deg)' }} />
    </div>
  )
}

function LadderMark() {
  return (
    <svg width="34" height="42" viewBox="0 0 26 30" fill="none" aria-hidden="true">
      <rect x="2" y="2" width="4" height="26" rx="2" fill="hsl(200 82% 60%)" />
      <rect x="20" y="2" width="4" height="26" rx="2" fill="hsl(340 75% 58%)" />
      <rect x="4" y="5" width="18" height="4" rx="2" fill="hsl(145 55% 55%)" />
      <rect x="4" y="13" width="18" height="4" rx="2" fill="hsl(24 92% 58%)" />
      <rect x="4" y="21" width="18" height="4" rx="2" fill="hsl(275 58% 60%)" />
    </svg>
  )
}

function WebMark() {
  return (
    <svg width="42" height="42" viewBox="0 0 30 30" fill="none" aria-hidden="true">
      <circle cx="7" cy="7" r="4" fill="hsl(24 92% 58%)" />
      <circle cx="23" cy="7" r="4" fill="hsl(145 55% 55%)" />
      <circle cx="7" cy="23" r="4" fill="hsl(275 58% 60%)" />
      <circle cx="23" cy="23" r="4" fill="hsl(200 82% 66%)" />
      <path d="M10 8 L20 22 M20 8 L10 22 M7 11 L7 19 M23 11 L23 19" stroke="hsl(340 28% 35%)" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

function KeyMark() {
  return (
    <svg width="42" height="34" viewBox="0 0 30 24" fill="none" aria-hidden="true">
      <rect x="0" y="6" width="8" height="10" rx="2.5" fill="hsl(145 55% 55%)" />
      <rect x="11" y="6" width="8" height="10" rx="2.5" fill="hsl(43 92% 58%)" />
      <rect x="22" y="6" width="8" height="10" rx="2.5" fill="hsl(340 14% 62%)" />
    </svg>
  )
}

function RingMark() {
  return (
    <svg width="40" height="40" viewBox="0 0 28 28" fill="none" aria-hidden="true">
      <circle cx="14" cy="4" r="3.4" fill="hsl(24 92% 58%)" />
      <circle cx="24" cy="14" r="3.4" fill="hsl(145 55% 55%)" />
      <circle cx="14" cy="24" r="3.4" fill="hsl(200 82% 60%)" />
      <circle cx="4" cy="14" r="3.4" fill="hsl(275 58% 62%)" />
      <circle cx="14" cy="14" r="4" fill="none" stroke="hsl(340 25% 40%)" strokeWidth="2" strokeDasharray="2 2.5" />
    </svg>
  )
}

function GridMark() {
  return (
    <svg width="40" height="40" viewBox="0 0 28 28" fill="none" aria-hidden="true">
      <rect x="1" y="1" width="12" height="12" rx="3.5" fill="hsl(43 92% 55%)" />
      <rect x="15" y="1" width="12" height="12" rx="3.5" fill="hsl(145 55% 55%)" />
      <rect x="1" y="15" width="12" height="12" rx="3.5" fill="hsl(200 82% 60%)" />
      <rect x="15" y="15" width="12" height="12" rx="3.5" fill="hsl(275 58% 60%)" />
    </svg>
  )
}

const GAMES: GameCard[] = [
  {
    id: 'cairn',
    name: 'CAIRN',
    tagline: 'Stack every letter. Climb from 3 to 7.',
    path: '/cairn',
    logo: <CairnMark />,
    tint: 'hsl(24 92% 58%)',
  },
  {
    id: 'morph',
    name: 'MORPH',
    tagline: 'One letter at a time, start word to target. Beat par.',
    path: '/morph',
    logo: <LadderMark />,
    tint: 'hsl(145 55% 55%)',
  },
  {
    id: 'tangle',
    name: 'TANGLE',
    tagline: 'Trace the 4×4 web. Find words, chase gold.',
    path: '/tangle',
    logo: <WebMark />,
    tint: 'hsl(275 58% 60%)',
  },
  {
    id: 'hunch',
    name: 'HUNCH',
    tagline: 'Guess the hidden word in six. Trust your gut.',
    path: '/hunch',
    logo: <KeyMark />,
    tint: 'hsl(43 92% 55%)',
  },
  {
    id: 'circuit',
    name: 'CIRCUIT',
    tagline: 'Chain words around the ring. Light all 12 letters.',
    path: '/circuit',
    logo: <RingMark />,
    tint: 'hsl(200 82% 60%)',
  },
  {
    id: 'quartet',
    name: 'QUARTET',
    tagline: 'Sixteen words, four hidden groups. Spot them all.',
    path: '/quartet',
    logo: <GridMark />,
    tint: 'hsl(24 92% 58%)',
  },
]

function readJSON<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : null
  } catch {
    return null
  }
}

function gameDoneToday(id: string, day: number): boolean {
  if (id === 'tangle') return readJSON<{ goldReached: boolean }>(`tangle:day:${day}`)?.goldReached === true
  return readJSON<{ finished: boolean }>(`${id}:day:${day}`)?.finished === true
}

function suiteStreak(day: number): number {
  let streak = 0
  for (let d = day; d > day - 400; d--) {
    const allDone = GAMES.every((g) => gameDoneToday(g.id, d))
    if (allDone) streak++
    else if (d === day) continue // today may still be in progress
    else break
  }
  return streak
}

export default function Home() {
  const [premiumOpen, setPremiumOpen] = useState(false)
  const [premium] = useState(isPremium())
  const day = todayDayNumber()
  const doneCount = useMemo(() => GAMES.filter((g) => gameDoneToday(g.id, day)).length, [day])
  const streak = useMemo(() => suiteStreak(day), [day])

  return (
    <div className="flex min-h-dvh flex-col">
      <header className="sticky top-0 z-40 border-b-2 border-border/60 bg-background/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-lg items-center justify-between px-3">
          <div className="flex items-center gap-2.5">
            <CairnMark />
            <div className="leading-tight">
              <div className="font-display text-2xl font-extrabold tracking-wide">PEBBLES</div>
              <div className="text-xs font-semibold text-muted-foreground">{dateLabel()}</div>
            </div>
          </div>
          <button
            type="button"
            onClick={() => setPremiumOpen(true)}
            className="btn3d h-11 px-4 text-sm"
            aria-label="Pebbles+ premium"
          >
            <Crown className="h-4 w-4" />
            {premium ? 'Pebbles+ ✨' : 'Go Pebbles+'}
          </button>
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-lg flex-1 flex-col px-3">
        {/* today's progress */}
        <div className="mt-5 flex items-center justify-between rounded-3xl bg-secondary px-5 py-4">
          <div>
            <div className="font-display text-lg font-extrabold">Today's mountains</div>
            <div className="text-sm font-bold text-muted-foreground">{doneCount} of {GAMES.length} games summited</div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex gap-1.5">
              {GAMES.map((g) => (
                <span
                  key={g.id}
                  className="h-3.5 w-7 rounded-full"
                  style={{ background: gameDoneToday(g.id, day) ? 'hsl(145 55% 52%)' : 'hsl(340 15% 84%)' }}
                  aria-label={`${g.name} ${gameDoneToday(g.id, day) ? 'done' : 'not done'}`}
                />
              ))}
            </div>
            {streak > 0 && (
              <span className="flex items-center gap-1 font-display text-lg font-extrabold text-[hsl(24_92%_50%)]">
                <Flame className="h-5 w-5" />
                {streak}
              </span>
            )}
          </div>
        </div>

        {/* game cards */}
        <div className="mt-4 flex flex-col gap-3">
          {GAMES.map((g) => {
            const done = gameDoneToday(g.id, day)
            return (
              <Link
                key={g.id}
                to={g.path}
                className="group flex items-center gap-4 rounded-3xl border-2 border-border bg-card p-4 transition-transform duration-150 hover:-translate-y-0.5 focus-visible:outline-3 focus-visible:outline-ring"
              >
                <div
                  className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl"
                  style={{ background: `${g.tint.replace(')', ' / 0.14)')}` }}
                >
                  {g.logo}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-display text-xl font-extrabold tracking-wide">{g.name}</span>
                    {done && (
                      <span className="rounded-full bg-[hsl(145_55%_52%/0.18)] px-2 py-0.5 text-xs font-extrabold text-[hsl(145_55%_35%)]">
                        Done ✓
                      </span>
                    )}
                  </div>
                  <p className="truncate text-sm font-semibold text-muted-foreground">{g.tagline}</p>
                </div>
                <ChevronRight className="h-6 w-6 shrink-0 text-muted-foreground transition-transform duration-150 group-hover:translate-x-1" />
              </Link>
            )
          })}
        </div>

        {/* premium upsell */}
        {!premium && (
          <button
            type="button"
            onClick={() => setPremiumOpen(true)}
            className="mt-4 flex items-center gap-3 rounded-3xl border-2 border-dashed border-[hsl(45_95%_52%)] bg-[hsl(45_95%_52%/0.08)] p-4 text-left transition-colors hover:bg-[hsl(45_95%_52%/0.14)] focus-visible:outline-3 focus-visible:outline-ring"
          >
            <Crown className="h-8 w-8 shrink-0" style={{ color: 'hsl(45 95% 50%)' }} />
            <span>
              <span className="block font-display text-lg font-extrabold">Pebbles+</span>
              <span className="block text-sm font-semibold text-muted-foreground">
                Unlimited hints in all six games · archive · deep stats. From $2.99/mo.
              </span>
            </span>
          </button>
        )}
      </main>

      <footer className="mx-auto max-w-lg px-3 pb-8 pt-6 text-center text-xs font-semibold leading-relaxed text-muted-foreground">
        <p>New puzzles every midnight · Progress saves on this device</p>
        <p className="mt-1">On iPhone: open in Safari → Share → “Add to Home Screen” to install as an app</p>
      </footer>

      <PremiumModal open={premiumOpen} onOpenChange={setPremiumOpen} />
    </div>
  )
}
