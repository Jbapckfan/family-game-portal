import { useEffect, useState } from 'react'
import { Crown, Infinity as InfinityIcon, Archive, LineChart, Sparkles } from 'lucide-react'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'
import { isPremium, setPremium } from '../shared/premium'

const BENEFITS = [
  { icon: InfinityIcon, text: 'Unlimited hints in every game' },
  { icon: Archive, text: 'Full puzzle archive — play any past day' },
  { icon: LineChart, text: 'Deep stats: guess distribution & history graphs' },
  { icon: Sparkles, text: 'Exclusive tile themes + supporter badge' },
]

const PLANS = [
  { id: 'monthly', name: 'Monthly', price: '$2.99', note: 'per month' },
  { id: 'yearly', name: 'Yearly', price: '$19.99', note: 'save 44%', best: true },
  { id: 'lifetime', name: 'Lifetime', price: '$39.99', note: 'once, forever' },
] as const

export function PremiumModal({ open, onOpenChange }: { open: boolean; onOpenChange: (o: boolean) => void }) {
  const [premium, setPremiumState] = useState(isPremium())
  const [toast, setToast] = useState<string | null>(null)

  useEffect(() => {
    const sync = () => setPremiumState(isPremium())
    window.addEventListener('pebbles:premium-changed', sync)
    return () => window.removeEventListener('pebbles:premium-changed', sync)
  }, [])

  const flash = (msg: string) => {
    setToast(msg)
    window.setTimeout(() => setToast(null), 2200)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md rounded-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-center gap-2 text-center font-display text-3xl font-extrabold">
            <Crown className="h-7 w-7" style={{ color: 'hsl(45 95% 50%)' }} />
            Pebbles+
          </DialogTitle>
          <DialogDescription className="sr-only">Premium subscription options</DialogDescription>
        </DialogHeader>

        {toast && (
          <div className="anim-toast mx-auto rounded-full bg-[hsl(340_25%_28%)] px-4 py-2 font-display text-sm font-bold text-white">
            {toast}
          </div>
        )}

        {premium ? (
          <div className="flex flex-col items-center gap-3 text-center">
            <div className="rounded-full bg-[hsl(45_95%_52%/0.2)] px-4 py-2 font-display text-lg font-extrabold">
              Demo premium is active ✨
            </div>
            <p className="text-sm font-semibold text-muted-foreground">
              Unlimited hints are unlocked across all three games right now.
            </p>
            <button
              type="button"
              className="btn3d btn3d-soft h-11 px-5 text-sm"
              onClick={() => {
                setPremium(false)
                flash('Demo premium off')
              }}
            >
              Turn off demo premium
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            <ul className="flex flex-col gap-2.5">
              {BENEFITS.map((b) => (
                <li key={b.text} className="flex items-center gap-3 text-[15px] font-bold">
                  <span className="flex h-9 w-9 items-center justify-center rounded-2xl bg-secondary">
                    <b.icon className="h-4.5 w-4.5" />
                  </span>
                  {b.text}
                </li>
              ))}
            </ul>

            <div className="grid grid-cols-3 gap-2">
              {PLANS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => flash('Demo build — payments wire up via StoreKit on iOS')}
                  className={`btn3d flex h-auto flex-col gap-0.5 px-2 py-3 text-center ${'best' in p && p.best ? '' : 'btn3d-soft'}`}
                >
                  <span className="text-xs font-bold uppercase tracking-wide opacity-80">{p.name}</span>
                  <span className="font-display text-xl font-extrabold">{p.price}</span>
                  <span className="text-[10px] font-bold opacity-70">{p.note}</span>
                </button>
              ))}
            </div>

            <div className="flex items-center justify-center gap-3">
              <button
                type="button"
                className="btn3d btn3d-accent h-11 px-5 text-sm"
                onClick={() => {
                  setPremium(true)
                  flash('Demo premium on — enjoy unlimited hints')
                }}
              >
                Try demo premium
              </button>
              <button
                type="button"
                className="h-11 cursor-pointer px-2 text-sm font-bold text-muted-foreground underline underline-offset-2 transition-colors hover:text-foreground"
                onClick={() => flash('No purchase found (demo)')}
              >
                Restore purchase
              </button>
            </div>
            <p className="text-center text-xs font-semibold text-muted-foreground">
              Demo checkout: on the App Store this becomes a real StoreKit in-app purchase; on web, Stripe.
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
